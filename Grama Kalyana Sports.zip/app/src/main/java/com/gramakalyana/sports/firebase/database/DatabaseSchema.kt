package com.gramakalyana.sports.firebase.database

/**
 * Firebase Realtime Database Schema for Grama Kalyana Sports
 * Optimized for real-time score synchronization and low-latency updates
 */
object DatabaseSchema {
    
    // Root structure
    const val ROOT = "gramakalyana_sports"
    
    // Main nodes
    object Users {
        const val NODE = "users"
        const val UID = "uid"
        const val EMAIL = "email"
        const val NAME = "name"
        const val PHONE = "phone"
        const val ROLE = "role"
        const val CREATED_AT = "createdAt"
        const val LAST_LOGIN_AT = "lastLoginAt"
        const val IS_EMAIL_VERIFIED = "isEmailVerified"
        const val PROFILE_IMAGE = "profileImage"
        const val NOTIFICATIONS_ENABLED = "notificationsEnabled"
        const val SETTINGS = "settings"
    }
    
    object Tournaments {
        const val NODE = "tournaments"
        const val ID = "id"
        const val NAME = "name"
        const val DESCRIPTION = "description"
        const val SPORT_TYPE = "sportType"
        const val STATUS = "status"
        const val TOTAL_TEAMS = "totalTeams"
        const val TOTAL_MATCHES = "totalMatches"
        const val COMPLETED_MATCHES = "completedMatches"
        const val START_DATE = "startDate"
        const val END_DATE = "endDate"
        const val VENUE = "venue"
        const val FORMAT = "format"
        const val PRIZE_POOL = "prizePool"
        const val CREATED_BY = "createdBy"
        const val CREATED_AT = "createdAt"
        const val UPDATED_AT = "updatedAt"
        const val TEAMS = "teams"
        const val FIXTURES = "fixtures"
        const val CURRENT_MATCH = "currentMatch"
    }
    
    object Teams {
        const val NODE = "teams"
        const val ID = "id"
        const val NAME = "name"
        const val LOGO = "logo"
        const val CAPTAIN = "captain"
        const val TOTAL_PLAYERS = "totalPlayers"
        const val WINS = "wins"
        const val LOSSES = "losses"
        const val POINTS = "points"
        const val STATUS = "status"
        const val SPORT_TYPE = "sportType"
        const val FOUNDED_YEAR = "foundedYear"
        const val HOME_GROUND = "homeGround"
        const val TOURNAMENT_ID = "tournamentId"
        const val PLAYERS = "players"
        const val STATISTICS = "statistics"
        const val CREATED_AT = "createdAt"
        const val UPDATED_AT = "updatedAt"
    }
    
    object Players {
        const val NODE = "players"
        const val ID = "id"
        const val NAME = "name"
        const val TEAM_ID = "teamId"
        const val TEAM_NAME = "teamName"
        const val JERSEY_NUMBER = "jerseyNumber"
        const val ROLE = "role"
        const val AGE = "age"
        const val PHONE_NUMBER = "phoneNumber"
        const val EMAIL = "email"
        const val PROFILE_IMAGE = "profileImage"
        const val TOTAL_MATCHES = "totalMatches"
        const val TOTAL_RUNS = "totalRuns"
        const val TOTAL_WICKETS = "totalWickets"
        const val TOTAL_POINTS = "totalPoints"
        const val STATUS = "status"
        const val JOIN_DATE = "joinDate"
        const val BATTING_AVERAGE = "battingAverage"
        const val STRIKE_RATE = "strikeRate"
        const val BOWLING_AVERAGE = "bowlingAverage"
        const val ECONOMY_RATE = "economyRate"
        const val HIGHEST_SCORE = "highestScore"
        const val BEST_BOWLING = "bestBowling"
        const val MAN_OF_THE_MATCH_AWARDS = "manOfTheMatchAwards"
        const val CATCHES = "catches"
        const val RUN_OUTS = "runOuts"
        const val STATISTICS = "statistics"
        const val MATCH_HISTORY = "matchHistory"
        const val CREATED_AT = "createdAt"
        const val UPDATED_AT = "updatedAt"
    }
    
    object Matches {
        const val NODE = "matches"
        const val ID = "id"
        const val TOURNAMENT_ID = "tournamentId"
        const val TEAM_A_ID = "teamAId"
        const val TEAM_B_ID = "teamBId"
        const val TEAM_A_NAME = "teamAName"
        const val TEAM_B_NAME = "teamBName"
        const val SPORT_TYPE = "sportType"
        const val VENUE = "venue"
        const val SCHEDULED_DATE = "scheduledDate"
        const val STATUS = "status"
        const val WINNER_ID = "winnerId"
        const val RESULT_SUMMARY = "resultSummary"
        const val MVP_PLAYER_ID = "mvpPlayerId"
        const val MVP_PLAYER_NAME = "mvpPlayerName"
        const val MVP_STATS = "mvpStats"
        const val CREATED_AT = "createdAt"
        const val UPDATED_AT = "updatedAt"
        const val STARTED_AT = "startedAt"
        const val COMPLETED_AT = "completedAt"
        const val DURATION = "duration"
    }
    
    object LiveScores {
        const val NODE = "live_scores"
        const val MATCH_ID = "matchId"
        const val TEAM_A_SCORE = "teamAScore"
        const val TEAM_B_SCORE = "teamBScore"
        const val CURRENT_OVER = "currentOver"
        const val CURRENT_BALL = "currentBall"
        const val INNINGS = "innings"
        const val TARGET = "target"
        const val REQUIRED_RUN_RATE = "requiredRunRate"
        const val CURRENT_RUN_RATE = "currentRunRate"
        const val LAST_UPDATED = "lastUpdated"
        const val IS_LIVE = "isLive"
        const val VIEWERS_COUNT = "viewersCount"
        
        // Cricket specific
        object Cricket {
            const val TEAM_A_RUNS = "teamARuns"
            const val TEAM_A_WICKETS = "teamAWickets"
            const val TEAM_A_OVERS = "teamAOvers"
            const val TEAM_B_RUNS = "teamBRuns"
            const val TEAM_B_WICKETS = "teamBWickets"
            const val TEAM_B_OVERS = "teamBOvers"
            const val CURRENT_BATSMAN = "currentBatsman"
            const val CURRENT_BOWLER = "currentBowler"
            const val PARTNERSHIP = "partnership"
            const val LAST_WICKET = "lastWicket"
            const val LAST_SIX = "lastSix"
            const val LAST_FOUR = "lastFour"
            const val POWERPLAY = "powerplay"
        }
        
        // Kabaddi specific
        object Kabaddi {
            const val TEAM_A_POINTS = "teamAPoints"
            const val TEAM_B_POINTS = "teamBPoints"
            const val CURRENT_RAID = "currentRaid"
            const val RAID_TIME = "raidTime"
            const val TEAM_A_SUCCESSFUL_RAIDS = "teamASuccessfulRaids"
            const val TEAM_B_SUCCESSFUL_RAIDS = "teamBSuccessfulRaids"
            const val TEAM_A_UNSUCCESSFUL_RAIDS = "teamAUnsuccessfulRaids"
            const val TEAM_B_UNSUCCESSFUL_RAIDS = "teamBUnsuccessfulRaids"
            const val TEAM_A_ALL_OUTS = "teamAAllOuts"
            const val TEAM_B_ALL_OUTS = "teamBAllOuts"
            const val CURRENT_HALF = "currentHalf"
            const val TIME_LEFT = "timeLeft"
            const val LAST_RAID = "lastRaid"
            const val LAST_TACKLE = "lastTackle"
        }
        
        // Volleyball specific
        object Volleyball {
            const val TEAM_A_SETS = "teamASets"
            const val TEAM_B_SETS = "teamBSets"
            const val TEAM_A_POINTS = "teamAPoints"
            const val TEAM_B_POINTS = "teamBPoints"
            const val CURRENT_SET = "currentSet"
            const val SET_POINTS = "setPoints"
            const val TEAM_A_SERVES = "teamAServes"
            const val TEAM_B_SERVES = "teamBServes"
            const val LAST_SERVE = "lastServe"
            const val LAST_SPIKE = "lastSpike"
            const val LAST_BLOCK = "lastBlock"
            const val SET_TIMEOUTS = "setTimeouts"
        }
    }
    
    object Commentary {
        const val NODE = "commentary"
        const val MATCH_ID = "matchId"
        const val ID = "id"
        const val TEXT = "text"
        const val TYPE = "type"
        const val TIMESTAMP = "timestamp"
        const val OVER = "over"
        const val BALL = "ball"
        const val PLAYER_NAME = "playerName"
        const val TEAM_NAME = "teamName"
        const val IMPORTANCE = "importance"
        const val CREATED_AT = "createdAt"
        
        // Commentary types
        object Type {
            const val RUN = "run"
            const val WICKET = "wicket"
            const val BOUNDARY = "boundary"
            const val SIX = "six"
            const val OVER_START = "over_start"
            const val OVER_END = "over_end"
            const val INNINGS_START = "innings_start"
            const val INNINGS_END = "innings_end"
            const val MATCH_START = "match_start"
            const val MATCH_END = "match_end"
            const val RAID = "raid"
            const val TACKLE = "tackle"
            const val ALL_OUT = "all_out"
            const val SERVE = "serve"
            const val SPIKE = "spike"
            const val BLOCK = "block"
            const val SET_START = "set_start"
            const val SET_END = "set_end"
            const val GENERAL = "general"
        }
        
        // Importance levels
        object Importance {
            const val LOW = "low"
            const val MEDIUM = "medium"
            const val HIGH = "high"
            const val CRITICAL = "critical"
        }
    }
    
    object Leaderboards {
        const val NODE = "leaderboards"
        const val TYPE = "type"
        const val RANK = "rank"
        const val ENTITY_ID = "entityId"
        const val ENTITY_NAME = "entityName"
        const val VALUE = "value"
        const val TEAM_ID = "teamId"
        const val SPORT_TYPE = "sportType"
        const val LAST_UPDATED = "lastUpdated"
        const val TREND = "trend"
        
        // Leaderboard types
        object Type {
            const val MOST_RUNS = "most_runs"
            const val MOST_WICKETS = "most_wickets"
            const val MOST_POINTS = "most_points"
            const val BEST_BATTING_AVERAGE = "best_batting_average"
            const val BEST_BOWLING_AVERAGE = "best_bowling_average"
            const val MOST_SIXES = "most_sixes"
            const val MOST_FOURS = "most_fours"
            const val BEST_STRIKE_RATE = "best_strike_rate"
            const val MOST_RAID_POINTS = "most_raid_points"
            const val BEST_DEFENDER = "best_defender"
            const val MOST_SUCCESSFUL_RAIDS = "most_successful_raids"
            const val MOST_SUCCESSFUL_TACKLES = "most_successful_tackles"
            const val TEAM_POINTS = "team_points"
            const val TEAM_WINS = "team_wins"
            const val MVP_COUNT = "mvp_count"
        }
    }
    
    object Notifications {
        const val NODE = "notifications"
        const val USER_ID = "userId"
        const val ID = "id"
        const val TITLE = "title"
        const val MESSAGE = "message"
        const val TYPE = "type"
        const val DATA = "data"
        const val IS_READ = "isRead"
        const val CREATED_AT = "createdAt"
        const val EXPIRES_AT = "expiresAt"
        const val MATCH_ID = "matchId"
        const val TOURNAMENT_ID = "tournamentId"
        
        // Notification types
        object Type {
            const val MATCH_STARTED = "match_started"
            const val MATCH_COMPLETED = "match_completed"
            const val SCORE_UPDATE = "score_update"
            const val WICKET_FALLEN = "wicket_fallen"
            const val BOUNDARY_HIT = "boundary_hit"
            const val SIX_HIT = "six_hit"
            const val RAID_COMPLETED = "raid_completed"
            const val TACKLE_COMPLETED = "tackle_completed"
            const val ALL_OUT = "all_out"
            const val SET_COMPLETED = "set_completed"
            const val MATCH_CANCELLED = "match_cancelled"
            const val TOURNAMENT_STARTED = "tournament_started"
            const val TOURNAMENT_COMPLETED = "tournament_completed"
            const val NEW_TOURNAMENT = "new_tournament"
            const val TEAM_UPDATE = "team_update"
            const val PLAYER_UPDATE = "player_update"
            const val SYSTEM = "system"
        }
    }
    
    object MatchHistory {
        const val NODE = "match_history"
        const val MATCH_ID = "matchId"
        const val PLAYER_ID = "playerId"
        const val TEAM_ID = "teamId"
        const val PERFORMANCE = "performance"
        const val DATE = "date"
        const val RESULT = "result"
        const val POINTS_EARNED = "pointsEarned"
        const val RATING = "rating"
    }
    
    object Statistics {
        const val NODE = "statistics"
        const val ENTITY_TYPE = "entityType"
        const val ENTITY_ID = "entityId"
        const val TOTAL_MATCHES = "totalMatches"
        const val WINS = "wins"
        const val LOSSES = "losses"
        const val DRAWS = "draws"
        const val POINTS = "points"
        const val RUNS = "runs"
        const val WICKETS = "wickets"
        const val CATCHES = "catches"
        const val RUN_OUTS = "runOuts"
        const val STUMPINGS = "stumpings"
        const val SIXES = "sixes"
        const val FOURS = "fours"
        const val RAID_POINTS = "raidPoints"
        const val SUCCESSFUL_RAIDS = "successfulRaids"
        const val UNSUCCESSFUL_RAIDS = "unsuccessfulRaids"
        const val SUCCESSFUL_TACKLES = "successfulTackles"
        const val UNSUCCESSFUL_TACKLES = "unsuccessfulTackles"
        const val ALL_OUTS = "allOuts"
        const val SETS_WON = "setsWon"
        const val SETS_LOST = "setsLost"
        const val POINTS_CONCEDED = "pointsConceded"
        const val SPIKES = "spikes"
        const val BLOCKS = "blocks"
        const val SERVES = "serves"
        const val ACE_SERVES = "aceServes"
        const val RECEPTIONS = "receptions"
        const val DIGS = "digs"
        const val LAST_UPDATED = "lastUpdated"
        const val SEASON = "season"
        const val TOURNAMENT_ID = "tournamentId"
    }
    
    /**
     * Example JSON structure for a complete match
     */
    fun getExampleMatchSchema(): String {
        return """
        {
          "matches": {
            "match_001": {
              "id": "match_001",
              "tournamentId": "tournament_001",
              "teamAId": "team_001",
              "teamBId": "team_002",
              "teamAName": "Royal Warriors",
              "teamBName": "Thunder Strikers",
              "sportType": "CRICKET",
              "venue": "Grama Kalyana Stadium",
              "scheduledDate": 1672531200000,
              "status": "LIVE",
              "createdAt": 1672531200000,
              "updatedAt": 1672531200000,
              "startedAt": 1672531200000
            }
          },
          "live_scores": {
            "match_001": {
              "matchId": "match_001",
              "cricket": {
                "teamARuns": 156,
                "teamAWickets": 4,
                "teamAOvers": 18.5,
                "teamBRuns": 89,
                "teamBWickets": 2,
                "teamBOvers": 12.3,
                "currentOver": 19,
                "currentBall": 3,
                "currentBatsman": "player_001",
                "currentBowler": "player_005",
                "partnership": {
                  "runs": 45,
                  "balls": 32,
                  "batsman1": "player_001",
                  "batsman2": "player_002"
                },
                "lastWicket": {
                  "player": "player_003",
                  "score": 89,
                  "balls": 67,
                  "wicketType": "caught",
                  "bowler": "player_005"
                },
                "lastSix": {
                  "player": "player_001",
                  "over": 18,
                  "ball": 4,
                  "runs": 6
                },
                "lastFour": {
                  "player": "player_002",
                  "over": 17,
                  "ball": 2,
                  "runs": 4
                }
              },
              "lastUpdated": 1672531200000,
              "isLive": true,
              "viewersCount": 245
            }
          },
          "commentary": {
            "match_001": {
              "commentary_001": {
                "id": "commentary_001",
                "text": "Massive six over mid-wicket!",
                "type": "six",
                "timestamp": 1672531200000,
                "over": 18,
                "ball": 4,
                "playerName": "Rahul Sharma",
                "teamName": "Royal Warriors",
                "importance": "high",
                "createdAt": 1672531200000
              }
            }
          }
        }
        """.trimIndent()
    }
    
    /**
     * Example JSON structure for a tournament
     */
    fun getExampleTournamentSchema(): String {
        return """
        {
          "tournaments": {
            "tournament_001": {
              "id": "tournament_001",
              "name": "Grama Kalyana Premier League",
              "description": "Annual cricket championship",
              "sportType": "CRICKET",
              "status": "LIVE",
              "totalTeams": 8,
              "totalMatches": 28,
              "completedMatches": 12,
              "startDate": 1672531200000,
              "endDate": 1675123200000,
              "venue": "Grama Kalyana Sports Complex",
              "format": "LEAGUE",
              "prizePool": "₹50,000",
              "createdBy": "user_001",
              "createdAt": 1672444800000,
              "updatedAt": 1672531200000,
              "teams": ["team_001", "team_002", "team_003", "team_004"],
              "fixtures": [
                {
                  "id": "fixture_001",
                  "matchId": "match_001",
                  "teamAId": "team_001",
                  "teamBId": "team_002",
                  "scheduledDate": 1672531200000,
                  "venue": "Grama Kalyana Stadium",
                  "round": 1,
                  "matchNumber": 1
                }
              ],
              "currentMatch": "match_001"
            }
          }
        }
        """.trimIndent()
    }
    
    /**
     * Example JSON structure for player statistics
     */
    fun getExamplePlayerStatsSchema(): String {
        return """
        {
          "statistics": {
            "players": {
              "player_001": {
                "entityType": "player",
                "entityId": "player_001",
                "totalMatches": 25,
                "wins": 18,
                "losses": 7,
                "draws": 0,
                "points": 36,
                "cricket": {
                  "runs": 1250,
                  "wickets": 12,
                  "battingAverage": 52.5,
                  "strikeRate": 145.8,
                  "bowlingAverage": 28.3,
                  "economyRate": 6.2,
                  "highestScore": 98,
                  "bestBowling": "3/24",
                  "sixes": 15,
                  "fours": 45,
                  "catches": 18,
                  "runOuts": 7,
                  "stumpings": 2
                },
                "kabaddi": {
                  "raidPoints": 156,
                  "successfulRaids": 89,
                  "unsuccessfulRaids": 12,
                  "successfulTackles": 34,
                  "unsuccessfulTackles": 8,
                  "allOuts": 3
                },
                "volleyball": {
                  "setsWon": 45,
                  "setsLost": 23,
                  "pointsConceded": 234,
                  "spikes": 67,
                  "blocks": 34,
                  "serves": 89,
                  "aceServes": 12,
                  "receptions": 156,
                  "digs": 78
                },
                "lastUpdated": 1672531200000,
                "season": "2024",
                "tournamentId": "tournament_001"
              }
            }
          }
        }
        """.trimIndent()
    }
}
