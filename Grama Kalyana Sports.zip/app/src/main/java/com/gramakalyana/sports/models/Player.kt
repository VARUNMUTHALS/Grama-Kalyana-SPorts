package com.gramakalyana.sports.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.Date

@Parcelize
data class Player(
    val id: String = "",
    val name: String = "",
    val teamId: String = "",
    val sportType: SportType = SportType.CRICKET,
    val jerseyNumber: Int = 0,
    val position: String = "",
    val photo: String = "",
    val dateOfBirth: Date = Date(),
    val contactNumber: String = "",
    val email: String = "",
    val address: String = "",
    val isCaptain: Boolean = false,
    val isViceCaptain: Boolean = false,
    val isActive: Boolean = true,
    
    // Cricket specific stats
    val totalRuns: Int = 0,
    val totalWickets: Int = 0,
    val totalCatches: Int = 0,
    val highestScore: Int = 0,
    val totalMatches: Int = 0,
    val average: Double = 0.0,
    val strikeRate: Double = 0.0,
    val economy: Double = 0.0,
    
    // Kabaddi specific stats
    val totalRaidPoints: Int = 0,
    val totalTacklePoints: Int = 0,
    val totalSuperRaids: Int = 0,
    val totalSuperTackles: Int = 0,
    val totalAllOutConceded: Int = 0,
    
    // Volleyball specific stats
    val totalKills: Int = 0,
    val totalBlocks: Int = 0,
    val totalAces: Int = 0,
    val totalDigs: Int = 0,
    val totalAssists: Int = 0,
    
    // Common stats
    val manOfTheMatchCount: Int = 0,
    val bestPlayerCount: Int = 0,
    val createdAt: Date = Date(),
    val updatedAt: Date = Date()
) : Parcelable {
    
    fun getAge(): Int {
        val now = Date()
        val diff = now.time - dateOfBirth.time
        return (diff / (1000 * 60 * 60 * 24 * 365)).toInt()
    }
    
    fun getPlayerRole(): String {
        return when {
            isCaptain -> "Captain"
            isViceCaptain -> "Vice Captain"
            position.isNotEmpty() -> position
            else -> "Player"
        }
    }
    
    fun getCricketStatsString(): String {
        return "Matches: $totalMatches | Runs: $totalRuns | Wickets: $totalWickets | Avg: ${String.format("%.2f", average)}"
    }
    
    fun getKabaddiStatsString(): String {
        return "Matches: $totalMatches | Raid Points: $totalRaidPoints | Tackle Points: $totalTacklePoints"
    }
    
    fun getVolleyballStatsString(): String {
        return "Matches: $totalMatches | Kills: $totalKills | Blocks: $totalBlocks | Aces: $totalAces"
    }
}
