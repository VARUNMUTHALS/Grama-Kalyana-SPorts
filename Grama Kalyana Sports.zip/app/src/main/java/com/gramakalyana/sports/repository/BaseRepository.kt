package com.gramakalyana.sports.repository

import com.google.firebase.database.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

abstract class BaseRepository {
    
    protected val database: FirebaseDatabase = FirebaseDatabase.getInstance()
    
    /**
     * Get a reference to a database path
     */
    protected fun getReference(path: String): DatabaseReference {
        return database.getReference(path)
    }
    
    /**
     * Get a Flow that emits data changes from Firebase Realtime Database
     */
    protected fun <T> getDataFlow(
        reference: DatabaseReference,
        type: Class<T>
    ): Flow<Result<T?>> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                try {
                    val data = snapshot.getValue(type)
                    trySend(Result.success(data))
                } catch (e: Exception) {
                    trySend(Result.failure(e))
                }
            }
            
            override fun onCancelled(error: DatabaseError) {
                trySend(Result.failure(error.toException()))
            }
        }
        
        reference.addValueEventListener(listener)
        awaitClose { reference.removeEventListener(listener) }
    }
    
    /**
     * Get a Flow that emits a list of data changes from Firebase Realtime Database
     */
    protected fun <T> getListFlow(
        reference: DatabaseReference,
        type: Class<T>
    ): Flow<Result<List<T>>> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                try {
                    val list = mutableListOf<T>()
                    for (childSnapshot in snapshot.children) {
                        val data = childSnapshot.getValue(type)
                        if (data != null) {
                            list.add(data)
                        }
                    }
                    trySend(Result.success(list))
                } catch (e: Exception) {
                    trySend(Result.failure(e))
                }
            }
            
            override fun onCancelled(error: DatabaseError) {
                trySend(Result.failure(error.toException()))
            }
        }
        
        reference.addValueEventListener(listener)
        awaitClose { reference.removeEventListener(listener) }
    }
    
    /**
     * Set data to Firebase Realtime Database
     */
    protected suspend fun <T> setData(
        reference: DatabaseReference,
        data: T
    ): Result<Unit> {
        return try {
            reference.setValue(data).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Update data in Firebase Realtime Database
     */
    protected suspend fun updateData(
        reference: DatabaseReference,
        updates: Map<String, Any>
    ): Result<Unit> {
        return try {
            reference.updateChildren(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Delete data from Firebase Realtime Database
     */
    protected suspend fun deleteData(
        reference: DatabaseReference
    ): Result<Unit> {
        return try {
            reference.removeValue().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Push new data to Firebase Realtime Database
     */
    protected fun pushData(
        reference: DatabaseReference
    ): DatabaseReference {
        return reference.push()
    }
    
    /**
     * Get data once from Firebase Realtime Database
     */
    protected suspend fun <T> getDataOnce(
        reference: DatabaseReference,
        type: Class<T>
    ): Result<T?> {
        return try {
            val snapshot = reference.get().await()
            val data = snapshot.getValue(type)
            Result.success(data)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Query data with conditions
     */
    protected fun queryData(
        reference: DatabaseReference,
        orderByChild: String,
        equalTo: Any
    ): Query {
        return reference.orderByChild(orderByChild).equalTo(equalTo)
    }
    
    /**
     * Query data with range
     */
    protected fun queryDataRange(
        reference: DatabaseReference,
        orderByChild: String,
        startValue: Any,
        endValue: Any
    ): Query {
        return reference.orderByChild(orderByChild).startAt(startValue).endAt(endValue)
    }
    
    /**
     * Query data with limit
     */
    protected fun queryDataLimit(
        reference: DatabaseReference,
        limitToFirst: Int? = null,
        limitToLast: Int? = null
    ): Query {
        return when {
            limitToFirst != null -> reference.limitToFirst(limitToFirst)
            limitToLast != null -> reference.limitToLast(limitToLast)
            else -> reference
        }
    }
}
