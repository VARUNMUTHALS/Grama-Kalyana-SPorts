package com.gramakalyana.sports.models

enum class SportType(val displayName: String) {
    CRICKET("Cricket"),
    KABADDI("Kabaddi"),
    VOLLEYBALL("Volleyball")
}

fun getSportTypeFromDisplayName(displayName: String): SportType {
    return SportType.values().find { it.displayName == displayName } ?: SportType.CRICKET
}
