package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TournamentListScreenNew(
    onBack: () -> Unit,
    onCreateTournament: () -> Unit,
    onNavigateToTournament: (String) -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(150000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val liveGlow by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Tournament data
    var selectedFilter by remember { mutableStateOf(TournamentFilter.ALL) }
    val tournaments = remember {
        listOf(
            Tournament(
                id = "tournament_001",
                name = "Grama Kalyana Premier League",
                description = "Annual cricket championship with top teams",
                sportType = SportType.CRICKET,
                status = TournamentStatus.LIVE,
                totalTeams = 8,
                totalMatches = 28,
                completedMatches = 12,
                startDate = System.currentTimeMillis() - 86400000 * 7, // 7 days ago
                endDate = System.currentTimeMillis() + 86400000 * 14, // 14 days from now
                venue = "Grama Kalyana Sports Complex",
                format = TournamentFormat.LEAGUE,
                prizePool = "₹50,000"
            ),
            Tournament(
                id = "tournament_002",
                name = "Summer Kabaddi Championship",
                description = "Intense kabaddi competition",
                sportType = SportType.KABADDI,
                status = TournamentStatus.UPCOMING,
                totalTeams = 6,
                totalMatches = 15,
                completedMatches = 0,
                startDate = System.currentTimeMillis() + 86400000 * 3, // 3 days from now
                endDate = System.currentTimeMillis() + 86400000 * 10, // 10 days from now
                venue = "Community Sports Ground",
                format = TournamentFormat.KNOCKOUT,
                prizePool = "₹25,000"
            ),
            Tournament(
                id = "tournament_003",
                name = "Volleyball Cup 2024",
                description = "Beach volleyball tournament",
                sportType = SportType.VOLLEYBALL,
                status = TournamentStatus.COMPLETED,
                totalTeams = 10,
                totalMatches = 20,
                completedMatches = 20,
                startDate = System.currentTimeMillis() - 86400000 * 30, // 30 days ago
                endDate = System.currentTimeMillis() - 86400000 * 20, // 20 days ago
                venue = "Beach Sports Arena",
                format = TournamentFormat.KNOCKOUT,
                prizePool = "₹30,000"
            ),
            Tournament(
                id = "tournament_004",
                name = "Junior Cricket League",
                description = "Under-19 cricket tournament",
                sportType = SportType.CRICKET,
                status = TournamentStatus.UPCOMING,
                totalTeams = 12,
                totalMatches = 36,
                completedMatches = 0,
                startDate = System.currentTimeMillis() + 86400000 * 7, // 7 days from now
                endDate = System.currentTimeMillis() + 86400000 * 21, // 21 days from now
                venue = "Youth Sports Complex",
                format = TournamentFormat.LEAGUE,
                prizePool = "₹15,000"
            )
        )
    }
    
    val filteredTournaments = remember(selectedFilter, tournaments) {
        when (selectedFilter) {
            TournamentFilter.ALL -> tournaments
            TournamentFilter.LIVE -> tournaments.filter { it.status == TournamentStatus.LIVE }
            TournamentFilter.UPCOMING -> tournaments.filter { it.status == TournamentStatus.UPCOMING }
            TournamentFilter.COMPLETED -> tournaments.filter { it.status == TournamentStatus.COMPLETED }
        }
    }
    
    val listState = rememberLazyListState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Tournament list background
        TournamentListBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = liveGlow
        )
        
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            TournamentListHeader(
                onBack = onBack,
                onCreateTournament = onCreateTournament,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Filter tabs
            TournamentFilterTabs(
                selectedFilter = selectedFilter,
                onFilterSelected = { selectedFilter = it },
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Tournament list
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                state = listState,
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredTournaments) { tournament ->
                    TournamentCard(
                        tournament = tournament,
                        onClick = { onNavigateToTournament(tournament.id) },
                        liveGlow = liveGlow
                    )
                }
            }
        }
    }
}

@Composable
fun TournamentListBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle tournament background effect
        val positions = listOf(
            Offset(canvasWidth * 0.1f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.1f, canvasHeight * 0.9f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.9f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.5f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TournamentListHeader(
    onBack: () -> Unit,
    onCreateTournament: () -> Unit,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val buttonPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Text(
            text = "TOURNAMENTS",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                color = NeonOrange,
                letterSpacing = 2.sp
            )
        )
        
        Spacer(modifier = Modifier.weight(1f))
        
        Button(
            onClick = onCreateTournament,
            modifier = Modifier
                .scale(buttonPulse),
            colors = ButtonDefaults.buttonColors(
                containerColor = NeonOrange
            ),
            elevation = ButtonDefaults.buttonElevation(
                defaultElevation = 8.dp
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Create Tournament",
                tint = White,
                modifier = Modifier.size(20.dp)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = "CREATE",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = White,
                    letterSpacing = 1.sp
                )
            )
        }
    }
}

@Composable
fun TournamentFilterTabs(
    selectedFilter: TournamentFilter,
    onFilterSelected: (TournamentFilter) -> Unit,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val tabGlow by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        TournamentFilter.values().forEach { filter ->
            FilterTab(
                text = filter.name,
                isSelected = selectedFilter == filter,
                onClick = { onFilterSelected(filter) },
                tabGlow = if (selectedFilter == filter && filter == TournamentFilter.LIVE) tabGlow else 1f,
                liveGlow = liveGlow
            )
        }
    }
}

@Composable
fun FilterTab(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    tabGlow: Float,
    liveGlow: Float
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .scale(tabGlow),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) NeonOrange else MatteBlackLight,
            contentColor = if (isSelected) White else White80
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = if (isSelected) 8.dp else 4.dp
        ),
        shape = RoundedCornerShape(20.dp),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )
        
        if (isSelected && text == "LIVE") {
            Spacer(modifier = Modifier.width(8.dp))
            
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(LiveRed, RoundedCornerShape(3.dp))
                    .scale(1f + liveGlow * 0.5f)
            )
        }
    }
}

@Composable
fun TournamentCard(
    tournament: Tournament,
    onClick: () -> Unit,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val cardPulse by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .scale(if (tournament.status == TournamentStatus.LIVE) cardPulse else 1f),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = when (tournament.status) {
                TournamentStatus.LIVE -> 12.dp
                TournamentStatus.UPCOMING -> 8.dp
                else -> 6.dp
            }
        ),
        border = when (tournament.status) {
            TournamentStatus.LIVE -> androidx.compose.foundation.BorderStroke(
                width = 2.dp,
                color = LiveRed.copy(alpha = liveGlow)
            )
            else -> null
        },
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header with status and sport type
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SportTypeBadge(
                        sportType = tournament.sportType,
                        isLive = tournament.status == TournamentStatus.LIVE,
                        size = SportBadgeSize.SMALL
                    )
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    Text(
                        text = tournament.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (tournament.status == TournamentStatus.LIVE) NeonOrange else White
                        ),
                        maxLines = 2
                    )
                }
                
                TournamentStatusBadge(
                    status = tournament.status,
                    liveGlow = liveGlow
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Description
            Text(
                text = tournament.description,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White80,
                    fontWeight = FontWeight.Medium
                ),
                maxLines = 2
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Tournament details grid
            TournamentDetailsGrid(tournament)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Progress bar for live/upcoming tournaments
            if (tournament.status != TournamentStatus.COMPLETED) {
                TournamentProgressBar(tournament)
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Footer with dates and venue
            TournamentFooter(tournament)
        }
    }
}

@Composable
fun TournamentStatusBadge(
    status: TournamentStatus,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val statusPulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(
                color = status.getDisplayColor().copy(alpha = 0.2f),
                shape = RoundedCornerShape(12.dp)
            )
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .scale(if (status == TournamentStatus.LIVE) statusPulse else 1f)
    ) {
        if (status == TournamentStatus.LIVE) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(LiveRed, RoundedCornerShape(3.dp))
                    .scale(1f + liveGlow * 0.5f)
            )
            
            Spacer(modifier = Modifier.width(6.dp))
        }
        
        Text(
            text = status.getDisplayText(),
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Black,
                color = status.getDisplayColor(),
                letterSpacing = 1.sp
            )
        )
    }
}

@Composable
fun TournamentDetailsGrid(
    tournament: Tournament
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // First row: Teams, Matches, Format
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TournamentDetailItem(
                label = "TEAMS",
                value = tournament.totalTeams.toString(),
                color = NeonOrange
            )
            
            TournamentDetailItem(
                label = "MATCHES",
                value = "${tournament.completedMatches}/${tournament.totalMatches}",
                color = NeonGreen
            )
            
            TournamentDetailItem(
                label = "FORMAT",
                value = tournament.format.getDisplayText(),
                color = VolleyballBlue
            )
        }
        
        // Second row: Prize pool
        if (tournament.prizePool.isNotEmpty()) {
            TournamentDetailItem(
                label = "PRIZE POOL",
                value = tournament.prizePool,
                color = NeonYellow
            )
        }
    }
}

@Composable
fun TournamentDetailItem(
    label: String,
    value: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = White60,
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.sp
            )
        )
        
        Spacer(modifier = Modifier.height(4.dp))
        
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = color,
                fontFamily = FontFamily.SansSerif
            )
        )
    }
}

@Composable
fun TournamentProgressBar(
    tournament: Tournament
) {
    val progress = tournament.completedMatches.toFloat() / tournament.totalMatches.toFloat()
    
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "PROGRESS",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = White60,
                    letterSpacing = 1.sp
                )
            )
            
            Text(
                text = "${(progress * 100).toInt()}%",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .background(
                    color = White20,
                    shape = RoundedCornerShape(3.dp)
                )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress)
                    .fillMaxHeight()
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                NeonOrangeDark,
                                NeonOrange,
                                NeonOrangeLight
                            )
                        ),
                        shape = RoundedCornerShape(3.dp)
                    )
            )
        }
    }
}

@Composable
fun TournamentFooter(
    tournament: Tournament
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarToday,
                    contentDescription = null,
                    tint = White60,
                    modifier = Modifier.size(16.dp)
                )
                
                Spacer(modifier = Modifier.width(6.dp))
                
                Text(
                    text = "${tournament.getFormattedStartDate()} - ${tournament.getFormattedEndDate()}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = White80,
                        fontWeight = FontWeight.Medium
                    )
                )
            }
        }
        
        Spacer(modifier = Modifier.height(6.dp))
        
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = null,
                tint = White60,
                modifier = Modifier.size(16.dp)
            )
            
            Spacer(modifier = Modifier.width(6.dp))
            
            Text(
                text = tournament.venue,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = White80,
                    fontWeight = FontWeight.Medium
                ),
                maxLines = 1
            )
        }
    }
}

// Extension functions for Tournament
fun Tournament.getFormattedStartDate(): String {
    val date = java.util.Date(startDate)
    val formatter = java.text.SimpleDateFormat("dd MMM", java.util.Locale.getDefault())
    return formatter.format(date)
}

fun Tournament.getFormattedEndDate(): String {
    val date = java.util.Date(endDate)
    val formatter = java.text.SimpleDateFormat("dd MMM", java.util.Locale.getDefault())
    return formatter.format(date)
}

fun TournamentFormat.getDisplayText(): String {
    return when (this) {
        TournamentFormat.LEAGUE -> "LEAGUE"
        TournamentFormat.KNOCKOUT -> "KNOCKOUT"
        TournamentFormat.ROUND_ROBIN -> "ROUND ROBIN"
        TournamentFormat.DOUBLE_ELIMINATION -> "DOUBLE ELIM"
    }
}
