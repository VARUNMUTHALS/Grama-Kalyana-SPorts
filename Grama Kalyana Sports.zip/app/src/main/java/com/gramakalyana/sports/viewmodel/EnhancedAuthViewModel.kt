package com.gramakalyana.sports.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.common.api.ApiException
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider
import com.gramakalyana.sports.firebase.auth.EnhancedAuthRepository
import com.gramakalyana.sports.firebase.auth.EnhancedAuthenticationState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Enhanced Authentication ViewModel - Handles multiple authentication methods
 * Supports Email/Password, Phone Number, and Google Sign-In
 */
class EnhancedAuthViewModel(application: Application) : AndroidViewModel(application) {
    
    private val enhancedAuthRepository = EnhancedAuthRepository.getInstance()
    private val context = application.applicationContext
    
    init {
        // Initialize Google Auth with context
        enhancedAuthRepository.initializeGoogleAuth(context)
    }
    
    // Authentication state
    private val _authenticationState = MutableStateFlow<EnhancedAuthenticationState>(
        EnhancedAuthenticationState.Unauthenticated
    )
    val authenticationState: StateFlow<EnhancedAuthenticationState> = _authenticationState.asStateFlow()
    
    // Loading states
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    // Error states
    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()
    
    // Success messages
    private val _successMessage = MutableStateFlow<String?>(null)
    val successMessage: StateFlow<String?> = _successMessage.asStateFlow()
    
    // Current user
    private val _currentUser = MutableStateFlow<FirebaseUser?>(null)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()
    
    // Phone auth states
    private val _verificationId = MutableStateFlow<String?>(null)
    val verificationId: StateFlow<String?> = _verificationId.asStateFlow()
    
    private val _resendToken = MutableStateFlow<PhoneAuthProvider.ForceResendingToken?>(null)
    val resendToken: StateFlow<PhoneAuthProvider.ForceResendingToken?> = _resendToken.asStateFlow()
    
    private val _isCodeSent = MutableStateFlow(false)
    val isCodeSent: StateFlow<Boolean> = _isCodeSent.asStateFlow()
    
    // Google Sign-In states
    private val _googleSignInClient = MutableStateFlow(enhancedAuthRepository.getGoogleSignInClient())
    val googleSignInClient: StateFlow<com.google.android.gms.auth.api.signin.GoogleSignInClient?> = _googleSignInClient.asStateFlow()
    
    init {
        // Observe authentication state changes
        viewModelScope.launch {
            enhancedAuthRepository.authenticationStateFlow.collect { state ->
                _authenticationState.value = state
                when (state) {
                    is EnhancedAuthenticationState.Authenticated -> {
                        _currentUser.value = state.user
                        _errorMessage.value = null
                    }
                    EnhancedAuthenticationState.Unauthenticated -> {
                        _currentUser.value = null
                    }
                }
            }
        }
    }
    
    // Email/Password Authentication
    
    /**
     * Sign up with email and password
     */
    fun signUpWithEmail(email: String, password: String, name: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            _successMessage.value = null
            
            enhancedAuthRepository.signUpWithEmail(email, password, name)
                .onSuccess {
                    _isLoading.value = false
                    _successMessage.value = "Account created successfully!"
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Sign in with email and password
     */
    fun signInWithEmail(email: String, password: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            _successMessage.value = null
            
            enhancedAuthRepository.signInWithEmail(email, password)
                .onSuccess {
                    _isLoading.value = false
                    _successMessage.value = "Signed in successfully!"
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    // Phone Authentication
    
    /**
     * Send verification code to phone number
     */
    fun sendPhoneVerificationCode(phoneNumber: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            _successMessage.value = null
            
            val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    viewModelScope.launch {
                        _isLoading.value = false
                        _isCodeSent.value = false
                        enhancedAuthRepository.signInWithPhoneCredential(credential)
                            .onSuccess {
                                _successMessage.value = "Phone number verified successfully!"
                            }
                            .onFailure { exception ->
                                _errorMessage.value = exception.message
                            }
                    }
                }
                
                override fun onVerificationFailed(e: FirebaseException) {
                    _isLoading.value = false
                    _isCodeSent.value = false
                    _errorMessage.value = when {
                        e.message?.contains("invalid") == true -> "Invalid phone number format"
                        e.message?.contains("quota") == true -> "SMS quota exceeded. Try again later"
                        e.message?.contains("blocked") == true -> "Device blocked. Contact support"
                        else -> "Verification failed: ${e.message}"
                    }
                }
                
                override fun onCodeSent(
                    verificationId: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    _verificationId.value = verificationId
                    _resendToken.value = token
                    _isCodeSent.value = true
                    _isLoading.value = false
                    _successMessage.value = "Verification code sent to $phoneNumber"
                }
                
                override fun onCodeAutoRetrievalTimeOut(verificationId: String) {
                    _isLoading.value = false
                    _errorMessage.value = "Auto-retrieval timed out. Please enter the code manually."
                }
            }
            
            enhancedAuthRepository.sendPhoneVerificationCode(phoneNumber, callbacks)
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Verify phone number with code
     */
    fun verifyPhoneNumber(code: String) {
        val verificationId = _verificationId.value
        if (verificationId == null) {
            _errorMessage.value = "No verification ID available"
            return
        }
        
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            try {
                val credential = enhancedAuthRepository.createPhoneCredential(verificationId, code)
                enhancedAuthRepository.signInWithPhoneCredential(credential)
                    .onSuccess {
                        _isLoading.value = false
                        _isCodeSent.value = false
                        _successMessage.value = "Phone number verified successfully!"
                    }
                    .onFailure { exception ->
                        _isLoading.value = false
                        _errorMessage.value = when {
                            exception.message?.contains("invalid") == true -> "Invalid verification code"
                            exception.message?.contains("expired") == true -> "Verification code expired. Try again"
                            else -> "Verification failed: ${exception.message}"
                        }
                    }
            } catch (e: Exception) {
                _isLoading.value = false
                _errorMessage.value = "Error creating credential: ${e.message}"
            }
        }
    }
    
    /**
     * Resend verification code
     */
    fun resendVerificationCode(phoneNumber: String) {
        val token = _resendToken.value
        if (token == null) {
            _errorMessage.value = "Cannot resend code. Please start over."
            return
        }
        
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    viewModelScope.launch {
                        _isLoading.value = false
                        enhancedAuthRepository.signInWithPhoneCredential(credential)
                            .onSuccess {
                                _successMessage.value = "Phone number verified successfully!"
                            }
                            .onFailure { exception ->
                                _errorMessage.value = exception.message
                            }
                    }
                }
                
                override fun onVerificationFailed(e: FirebaseException) {
                    _isLoading.value = false
                    _errorMessage.value = "Resend failed: ${e.message}"
                }
                
                override fun onCodeSent(
                    verificationId: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    _verificationId.value = verificationId
                    _resendToken.value = token
                    _isLoading.value = false
                    _successMessage.value = "Verification code resent!"
                }
                
                override fun onCodeAutoRetrievalTimeOut(verificationId: String) {
                    _isLoading.value = false
                }
            }
            
            enhancedAuthRepository.resendPhoneVerificationCode(phoneNumber, token, callbacks)
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    // Google Sign-In
    
    /**
     * Sign in with Google
     */
    fun signInWithGoogle(account: GoogleSignInAccount) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            _successMessage.value = null
            
            enhancedAuthRepository.signInWithGoogle(account)
                .onSuccess {
                    _isLoading.value = false
                    _successMessage.value = "Signed in with Google successfully!"
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = when {
                        exception is ApiException -> {
                            when (exception.statusCode) {
                                7 -> "Network error. Check your connection."
                                10 -> "Developer error. Check configuration."
                                16 -> "Sign-in was canceled."
                                12501 -> "Sign-in failed. Try again."
                                else -> "Google Sign-In error: ${exception.statusCode}"
                            }
                        }
                        else -> "Google Sign-In failed: ${exception.message}"
                    }
                }
        }
    }
    
    /**
     * Silent Google Sign-In
     */
    fun silentGoogleSignIn() {
        viewModelScope.launch {
            enhancedAuthRepository.silentGoogleSignIn()
                .onSuccess { account ->
                    if (account != null) {
                        signInWithGoogle(account)
                    }
                }
                .onFailure { exception ->
                    // Silent sign-in failed, user needs to sign in manually
                    _errorMessage.value = "Please sign in manually"
                }
        }
    }
    
    // Common Authentication Methods
    
    /**
     * Send password reset email
     */
    fun sendPasswordResetEmail(email: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            enhancedAuthRepository.sendPasswordResetEmail(email)
                .onSuccess {
                    _isLoading.value = false
                    _successMessage.value = "Password reset email sent successfully"
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Update user profile
     */
    fun updateProfile(name: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            enhancedAuthRepository.updateProfile(name)
                .onSuccess {
                    _isLoading.value = false
                    _successMessage.value = "Profile updated successfully"
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Update user email
     */
    fun updateEmail(newEmail: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            enhancedAuthRepository.updateEmail(newEmail)
                .onSuccess {
                    _isLoading.value = false
                    _successMessage.value = "Email updated successfully"
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Update user password
     */
    fun updatePassword(newPassword: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            enhancedAuthRepository.updatePassword(newPassword)
                .onSuccess {
                    _isLoading.value = false
                    _successMessage.value = "Password updated successfully"
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Delete user account
     */
    fun deleteAccount() {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            enhancedAuthRepository.deleteAccount()
                .onSuccess {
                    _isLoading.value = false
                    _successMessage.value = "Account deleted successfully"
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Sign out current user
     */
    fun signOut() {
        viewModelScope.launch {
            _isLoading.value = true
            
            enhancedAuthRepository.signOut()
                .onSuccess {
                    _isLoading.value = false
                    _successMessage.value = "Signed out successfully"
                    // Reset states
                    _verificationId.value = null
                    _resendToken.value = null
                    _isCodeSent.value = false
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Get authentication method
     */
    fun getAuthMethod(): String {
        return enhancedAuthRepository.getAuthMethod()
    }
    
    /**
     * Check if user is authenticated
     */
    fun isUserAuthenticated(): Boolean {
        return enhancedAuthRepository.isUserAuthenticated
    }
    
    /**
     * Get current user ID
     */
    fun getCurrentUserId(): String? {
        return enhancedAuthRepository.currentUser?.uid
    }
    
    /**
     * Clear error message
     */
    fun clearError() {
        _errorMessage.value = null
    }
    
    /**
     * Clear success message
     */
    fun clearSuccess() {
        _successMessage.value = null
    }
    
    /**
     * Reset phone auth state
     */
    fun resetPhoneAuthState() {
        _verificationId.value = null
        _resendToken.value = null
        _isCodeSent.value = false
        _errorMessage.value = null
        _successMessage.value = null
    }
}
