package com.gramakalyana.sports

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.database.FirebaseDatabase
import com.gramakalyana.sports.firebase.FirebaseManager
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

@HiltAndroidApp
class SportsApplication : Application() {
    
    override fun onCreate() {
        super.onCreate()
        
        // Initialize Firebase
        initializeFirebase()
        
        // Initialize logging
        initializeLogging()
    }
    
    private fun initializeFirebase() {
        try {
            // Initialize Firebase
            FirebaseApp.initializeApp(this)
            
            // Initialize Firebase Manager
            FirebaseManager.initialize()
            
            // Enable Firebase Crashlytics
            FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(!BuildConfig.DEBUG)
            
            // Configure Firebase Database for offline persistence
            FirebaseDatabase.getInstance().setPersistenceEnabled(true)
            
            // Set database URL if needed
            // FirebaseDatabase.getInstance().reference.keepSynced(true)
            
            Timber.d("Firebase initialized successfully")
        } catch (e: Exception) {
            Timber.e(e, "Failed to initialize Firebase")
        }
    }
    
    private fun initializeLogging() {
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        } else {
            // Plant a tree that logs to Crashlytics in release builds
            Timber.plant(object : Timber.Tree() {
                override fun isLoggable(tag: String?, priority: Int): Boolean {
                    return priority >= android.util.Log.INFO
                }
                
                override fun log(priority: Int, tag: String?, message: String, t: Throwable?) {
                    if (priority == android.util.Log.ERROR && t != null) {
                        FirebaseCrashlytics.getInstance().recordException(t)
                    }
                    FirebaseCrashlytics.getInstance().log(message)
                }
            })
        }
    }
}
