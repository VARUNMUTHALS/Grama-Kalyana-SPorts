package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScorerControlScreen(
    matchId: String,
    onBack: () -> Unit,
    onEndMatch: () -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(80000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val liveGlow by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val buttonPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Match state
    var currentMatch by remember {
        mutableStateOf(
            Match(
                id = matchId,
                teamAName = "Royal Warriors",
                teamBName = "Thunder Strikers",
                sportType = SportType.CRICKET,
                status = MatchStatus.LIVE,
                cricketScore = CricketScore(
                    teamARuns = 156,
                    teamAWickets = 4,
                    teamAOvers = 18.5,
                    teamBRuns = 89,
                    teamBWickets = 2,
                    teamBOvers = 12.3
                )
            )
        )
    }
    
    var commentary by remember { mutableStateOf("") }
    var lastAction by remember { mutableStateOf<String?>(null) }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Scorer background
        ScorerBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = liveGlow
        )
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header with match info and back button
            ScorerHeader(
                match = currentMatch,
                onBack = onBack,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Score display
            ScorerScoreDisplay(
                match = currentMatch,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Sport-specific controls
            when (currentMatch.sportType) {
                SportType.CRICKET -> CricketScorerControls(
                    match = currentMatch,
                    onScoreUpdate = { updatedMatch ->
                        currentMatch = updatedMatch
                        lastAction = "Score updated"
                    },
                    buttonPulse = buttonPulse
                )
                SportType.KABADDI -> KabaddiScorerControls(
                    match = currentMatch,
                    onScoreUpdate = { updatedMatch ->
                        currentMatch = updatedMatch
                        lastAction = "Score updated"
                    },
                    buttonPulse = buttonPulse
                )
                SportType.VOLLEYBALL -> VolleyballScorerControls(
                    match = currentMatch,
                    onScoreUpdate = { updatedMatch ->
                        currentMatch = updatedMatch
                        lastAction = "Score updated"
                    },
                    buttonPulse = buttonPulse
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Commentary input
            CommentaryInput(
                commentary = commentary,
                onCommentaryChange = { commentary = it },
                onSubmit = {
                    lastAction = "Commentary added"
                    commentary = ""
                }
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Action buttons
            ScorerActionButtons(
                onUndo = {
                    lastAction = "Action undone"
                },
                onEndMatch = onEndMatch,
                buttonPulse = buttonPulse
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Last action feedback
            lastAction?.let { action ->
                ActionFeedback(
                    action = action,
                    onDismiss = { lastAction = null }
                )
            }
        }
    }
}

@Composable
fun ScorerBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle stadium effect for scorer
        val positions = listOf(
            Offset(canvasWidth * 0.1f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.1f, canvasHeight * 0.9f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.9f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.3f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScorerHeader(
    match: Match,
    onBack: () -> Unit,
    liveGlow: Float
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(56.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange,
                modifier = Modifier.size(28.dp)
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .background(LiveRed, RoundedCornerShape(6.dp))
                        .scale(1f + liveGlow * 0.3f)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = "LIVE SCORER",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = LiveRed,
                        letterSpacing = 2.sp
                    )
                )
            }
            
            Text(
                text = "${match.teamAName} vs ${match.teamBName}",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White80,
                    fontWeight = FontWeight.Medium
                )
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        // Match timer
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "OVERS",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = White60,
                    letterSpacing = 1.sp
                )
            )
            
            Text(
                text = match.cricketScore?.teamAOvers?.toString() ?: "0.0",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Black,
                    color = NeonOrange,
                    fontFamily = FontFamily.SansSerif
                )
            )
        }
    }
}

@Composable
fun ScorerScoreDisplay(
    match: Match,
    liveGlow: Float
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Team A score
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = match.teamAName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange
                    )
                )
                
                Text(
                    text = "${match.cricketScore?.teamARuns}/${match.cricketScore?.teamAWickets}",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black,
                        color = NeonOrange,
                        fontFamily = FontFamily.SansSerif
                    ),
                    modifier = Modifier.scale(1f + liveGlow * 0.05f)
                )
            }
            
            // VS
            Text(
                text = "VS",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = White60,
                    letterSpacing = 4.sp
                )
            )
            
            // Team B score
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = match.teamBName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = White
                    )
                )
                
                Text(
                    text = "${match.cricketScore?.teamBRuns}/${match.cricketScore?.teamBWickets}",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black,
                        color = White,
                        fontFamily = FontFamily.SansSerif
                    )
                )
            }
        }
    }
}

@Composable
fun CricketScorerControls(
    match: Match,
    onScoreUpdate: (Match) -> Unit,
    buttonPulse: Float
) {
    val cricketScore = match.cricketScore ?: return
    
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Runs buttons
        Text(
            text = "RUNS",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = NeonOrange
            )
        )
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScorerButton(
                text = "0",
                onClick = { /* Add dot ball */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse,
                color = White20
            )
            
            ScorerButton(
                text = "1",
                onClick = { /* Add single */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse
            )
            
            ScorerButton(
                text = "2",
                onClick = { /* Add double */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse
            )
            
            ScorerButton(
                text = "3",
                onClick = { /* Add triple */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse
            )
            
            ScorerButton(
                text = "4",
                onClick = { /* Add boundary */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse
            )
            
            ScorerButton(
                text = "6",
                onClick = { /* Add six */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse,
                isSpecial = true
            )
        }
        
        // Extras and wickets
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScorerButton(
                text = "WIDE",
                onClick = { /* Add wide */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse,
                color = NeonYellow
            )
            
            ScorerButton(
                text = "NO BALL",
                onClick = { /* Add no ball */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse,
                color = NeonYellow
            )
            
            ScorerButton(
                text = "WICKET",
                onClick = { /* Add wicket */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse,
                color = NeonRed,
                isSpecial = true
            )
        }
    }
}

@Composable
fun KabaddiScorerControls(
    match: Match,
    onScoreUpdate: (Match) -> Unit,
    buttonPulse: Float
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "RAID POINTS",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = NeonOrange
            )
        )
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScorerButton(
                text = "0",
                onClick = { /* Empty raid */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse,
                color = White20
            )
            
            ScorerButton(
                text = "1",
                onClick = { /* Single point */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse
            )
            
            ScorerButton(
                text = "2",
                onClick = { /* Double points */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse
            )
            
            ScorerButton(
                text = "3",
                onClick = { /* Triple points */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse,
                isSpecial = true
            )
            
            ScorerButton(
                text = "4",
                onClick = { /* All out */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse,
                color = NeonRed,
                isSpecial = true
            )
        }
        
        // Tackle points
        Text(
            text = "TACKLE POINTS",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = NeonOrange
            )
        )
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScorerButton(
                text = "TACKLE",
                onClick = { /* Add tackle */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse
            )
            
            ScorerButton(
                text = "SUPER TACKLE",
                onClick = { /* Add super tackle */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse,
                color = NeonGreen,
                isSpecial = true
            )
        }
    }
}

@Composable
fun VolleyballScorerControls(
    match: Match,
    onScoreUpdate: (Match) -> Unit,
    buttonPulse: Float
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "POINTS",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = NeonOrange
            )
        )
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScorerButton(
                text = "TEAM A +1",
                onClick = { /* Add point to Team A */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse
            )
            
            ScorerButton(
                text = "TEAM B +1",
                onClick = { /* Add point to Team B */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse
            )
        }
        
        // Set controls
        Text(
            text = "SET CONTROL",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = NeonOrange
            )
        )
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScorerButton(
                text = "TEAM A SET",
                onClick = { /* Team A wins set */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse,
                color = NeonGreen,
                isSpecial = true
            )
            
            ScorerButton(
                text = "TEAM B SET",
                onClick = { /* Team B wins set */ },
                modifier = Modifier.weight(1f),
                buttonPulse = buttonPulse,
                color = NeonGreen,
                isSpecial = true
            )
        }
    }
}

@Composable
fun ScorerButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    buttonPulse: Float,
    color: Color = NeonOrange,
    isSpecial: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition()
    val specialGlow by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Button(
        onClick = onClick,
        modifier = modifier
            .height(80.dp)
            .scale(if (isSpecial) specialGlow else buttonPulse),
        colors = ButtonDefaults.buttonColors(
            containerColor = color
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = if (isSpecial) 12.dp else 8.dp,
            pressedElevation = if (isSpecial) 16.dp else 12.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = White,
                letterSpacing = 1.sp
            ),
            textAlign = TextAlign.Center
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommentaryInput(
    commentary: String,
    onCommentaryChange: (String) -> Unit,
    onSubmit: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "QUICK COMMENTARY",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom
            ) {
                OutlinedTextField(
                    value = commentary,
                    onValueChange = onCommentaryChange,
                    placeholder = {
                        Text(
                            text = "Add quick commentary...",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = White40
                            )
                        )
                    },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonOrange,
                        unfocusedBorderColor = White20,
                        focusedTextColor = White,
                        unfocusedTextColor = White,
                        cursorColor = NeonOrange
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                
                Spacer(modifier = Modifier.width(12.dp))
                
                IconButton(
                    onClick = onSubmit,
                    modifier = Modifier
                        .background(NeonOrange, RoundedCornerShape(12.dp))
                        .size(56.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ScorerActionButtons(
    onUndo: () -> Unit,
    onEndMatch: () -> Unit,
    buttonPulse: Float
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Undo button
        Button(
            onClick = onUndo,
            modifier = Modifier
                .weight(1f)
                .height(64.dp)
                .scale(buttonPulse),
            colors = ButtonDefaults.buttonColors(
                containerColor = NeonYellow
            ),
            elevation = ButtonDefaults.buttonElevation(
                defaultElevation = 8.dp
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Undo,
                contentDescription = "Undo",
                tint = White,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = "UNDO",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = White,
                    letterSpacing = 1.sp
                )
            )
        }
        
        // End match button
        Button(
            onClick = onEndMatch,
            modifier = Modifier
                .weight(1f)
                .height(64.dp)
                .scale(buttonPulse),
            colors = ButtonDefaults.buttonColors(
                containerColor = NeonRed
            ),
            elevation = ButtonDefaults.buttonElevation(
                defaultElevation = 8.dp
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Stop,
                contentDescription = "End Match",
                tint = White,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = "END MATCH",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = White,
                    letterSpacing = 1.sp
                )
            )
        }
    }
}

@Composable
fun ActionFeedback(
    action: String,
    onDismiss: () -> Unit
) {
    LaunchedEffect(key1 = action) {
        kotlinx.coroutines.GlobalScope.launch {
            delay(2000)
            onDismiss()
        }
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = NeonGreen.copy(alpha = 0.2f)
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = NeonGreen,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Text(
                text = action,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Medium,
                    color = NeonGreen
                )
            )
        }
    }
}
