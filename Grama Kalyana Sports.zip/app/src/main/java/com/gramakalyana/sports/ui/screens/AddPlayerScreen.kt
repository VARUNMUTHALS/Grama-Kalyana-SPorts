package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPlayerScreen(
    teamId: String,
    onBack: () -> Unit,
    onAddPlayer: (Player) -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(120000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Form states
    var playerName by remember { mutableStateOf("") }
    var jerseyNumber by remember { mutableStateOf("") }
    var playerRole by remember { mutableStateOf(PlayerRole.BATSMAN) }
    var age by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Add player background
        AddPlayerBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = glowPulse
        )
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Header
            AddPlayerHeader(
                onBack = onBack,
                glowPulse = glowPulse
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Form content
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MatteBlackLight
                ),
                elevation = CardDefaults.cardElevation(
                    defaultElevation = 8.dp
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    // Player name
                    PlayerTextField(
                        value = playerName,
                        onValueChange = { 
                            playerName = it
                            errorMessage = null
                        },
                        label = "Player Name",
                        placeholder = "Enter player name",
                        icon = Icons.Default.Person,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next,
                        onImeAction = {
                            focusManager.moveFocus(FocusDirection.Down)
                        },
                        errorMessage = if (playerName.isNotEmpty() && playerName.length < 3)
                            "Player name must be at least 3 characters" else null
                    )
                    
                    // Jersey number
                    PlayerTextField(
                        value = jerseyNumber,
                        onValueChange = { 
                            jerseyNumber = it
                            errorMessage = null
                        },
                        label = "Jersey Number",
                        placeholder = "Enter jersey number",
                        icon = Icons.Default.Numbers,
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Next,
                        onImeAction = {
                            focusManager.moveFocus(FocusDirection.Down)
                        },
                        errorMessage = if (jerseyNumber.isNotEmpty() && (jerseyNumber.toIntOrNull() ?: 0) < 1)
                            "Jersey number must be positive" else null
                    )
                    
                    // Player role selection
                    PlayerRoleSelector(
                        selectedRole = playerRole,
                        onRoleSelected = { playerRole = it },
                        glowPulse = glowPulse
                    )
                    
                    // Age
                    PlayerTextField(
                        value = age,
                        onValueChange = { 
                            age = it
                            errorMessage = null
                        },
                        label = "Age",
                        placeholder = "Enter player age",
                        icon = Icons.Default.Cake,
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Next,
                        onImeAction = {
                            focusManager.moveFocus(FocusDirection.Down)
                        },
                        errorMessage = if (age.isNotEmpty() && (age.toIntOrNull() ?: 0) < 10)
                            "Age must be at least 10" else null
                    )
                    
                    // Phone number
                    PlayerTextField(
                        value = phoneNumber,
                        onValueChange = { 
                            phoneNumber = it
                            errorMessage = null
                        },
                        label = "Phone Number",
                        placeholder = "Enter phone number",
                        icon = Icons.Default.Phone,
                        keyboardType = KeyboardType.Phone,
                        imeAction = ImeAction.Next,
                        onImeAction = {
                            focusManager.moveFocus(FocusDirection.Down)
                        },
                        errorMessage = if (phoneNumber.isNotEmpty() && phoneNumber.length < 10)
                            "Phone number must be at least 10 digits" else null
                    )
                    
                    // Email (optional)
                    PlayerTextField(
                        value = email,
                        onValueChange = { 
                            email = it
                            errorMessage = null
                        },
                        label = "Email (Optional)",
                        placeholder = "Enter email address",
                        icon = Icons.Default.Email,
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Done,
                        onImeAction = {
                            focusManager.clearFocus()
                        },
                        errorMessage = if (email.isNotEmpty() && !isValidEmail(email))
                            "Please enter a valid email" else null
                    )
                    
                    Spacer(modifier = Modifier.height(20.dp))
                    
                    // Error message
                    errorMessage?.let {
                        Text(
                            text = it,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NeonRed
                            ),
                            modifier = Modifier.padding(bottom = 16.dp)
                        )
                    }
                    
                    // Add player button
                    AddPlayerButton(
                        onClick = {
                            if (validatePlayerForm(playerName, jerseyNumber, age, phoneNumber)) {
                                isLoading = true
                                val player = Player(
                                    id = "",
                                    name = playerName,
                                    teamId = teamId,
                                    jerseyNumber = jerseyNumber.toIntOrNull() ?: 0,
                                    role = playerRole,
                                    age = age.toIntOrNull() ?: 0,
                                    phoneNumber = phoneNumber,
                                    email = email.ifEmpty { null },
                                    totalMatches = 0,
                                    totalRuns = 0,
                                    totalWickets = 0,
                                    totalPoints = 0,
                                    status = PlayerStatus.ACTIVE,
                                    joinDate = System.currentTimeMillis()
                                )
                                onAddPlayer(player)
                            }
                        },
                        isLoading = isLoading,
                        glowPulse = glowPulse
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun AddPlayerBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle background effect
        val positions = listOf(
            Offset(canvasWidth * 0.15f, canvasHeight * 0.15f),
            Offset(canvasWidth * 0.85f, canvasHeight * 0.15f),
            Offset(canvasWidth * 0.15f, canvasHeight * 0.85f),
            Offset(canvasWidth * 0.85f, canvasHeight * 0.85f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.4f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center pattern
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        drawCircle(
            color = NeonOrange.copy(alpha = glowAlpha * 0.05f),
            radius = min(canvasWidth, canvasHeight) * 0.2f,
            center = Offset(centerX, centerY)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPlayerHeader(
    onBack: () -> Unit,
    glowPulse: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val logoPulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "ADD PLAYER",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange,
                    letterSpacing = 2.sp
                )
            )
            
            Text(
                text = "Register new player",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White80
                )
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    color = NeonOrange.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(20.dp)
                )
                .scale(logoPulse),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.PersonAdd,
                contentDescription = "Player",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    keyboardType: KeyboardType,
    imeAction: ImeAction,
    onImeAction: () -> Unit,
    errorMessage: String? = null
) {
    Column {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White80
                    )
                )
            },
            placeholder = {
                Text(
                    text = placeholder,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White40
                    )
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = NeonOrange,
                    modifier = Modifier.size(24.dp)
                )
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = keyboardType,
                imeAction = imeAction
            ),
            keyboardActions = KeyboardActions(
                onAny = { onImeAction() }
            ),
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonOrange,
                unfocusedBorderColor = White20,
                focusedTextColor = White,
                unfocusedTextColor = White,
                cursorColor = NeonOrange,
                errorBorderColor = NeonRed,
                errorTextColor = NeonRed
            ),
            shape = RoundedCornerShape(12.dp),
            isError = errorMessage != null
        )
        
        errorMessage?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NeonRed
                ),
                modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
        }
    }
}

@Composable
fun PlayerRoleSelector(
    selectedRole: PlayerRole,
    onRoleSelected: (PlayerRole) -> Unit,
    glowPulse: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val selectorPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Column {
        Text(
            text = "Player Role",
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = White80
            )
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .scale(selectorPulse),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PlayerRole.values().forEach { role ->
                PlayerRoleChip(
                    role = role,
                    isSelected = selectedRole == role,
                    onClick = { onRoleSelected(role) },
                    glowPulse = glowPulse
                )
            }
        }
    }
}

@Composable
fun PlayerRoleChip(
    role: PlayerRole,
    isSelected: Boolean,
    onClick: () -> Unit,
    glowPulse: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val chipGlow by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val roleInfo = when (role) {
        PlayerRole.BATSMAN -> Triple("🏏", "BATSMAN", CricketGreen)
        PlayerRole.BOWLER -> Triple("⚡", "BOWLER", NeonRed)
        PlayerRole.ALL_ROUNDER -> Triple("🔄", "ALL-ROUNDER", NeonOrange)
        PlayerRole.WICKET_KEEPER -> Triple("🧤", "WICKET-KEEPER", VolleyballBlue)
        PlayerRole.RAIDER -> Triple("🤼", "RAIDER", KabaddiRed)
        PlayerRole.DEFENDER -> Triple("🛡️", "DEFENDER", NeonGreen)
        PlayerRole.SETTER -> Triple("🏐", "SETTER", VolleyballBlue)
        PlayerRole.SPIKER -> Triple("💥", "SPIKER", NeonOrange)
    }
    
    Button(
        onClick = onClick,
        modifier = Modifier
            .scale(if (isSelected) chipGlow else 1f),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) roleInfo.third else MatteBlackLight,
            contentColor = if (isSelected) White else roleInfo.third
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = if (isSelected) 8.dp else 4.dp
        ),
        shape = RoundedCornerShape(20.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = roleInfo.first,
                fontSize = 18.sp
            )
            
            Spacer(modifier = Modifier.width(6.dp))
            
            Text(
                text = roleInfo.second,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            )
        }
    }
}

@Composable
fun AddPlayerButton(
    onClick: () -> Unit,
    isLoading: Boolean,
    glowPulse: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val buttonPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .scale(buttonPulse),
        enabled = !isLoading,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent
        ),
        contentPadding = PaddingValues(0.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            NeonOrangeDark,
                            NeonOrange,
                            NeonOrangeLight
                        )
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
                .border(
                    width = 2.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            NeonOrange.copy(alpha = glowPulse),
                            NeonOrangeLight.copy(alpha = glowPulse)
                        )
                    ),
                    shape = RoundedCornerShape(16.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = White,
                    strokeWidth = 2.dp
                )
            } else {
                Text(
                    text = "ADD PLAYER",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = White,
                        letterSpacing = 2.sp
                    )
                )
            }
        }
    }
}

// Validation functions
fun validatePlayerForm(
    playerName: String,
    jerseyNumber: String,
    age: String,
    phoneNumber: String
): Boolean {
    return playerName.length >= 3 &&
           jerseyNumber.isNotEmpty() && (jerseyNumber.toIntOrNull() ?: 0) > 0 &&
           age.isNotEmpty() && (age.toIntOrNull() ?: 0) >= 10 &&
           phoneNumber.length >= 10
}

fun isValidEmail(email: String): Boolean {
    return email.contains("@") && email.contains(".")
}
