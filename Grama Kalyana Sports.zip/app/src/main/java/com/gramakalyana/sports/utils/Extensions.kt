package com.gramakalyana.sports.utils

import android.content.Context
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.gramakalyana.sports.R
import com.gramakalyana.sports.models.MatchStatus
import com.gramakalyana.sports.models.TournamentStatus
import java.text.SimpleDateFormat
import java.util.*

/**
 * Extension functions for common operations
 */

// Date Extensions
fun Date.formatForDisplay(): String {
    val formatter = SimpleDateFormat(Constants.DATE_FORMAT_DISPLAY, Locale.getDefault())
    return formatter.format(this)
}

fun Date.formatForAPI(): String {
    val formatter = SimpleDateFormat(Constants.DATE_FORMAT_API, Locale.getDefault())
    return formatter.format(this)
}

fun Date.formatWithTime(): String {
    val formatter = SimpleDateFormat(Constants.DATE_FORMAT_DATETIME, Locale.getDefault())
    return formatter.format(this)
}

fun Date.formatTime(): String {
    val formatter = SimpleDateFormat(Constants.DATE_FORMAT_TIME, Locale.getDefault())
    return formatter.format(this)
}

fun Date.isToday(): Boolean {
    val today = Calendar.getInstance()
    val date = Calendar.getInstance()
    date.time = this
    return today.get(Calendar.DAY_OF_YEAR) == date.get(Calendar.DAY_OF_YEAR) &&
            today.get(Calendar.YEAR) == date.get(Calendar.YEAR)
}

fun Date.isYesterday(): Boolean {
    val yesterday = Calendar.getInstance()
    yesterday.add(Calendar.DAY_OF_YEAR, -1)
    val date = Calendar.getInstance()
    date.time = this
    return yesterday.get(Calendar.DAY_OF_YEAR) == date.get(Calendar.DAY_OF_YEAR) &&
            yesterday.get(Calendar.YEAR) == date.get(Calendar.YEAR)
}

// String Extensions
fun String.isValidEmail(): Boolean {
    return Constants.EMAIL_PATTERN.matches(this)
}

fun String.isValidPhone(): Boolean {
    return Constants.PHONE_PATTERN.matches(this)
}

fun String.isValidName(): Boolean {
    return Constants.NAME_PATTERN.matches(this)
}

fun String.capitalizeWords(): String {
    return this.split(" ").joinToString(" ") { it.capitalize() }
}

fun String.getInitials(): String {
    return this.split(" ").take(2).joinToString("") { it.firstOrNull()?.uppercase() ?: "" }
}

// Tournament Status Extensions
fun TournamentStatus.getDisplayColor(): Int {
    return when (this) {
        TournamentStatus.LIVE -> android.graphics.Color.parseColor("#FF0000")
        TournamentStatus.UPCOMING -> android.graphics.Color.parseColor("#FFFF00")
        TournamentStatus.COMPLETED -> android.graphics.Color.parseColor("#00FF00")
        TournamentStatus.CANCELLED -> android.graphics.Color.parseColor("#FF073A")
        TournamentStatus.POSTPONED -> android.graphics.Color.parseColor("#FF6B35")
    }
}

fun TournamentStatus.getDisplayText(): String {
    return when (this) {
        TournamentStatus.LIVE -> "LIVE"
        TournamentStatus.UPCOMING -> "UPCOMING"
        TournamentStatus.COMPLETED -> "COMPLETED"
        TournamentStatus.CANCELLED -> "CANCELLED"
        TournamentStatus.POSTPONED -> "POSTPONED"
    }
}

// Match Status Extensions
fun MatchStatus.getDisplayColor(): Int {
    return when (this) {
        MatchStatus.LIVE -> android.graphics.Color.parseColor("#FF0000")
        MatchStatus.IN_PROGRESS -> android.graphics.Color.parseColor("#FF6B35")
        MatchStatus.BREAK -> android.graphics.Color.parseColor("#FFFF00")
        MatchStatus.SCHEDULED -> android.graphics.Color.parseColor("#00D4FF")
        MatchStatus.COMPLETED -> android.graphics.Color.parseColor("#00FF00")
        MatchStatus.ABANDONED -> android.graphics.Color.parseColor("#FF073A")
        MatchStatus.CANCELLED -> android.graphics.Color.parseColor("#FF073A")
        MatchStatus.POSTPONED -> android.graphics.Color.parseColor("#FF6B35")
    }
}

fun MatchStatus.getDisplayText(): String {
    return when (this) {
        MatchStatus.LIVE -> "LIVE"
        MatchStatus.IN_PROGRESS -> "IN PROGRESS"
        MatchStatus.BREAK -> "BREAK"
        MatchStatus.SCHEDULED -> "SCHEDULED"
        MatchStatus.COMPLETED -> "COMPLETED"
        MatchStatus.ABANDONED -> "ABANDONED"
        MatchStatus.CANCELLED -> "CANCELLED"
        MatchStatus.POSTPONED -> "POSTPONED"
    }
}

// Context Extensions
fun Context.showToast(message: String, duration: Int = Toast.LENGTH_SHORT) {
    Toast.makeText(this, message, duration).show()
}

fun Context.showToast(resId: Int, duration: Int = Toast.LENGTH_SHORT) {
    Toast.makeText(this, resId, duration).show()
}

// Number Extensions
fun Int.formatNumber(): String {
    return when {
        this >= 1000000 -> String.format("%.1fM", this / 1000000.0)
        this >= 1000 -> String.format("%.1fK", this / 1000.0)
        else -> this.toString()
    }
}

fun Double.roundTo(decimals: Int): Double {
    return "%.${decimals}f".format(this).toDouble()
}

fun Float.roundTo(decimals: Int): Float {
    return "%.${decimals}f".format(this).toFloat()
}

// Validation Extensions
fun String.validateTeamName(): String? {
    return when {
        this.isEmpty() -> "Team name cannot be empty"
        this.length < Constants.MIN_TEAM_NAME_LENGTH -> "Team name must be at least ${Constants.MIN_TEAM_NAME_LENGTH} characters"
        this.length > Constants.MAX_TEAM_NAME_LENGTH -> "Team name must not exceed ${Constants.MAX_TEAM_NAME_LENGTH} characters"
        !this.isValidName() -> "Team name contains invalid characters"
        else -> null
    }
}

fun String.validatePlayerName(): String? {
    return when {
        this.isEmpty() -> "Player name cannot be empty"
        this.length < Constants.MIN_PLAYER_NAME_LENGTH -> "Player name must be at least ${Constants.MIN_PLAYER_NAME_LENGTH} characters"
        this.length > Constants.MAX_PLAYER_NAME_LENGTH -> "Player name must not exceed ${Constants.MAX_PLAYER_NAME_LENGTH} characters"
        !this.isValidName() -> "Player name contains invalid characters"
        else -> null
    }
}

fun Int.validateJerseyNumber(): String? {
    return when {
        this < Constants.MIN_JERSEY_NUMBER -> "Jersey number must be at least ${Constants.MIN_JERSEY_NUMBER}"
        this > Constants.MAX_JERSEY_NUMBER -> "Jersey number must not exceed ${Constants.MAX_JERSEY_NUMBER}"
        else -> null
    }
}

// Compose Extensions
@Composable
fun Int.getOrdinal(): String {
    return when {
        this % 100 in 11..13 -> "${this}th"
        this % 10 == 1 -> "${this}st"
        this % 10 == 2 -> "${this}nd"
        this % 10 == 3 -> "${this}rd"
        else -> "${this}th"
    }
}

// List Extensions
fun <T> List<T>.takeIfNotEmpty(): List<T>? {
    return if (this.isNotEmpty()) this else null
}

fun <T> List<T>.takeIfEmpty(): List<T>? {
    return if (this.isEmpty()) this else null
}

// Time Extensions
fun Long.toMinutes(): Long {
    return this / 1000 / 60
}

fun Long.toHours(): Long {
    return this / 1000 / 60 / 60
}

fun Long.toDays(): Long {
    return this / 1000 / 60 / 60 / 24
}

fun Long.formatDuration(): String {
    val hours = this.toHours()
    val minutes = (this.toMinutes() % 60)
    
    return when {
        hours > 0 -> "${hours}h ${minutes}m"
        minutes > 0 -> "${minutes}m"
        else -> "Just now"
    }
}

// Color Extensions (for Compose)
fun String.toColor(): androidx.compose.ui.graphics.Color {
    return androidx.compose.ui.graphics.Color(android.graphics.Color.parseColor(this))
}
