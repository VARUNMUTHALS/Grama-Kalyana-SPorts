package com.gramakalyana.sports.firebase.auth

import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.gramakalyana.sports.firebase.FirebaseManager
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

/**
 * Phone Authentication Repository - Handles Firebase Phone Number Authentication
 * Provides clean interface for phone number sign-in operations
 */
class PhoneAuthRepository private constructor() {
    
    private val auth: FirebaseAuth by lazy { FirebaseManager.getAuth() }
    private val verificationCallbacks = mutableMapOf<String, PhoneAuthProvider.OnVerificationStateChangedCallbacks>()
    
    /**
     * Send verification code to phone number
     */
    suspend fun sendVerificationCode(
        phoneNumber: String,
        callbacks: PhoneAuthProvider.OnVerificationStateChangedCallbacks
    ): Result<Unit> {
        return try {
            // Validate phone number
            if (phoneNumber.isBlank()) {
                return Result.failure(PhoneAuthException.InvalidPhoneNumber("Phone number cannot be empty"))
            }
            
            if (!isValidPhoneNumber(phoneNumber)) {
                return Result.failure(PhoneAuthException.InvalidPhoneNumber("Invalid phone number format"))
            }
            
            val options = PhoneAuthOptions.newBuilder(auth)
                .setPhoneNumber(phoneNumber)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setCallbacks(callbacks)
                .build()
            
            PhoneAuthProvider.verifyPhoneNumber(options)
            
            // Store callbacks for cleanup
            verificationCallbacks[phoneNumber] = callbacks
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(handlePhoneAuthException(e))
        }
    }
    
    /**
     * Sign in with phone credential
     */
    suspend fun signInWithPhoneCredential(credential: PhoneAuthCredential): Result<String> {
        return try {
            val authResult = auth.signInWithCredential(credential).await()
            val userId = authResult.user?.uid ?: return Result.failure(
                PhoneAuthException.SignInFailed("Failed to get user ID after sign in")
            )
            
            // Create user profile in database if needed
            createUserProfileInDatabase(authResult.user)
            
            Result.success(userId)
        } catch (e: Exception) {
            Result.failure(handlePhoneAuthException(e))
        }
    }
    
    /**
     * Create phone credential from verification code
     */
    fun createPhoneCredential(verificationId: String, code: String): PhoneAuthCredential {
        return PhoneAuthProvider.getCredential(verificationId, code)
    }
    
    /**
     * Resend verification code
     */
    suspend fun resendVerificationCode(
        phoneNumber: String,
        token: PhoneAuthProvider.ForceResendingToken,
        callbacks: PhoneAuthProvider.OnVerificationStateChangedCallbacks
    ): Result<Unit> {
        return try {
            val options = PhoneAuthOptions.newBuilder(auth)
                .setPhoneNumber(phoneNumber)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setCallbacks(callbacks)
                .setForceResendingToken(token)
                .build()
            
            PhoneAuthProvider.verifyPhoneNumber(options)
            
            // Update stored callbacks
            verificationCallbacks[phoneNumber] = callbacks
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(handlePhoneAuthException(e))
        }
    }
    
    /**
     * Sign out current user
     */
    suspend fun signOut(): Result<Unit> {
        return try {
            auth.signOut()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(PhoneAuthException.SignOutFailed("Failed to sign out: ${e.message}"))
        }
    }
    
    /**
     * Get current user
     */
    val currentUser get() = auth.currentUser
    
    /**
     * Check if user is authenticated
     */
    val isUserAuthenticated get() = currentUser != null
    
    /**
     * Enable phone auth testing (for development)
     */
    fun enablePhoneAuthTesting() {
        auth.firebaseAuthSettings.setAppVerificationDisabledForTesting(true)
    }
    
    /**
     * Force reCAPTCHA flow (for testing)
     */
    fun forceRecaptchaFlowForTesting() {
        auth.firebaseAuthSettings.forceRecaptchaFlowForTesting(true)
    }
    
    /**
     * Set auto-retrieved SMS code for testing
     */
    fun setAutoRetrievedSmsCodeForTesting(phoneNumber: String, smsCode: String) {
        auth.firebaseAuthSettings.setAutoRetrievedSmsCodeForPhoneNumber(phoneNumber, smsCode)
    }
    
    /**
     * Clean up callbacks
     */
    fun cleanup(phoneNumber: String) {
        verificationCallbacks.remove(phoneNumber)
    }
    
    /**
     * Clean up all callbacks
     */
    fun cleanupAll() {
        verificationCallbacks.clear()
    }
    
    // Private helper methods
    
    private fun isValidPhoneNumber(phoneNumber: String): Boolean {
        // Basic phone number validation
        val phonePattern = "^\\+[1-9]\\d{1,14}$" // E.164 format
        return phoneNumber.matches(phonePattern.toRegex())
    }
    
    private suspend fun createUserProfileInDatabase(user: com.google.firebase.auth.FirebaseUser?) {
        user?.let { firebaseUser ->
            val userProfile = mapOf(
                "uid" to firebaseUser.uid,
                "phoneNumber" to firebaseUser.phoneNumber,
                "createdAt" to System.currentTimeMillis(),
                "lastLoginAt" to System.currentTimeMillis(),
                "isPhoneVerified" to true,
                "authMethod" to "phone",
                "role" to "USER"
            )
            
            FirebaseManager.usersRef.child(firebaseUser.uid).setValue(userProfile).await()
        }
    }
    
    private fun handlePhoneAuthException(exception: Exception): PhoneAuthException {
        return when (exception) {
            is FirebaseAuthInvalidCredentialsException -> {
                when (exception.message) {
                    "The verification code from SMS/TOTP is invalid." -> PhoneAuthException.InvalidVerificationCode("Invalid verification code")
                    "The phone number is badly formatted." -> PhoneAuthException.InvalidPhoneNumber("Invalid phone number format")
                    else -> PhoneAuthException.InvalidCredentials("Invalid credentials: ${exception.message}")
                }
            }
            is FirebaseException -> {
                when (exception.message) {
                    "The SMS quota for the project has been exceeded." -> PhoneAuthException.QuotaExceeded("SMS quota exceeded")
                    "We have blocked all requests from this device due to unusual activity." -> PhoneAuthException.DeviceBlocked("Device blocked due to unusual activity")
                    else -> PhoneAuthException.FirebaseError("Firebase error: ${exception.message}")
                }
            }
            else -> PhoneAuthException.UnknownError("Phone authentication failed: ${exception.message}", exception)
        }
    }
    
    companion object {
        @Volatile
        private var INSTANCE: PhoneAuthRepository? = null
        
        fun getInstance(): PhoneAuthRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: PhoneAuthRepository().also { INSTANCE = it }
            }
        }
    }
}

/**
 * Custom exceptions for phone authentication operations
 */
sealed class PhoneAuthException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class InvalidPhoneNumber(message: String) : PhoneAuthException(message)
    class InvalidVerificationCode(message: String) : PhoneAuthException(message)
    class InvalidCredentials(message: String) : PhoneAuthException(message)
    class QuotaExceeded(message: String) : PhoneAuthException(message)
    class DeviceBlocked(message: String) : PhoneAuthException(message)
    class SignInFailed(message: String) : PhoneAuthException(message)
    class SignOutFailed(message: String) : PhoneAuthException(message)
    class FirebaseError(message: String) : PhoneAuthException(message)
    class UnknownError(message: String, cause: Throwable? = null) : PhoneAuthException(message, cause)
}
