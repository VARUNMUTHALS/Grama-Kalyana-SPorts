package com.gramakalyana.sports.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToTournaments: () -> Unit,
    onNavigateToLiveScores: () -> Unit,
    onNavigateToStatistics: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Welcome to",
                    style = MaterialTheme.typography.bodyLarge,
                    color = White80
                )
                Text(
                    text = "Grama Kalyana Sports",
                    style = MaterialTheme.typography.headlineLarge,
                    color = NeonOrange,
                    fontWeight = FontWeight.Bold
                )
            }
            
            IconButton(
                onClick = onNavigateToSettings,
                modifier = Modifier
                    .background(MatteBlackLight, RoundedCornerShape(12.dp))
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = NeonOrange
                )
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // Quick Stats Cards
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.weight(1f)
        ) {
            item {
                Text(
                    text = "Quick Actions",
                    style = MaterialTheme.typography.headlineMedium,
                    color = White,
                    fontWeight = FontWeight.Bold
                )
            }
            
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    HomeActionCard(
                        title = "Tournaments",
                        subtitle = "Manage & View",
                        icon = Icons.Default.EmojiEvents,
                        color = NeonOrange,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToTournaments
                    )
                    
                    HomeActionCard(
                        title = "Live Scores",
                        subtitle = "Watch Live",
                        icon = Icons.Default.LiveTv,
                        color = LiveRed,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToLiveScores
                    )
                }
            }
            
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    HomeActionCard(
                        title = "Statistics",
                        subtitle = "Player Stats",
                        icon = Icons.Default.BarChart,
                        color = NeonGreen,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToStatistics
                    )
                    
                    HomeActionCard(
                        title = "Teams",
                        subtitle = "All Teams",
                        icon = Icons.Default.Groups,
                        color = NeonBlue,
                        modifier = Modifier.weight(1f),
                        onClick = { /* Navigate to teams */ }
                    )
                }
            }
            
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Featured Sports",
                    style = MaterialTheme.typography.headlineMedium,
                    color = White,
                    fontWeight = FontWeight.Bold
                )
            }
            
            item {
                SportCard(
                    sportName = "Cricket",
                    icon = Icons.Default.SportsCricket,
                    color = CricketGreen,
                    description = "T20, One Day, Test Matches"
                )
            }
            
            item {
                SportCard(
                    sportName = "Kabaddi",
                    icon = Icons.Default.SportsKabaddi,
                    color = KabaddiRed,
                    description = "Pro Kabaddi League Format"
                )
            }
            
            item {
                SportCard(
                    sportName = "Volleyball",
                    icon = Icons.Default.SportsVolleyball,
                    color = VolleyballBlue,
                    description = "Indoor & Beach Volleyball"
                )
            }
        }
    }
}

@Composable
fun HomeActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier
            .height(120.dp)
            .clip(RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = color,
                modifier = Modifier.size(32.dp)
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = White,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = White60,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun SportCard(
    sportName: String,
    icon: ImageVector,
    color: Color,
    description: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(80.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(color.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = sportName,
                    tint = color,
                    modifier = Modifier.size(28.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = sportName,
                    style = MaterialTheme.typography.titleMedium,
                    color = White,
                    fontWeight = FontWeight.Bold
                )
                
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = White60
                )
            }
            
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = "Navigate",
                tint = White40,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
