package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchListScreen(
    tournamentId: String,
    onBack: () -> Unit,
    onMatchClick: (String) -> Unit,
    onScheduleMatch: () -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(150000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val liveGlow by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Match data
    var selectedFilter by remember { mutableStateOf(MatchFilter.ALL) }
    val matches = remember {
        listOf(
            Match(
                id = "match_001",
                tournamentId = tournamentId,
                teamAId = "team_001",
                teamBId = "team_002",
                teamAName = "Royal Warriors",
                teamBName = "Thunder Strikers",
                sportType = SportType.CRICKET,
                venue = "Grama Kalyana Stadium",
                scheduledDate = System.currentTimeMillis(),
                status = MatchStatus.LIVE,
                cricketScore = CricketScore(
                    teamARuns = 156,
                    teamAWickets = 4,
                    teamAOvers = 18.5,
                    teamBRuns = 89,
                    teamBWickets = 2,
                    teamBOvers = 12.3
                )
            ),
            Match(
                id = "match_002",
                tournamentId = tournamentId,
                teamAId = "team_003",
                teamBId = "team_004",
                teamAName = "Lions Club",
                teamBName = "Eagles Team",
                sportType = SportType.KABADDI,
                venue = "Community Sports Ground",
                scheduledDate = System.currentTimeMillis() + 86400000 * 2, // 2 days from now
                status = MatchStatus.UPCOMING,
                kabaddiScore = KabaddiScore(
                    teamAPoints = 0,
                    teamBPoints = 0
                )
            ),
            Match(
                id = "match_003",
                tournamentId = tournamentId,
                teamAId = "team_001",
                teamBId = "team_003",
                teamAName = "Royal Warriors",
                teamBName = "Lions Club",
                sportType = SportType.CRICKET,
                venue = "Youth Sports Complex",
                scheduledDate = System.currentTimeMillis() - 86400000 * 3, // 3 days ago
                status = MatchStatus.COMPLETED,
                cricketScore = CricketScore(
                    teamARuns = 178,
                    teamAWickets = 6,
                    teamAOvers = 20.0,
                    teamBRuns = 145,
                    teamBWickets = 8,
                    teamBOvers = 18.4
                ),
                winnerId = "team_001",
                resultSummary = "Royal Warriors won by 33 runs"
            ),
            Match(
                id = "match_004",
                tournamentId = tournamentId,
                teamAId = "team_002",
                teamBId = "team_004",
                teamAName = "Thunder Strikers",
                teamBName = "Eagles Team",
                sportType = SportType.KABADDI,
                venue = "Beach Sports Arena",
                scheduledDate = System.currentTimeMillis() + 86400000 * 5, // 5 days from now
                status = MatchStatus.UPCOMING,
                kabaddiScore = KabaddiScore(
                    teamAPoints = 0,
                    teamBPoints = 0
                )
            ),
            Match(
                id = "match_005",
                tournamentId = tournamentId,
                teamAId = "team_003",
                teamBId = "team_002",
                teamAName = "Lions Club",
                teamBName = "Thunder Strikers",
                sportType = SportType.KABADDI,
                venue = "Indoor Sports Complex",
                scheduledDate = System.currentTimeMillis() - 86400000, // 1 day ago
                status = MatchStatus.COMPLETED,
                kabaddiScore = KabaddiScore(
                    teamAPoints = 32,
                    teamBPoints = 28
                ),
                winnerId = "team_003",
                resultSummary = "Lions Club won by 4 points"
            )
        )
    }
    
    val filteredMatches = remember(selectedFilter, matches) {
        when (selectedFilter) {
            MatchFilter.ALL -> matches
            MatchFilter.LIVE -> matches.filter { it.status == MatchStatus.LIVE }
            MatchFilter.UPCOMING -> matches.filter { it.status == MatchStatus.UPCOMING }
            MatchFilter.COMPLETED -> matches.filter { it.status == MatchStatus.COMPLETED }
        }
    }
    
    val listState = rememberLazyListState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Match list background
        MatchListBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = liveGlow
        )
        
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            MatchListHeader(
                onBack = onBack,
                onScheduleMatch = onScheduleMatch,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Filter tabs
            MatchFilterTabs(
                selectedFilter = selectedFilter,
                onFilterSelected = { selectedFilter = it },
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Match statistics summary
            MatchStatisticsSummary(
                matches = matches,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Match list
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                state = listState,
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredMatches) { match ->
                    MatchCard(
                        match = match,
                        onClick = { onMatchClick(match.id) },
                        liveGlow = liveGlow
                    )
                }
            }
        }
    }
}

enum class MatchFilter {
    ALL,
    LIVE,
    UPCOMING,
    COMPLETED
}

@Composable
fun MatchListBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle background effect
        val positions = listOf(
            Offset(canvasWidth * 0.1f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.1f, canvasHeight * 0.9f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.9f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.5f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center pattern
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        drawCircle(
            color = NeonOrange.copy(alpha = glowAlpha * 0.05f),
            radius = min(canvasWidth, canvasHeight) * 0.3f,
            center = Offset(centerX, centerY)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchListHeader(
    onBack: () -> Unit,
    onScheduleMatch: () -> Unit,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val buttonPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Text(
            text = "MATCHES",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                color = NeonOrange,
                letterSpacing = 2.sp
            )
        )
        
        Spacer(modifier = Modifier.weight(1f))
        
        Button(
            onClick = onScheduleMatch,
            modifier = Modifier
                .scale(buttonPulse),
            colors = ButtonDefaults.buttonColors(
                containerColor = NeonOrange
            ),
            elevation = ButtonDefaults.buttonElevation(
                defaultElevation = 8.dp
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Schedule Match",
                tint = White,
                modifier = Modifier.size(20.dp)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = "SCHEDULE",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = White,
                    letterSpacing = 1.sp
                )
            )
        }
    }
}

@Composable
fun MatchFilterTabs(
    selectedFilter: MatchFilter,
    onFilterSelected: (MatchFilter) -> Unit,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val tabGlow by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        MatchFilter.values().forEach { filter ->
            FilterTab(
                text = filter.name,
                isSelected = selectedFilter == filter,
                onClick = { onFilterSelected(filter) },
                tabGlow = if (selectedFilter == filter && filter == MatchFilter.LIVE) tabGlow else 1f,
                liveGlow = liveGlow
            )
        }
    }
}

@Composable
fun FilterTab(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    tabGlow: Float,
    liveGlow: Float
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .scale(tabGlow),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) NeonOrange else MatteBlackLight,
            contentColor = if (isSelected) White else White80
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = if (isSelected) 8.dp else 4.dp
        ),
        shape = RoundedCornerShape(20.dp),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )
        
        if (isSelected && text == "LIVE") {
            Spacer(modifier = Modifier.width(8.dp))
            
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(LiveRed, RoundedCornerShape(3.dp))
                    .scale(1f + liveGlow * 0.5f)
            )
        }
    }
}

@Composable
fun MatchStatisticsSummary(
    matches: List<Match>,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val statsPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .scale(statsPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            MatchStatItem(
                label = "TOTAL",
                value = matches.size.toString(),
                color = NeonOrange
            )
            
            VerticalDivider(
                modifier = Modifier.height(40.dp),
                color = White20
            )
            
            MatchStatItem(
                label = "LIVE",
                value = matches.count { it.status == MatchStatus.LIVE }.toString(),
                color = LiveRed
            )
            
            VerticalDivider(
                modifier = Modifier.height(40.dp),
                color = White20
            )
            
            MatchStatItem(
                label = "UPCOMING",
                value = matches.count { it.status == MatchStatus.UPCOMING }.toString(),
                color = NeonGreen
            )
            
            VerticalDivider(
                modifier = Modifier.height(40.dp),
                color = White20
            )
            
            MatchStatItem(
                label = "COMPLETED",
                value = matches.count { it.status == MatchStatus.COMPLETED }.toString(),
                color = White80
            )
        }
    }
}

@Composable
fun MatchStatItem(
    label: String,
    value: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Black,
                color = color,
                fontFamily = FontFamily.SansSerif
            )
        )
        
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = White60,
                letterSpacing = 1.sp
            )
        )
    }
}

@Composable
fun MatchCard(
    match: Match,
    onClick: () -> Unit,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val cardPulse by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .scale(if (match.status == MatchStatus.LIVE) cardPulse else 1f),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = when (match.status) {
                MatchStatus.LIVE -> 12.dp
                MatchStatus.UPCOMING -> 8.dp
                else -> 6.dp
            }
        ),
        border = when (match.status) {
            MatchStatus.LIVE -> androidx.compose.foundation.BorderStroke(
                width = 2.dp,
                color = LiveRed.copy(alpha = liveGlow)
            )
            else -> null
        },
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header with status and sport type
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SportTypeBadge(
                        sportType = match.sportType,
                        isLive = match.status == MatchStatus.LIVE,
                        size = SportBadgeSize.SMALL
                    )
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    Text(
                        text = match.getFormattedDate(),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = White80,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
                
                MatchStatusBadge(
                    status = match.status,
                    liveGlow = liveGlow
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Team names and scores
            when (match.status) {
                MatchStatus.LIVE -> LiveMatchContent(match, liveGlow)
                MatchStatus.UPCOMING -> UpcomingMatchContent(match)
                MatchStatus.COMPLETED -> CompletedMatchContent(match)
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Footer with venue
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = White60,
                    modifier = Modifier.size(16.dp)
                )
                
                Spacer(modifier = Modifier.width(6.dp))
                
                Text(
                    text = match.venue,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = White80,
                        fontWeight = FontWeight.Medium
                    ),
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun LiveMatchContent(
    match: Match,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val scorePulse by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Column {
        when (match.sportType) {
            SportType.CRICKET -> {
                val cricketScore = match.cricketScore ?: return
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        horizontalAlignment = Alignment.Start,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = match.teamAName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NeonOrange
                            ),
                            maxLines = 1
                        )
                        
                        Text(
                            text = "${cricketScore.teamARuns}/${cricketScore.teamAWickets}",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = NeonOrange,
                                fontFamily = FontFamily.SansSerif
                            ),
                            modifier = Modifier.scale(scorePulse)
                        )
                    }
                    
                    Text(
                        text = "VS",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = White60,
                            letterSpacing = 4.sp
                        )
                    )
                    
                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = match.teamBName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = White
                            ),
                            maxLines = 1
                        )
                        
                        Text(
                            text = "${cricketScore.teamBRuns}/${cricketScore.teamBWickets}",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = White,
                                fontFamily = FontFamily.SansSerif
                            )
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Over ${cricketScore.teamAOvers}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = NeonOrange,
                        fontWeight = FontWeight.Medium
                    )
                )
            }
            
            SportType.KABADDI -> {
                val kabaddiScore = match.kabaddiScore ?: return
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        horizontalAlignment = Alignment.Start,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = match.teamAName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NeonOrange
                            ),
                            maxLines = 1
                        )
                        
                        Text(
                            text = kabaddiScore.teamAPoints.toString(),
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = NeonOrange,
                                fontFamily = FontFamily.SansSerif
                            ),
                            modifier = Modifier.scale(scorePulse)
                        )
                    }
                    
                    Text(
                        text = "VS",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = White60,
                            letterSpacing = 4.sp
                        )
                    )
                    
                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = match.teamBName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = White
                            ),
                            maxLines = 1
                        )
                        
                        Text(
                            text = kabaddiScore.teamBPoints.toString(),
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = White,
                                fontFamily = FontFamily.SansSerif
                            )
                        )
                    }
                }
            }
            
            SportType.VOLLEYBALL -> {
                val volleyballScore = match.volleyballScore ?: return
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        horizontalAlignment = Alignment.Start,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = match.teamAName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NeonOrange
                            ),
                            maxLines = 1
                        )
                        
                        Text(
                            text = "${volleyballScore.teamASets} sets",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = NeonOrange,
                                fontFamily = FontFamily.SansSerif
                            ),
                            modifier = Modifier.scale(scorePulse)
                        )
                    }
                    
                    Text(
                        text = "VS",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = White60,
                            letterSpacing = 4.sp
                        )
                    )
                    
                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = match.teamBName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = White
                            ),
                            maxLines = 1
                        )
                        
                        Text(
                            text = "${volleyballScore.teamBSets} sets",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = White,
                                fontFamily = FontFamily.SansSerif
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun UpcomingMatchContent(match: Match) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            horizontalAlignment = Alignment.Start,
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = match.teamAName,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = White
                ),
                maxLines = 1
            )
        }
        
        Text(
            text = "VS",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Black,
                color = White60,
                letterSpacing = 4.sp
            )
        )
        
        Column(
            horizontalAlignment = Alignment.End,
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = match.teamBName,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = White
                ),
                maxLines = 1
            )
        }
    }
    
    Spacer(modifier = Modifier.height(8.dp))
    
    Text(
        text = match.getFormattedTime(),
        style = MaterialTheme.typography.bodySmall.copy(
            color = NeonGreen,
            fontWeight = FontWeight.Medium
        )
    )
}

@Composable
fun CompletedMatchContent(match: Match) {
    val winnerName = if (match.winnerId == match.teamAId) match.teamAName else match.teamBName
    
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            horizontalAlignment = Alignment.Start,
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = match.teamAName,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (match.winnerId == match.teamAId) NeonGreen else White60
                ),
                maxLines = 1
            )
        }
        
        Text(
            text = "VS",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Black,
                color = White60,
                letterSpacing = 4.sp
            )
        )
        
        Column(
            horizontalAlignment = Alignment.End,
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = match.teamBName,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (match.winnerId == match.teamBId) NeonGreen else White60
                ),
                maxLines = 1
            )
        }
    }
    
    Spacer(modifier = Modifier.height(8.dp))
    
    Text(
        text = match.resultSummary ?: "Match completed",
        style = MaterialTheme.typography.bodySmall.copy(
            color = NeonGreen,
            fontWeight = FontWeight.Medium
        )
    )
}

@Composable
fun MatchStatusBadge(
    status: MatchStatus,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val statusPulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(
                color = status.getDisplayColor().copy(alpha = 0.2f),
                shape = RoundedCornerShape(12.dp)
            )
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .scale(if (status == MatchStatus.LIVE) statusPulse else 1f)
    ) {
        if (status == MatchStatus.LIVE) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(LiveRed, RoundedCornerShape(3.dp))
                    .scale(1f + liveGlow * 0.5f)
            )
            
            Spacer(modifier = Modifier.width(6.dp))
        }
        
        Text(
            text = status.getDisplayText(),
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Black,
                color = status.getDisplayColor(),
                letterSpacing = 1.sp
            )
        )
    }
}

// Extension functions for Match
fun Match.getFormattedDate(): String {
    val date = java.util.Date(scheduledDate)
    val formatter = java.text.SimpleDateFormat("dd MMM", java.util.Locale.getDefault())
    return formatter.format(date)
}

fun Match.getFormattedTime(): String {
    val date = java.util.Date(scheduledDate)
    val formatter = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
    return formatter.format(date)
}
