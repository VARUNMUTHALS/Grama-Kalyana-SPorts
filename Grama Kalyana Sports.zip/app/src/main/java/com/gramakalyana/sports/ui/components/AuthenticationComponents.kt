package com.gramakalyana.sports.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.ui.theme.*

@Composable
fun AuthenticationBackground(
    modifier: Modifier = Modifier,
    rotation: Float = 0f,
    glowAlpha: Float = 0.5f
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Stadium floodlight effect
        val floodlightPositions = listOf(
            Offset(0f, 0f),
            Offset(canvasWidth, 0f),
            Offset(0f, canvasHeight),
            Offset(canvasWidth, canvasHeight)
        )
        
        floodlightPositions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.7f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.2f),
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 0.5f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center arena effect
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        val centerGradient = androidx.compose.ui.graphics.RadialGradientShader(
            center = Offset(centerX, centerY),
            radius = min(canvasWidth, canvasHeight) * 0.3f,
            colors = listOf(
                NeonOrange.copy(alpha = glowAlpha * 0.1f),
                Color.Transparent
            ),
            colorStops = listOf(0f, 1f)
        )
        
        drawRect(
            brush = ShaderBrush(centerGradient),
            size = size
        )
    }
}

@Composable
fun AuthHeader(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                color = White,
                textAlign = TextAlign.Center
            )
        )
        
        subtitle?.let {
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = it,
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = White80,
                    textAlign = TextAlign.Center
                )
            )
        }
    }
}

@Composable
fun SocialLoginButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    backgroundColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition()
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    OutlinedButton(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = White
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = backgroundColor.copy(alpha = glowPulse)
        )
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = backgroundColor,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Medium,
                    color = White
                )
            )
        }
    }
}

@Composable
fun TermsAndConditionsText(
    onTermsClick: () -> Unit,
    onPrivacyClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "By continuing, you agree to our ",
            style = MaterialTheme.typography.bodySmall.copy(
                color = White60
            )
        )
        
        TextButton(
            onClick = onTermsClick,
            contentPadding = PaddingValues(0.dp)
        ) {
            Text(
                text = "Terms of Service",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NeonOrange,
                    fontWeight = FontWeight.Medium
                )
            )
        }
        
        Text(
            text = " and ",
            style = MaterialTheme.typography.bodySmall.copy(
                color = White60
            )
        )
        
        TextButton(
            onClick = onPrivacyClick,
            contentPadding = PaddingValues(0.dp)
        ) {
            Text(
                text = "Privacy Policy",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NeonOrange,
                    fontWeight = FontWeight.Medium
                )
            )
        }
    }
}

@Composable
fun OrDivider(
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = White20
        )
        
        Text(
            text = "OR",
            style = MaterialTheme.typography.bodySmall.copy(
                color = White60
            ),
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = White20
        )
    }
}

@Composable
fun AuthSuccessAnimation(
    isVisible: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition()
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    if (isVisible) {
        Box(
            modifier = modifier,
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Success",
                tint = NeonGreen,
                modifier = Modifier
                    .size(80.dp)
                    .scale(scale)
                    .rotate(rotation)
            )
        }
    }
}

@Composable
fun LoadingAnimation(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition()
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator(
            modifier = Modifier
                .size(48.dp)
                .rotate(rotation),
            color = NeonOrange,
            strokeWidth = 4.dp
        )
    }
}

@Composable
fun PasswordStrengthIndicator(
    password: String,
    modifier: Modifier = Modifier
) {
    val strength = calculatePasswordStrength(password)
    val strengthColor = when (strength) {
        PasswordStrength.WEAK -> NeonRed
        PasswordStrength.MEDIUM -> NeonYellow
        PasswordStrength.STRONG -> NeonGreen
    }
    
    Column(
        modifier = modifier
    ) {
        Text(
            text = "Password Strength: ${strength.name.lowercase().replaceFirstChar { it.uppercase() }}",
            style = MaterialTheme.typography.bodySmall.copy(
                color = strengthColor,
                fontWeight = FontWeight.Medium
            )
        )
        
        Spacer(modifier = Modifier.height(4.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            for (i in 1..4) {
                val isActive = when (strength) {
                    PasswordStrength.WEAK -> i == 1
                    PasswordStrength.MEDIUM -> i <= 2
                    PasswordStrength.STRONG -> i <= 3
                }
                
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(4.dp)
                        .background(
                            color = if (isActive) strengthColor else White20,
                            shape = RoundedCornerShape(2.dp)
                        )
                )
            }
        }
    }
}

enum class PasswordStrength {
    WEAK,
    MEDIUM,
    STRONG
}

fun calculatePasswordStrength(password: String): PasswordStrength {
    return when {
        password.length < 6 -> PasswordStrength.WEAK
        password.length < 10 && password.any { it.isUpperCase() } && password.any { it.isDigit() } -> PasswordStrength.MEDIUM
        password.length >= 10 && password.any { it.isUpperCase() } && password.any { it.isDigit() } && password.any { !it.isLetterOrDigit() } -> PasswordStrength.STRONG
        password.length >= 8 && (password.any { it.isUpperCase() } || password.any { it.isDigit() }) -> PasswordStrength.MEDIUM
        else -> PasswordStrength.WEAK
    }
}

@Composable
fun ValidationMessage(
    message: String,
    isError: Boolean = true,
    modifier: Modifier = Modifier
) {
    val color = if (isError) NeonRed else NeonGreen
    val icon = if (isError) Icons.Default.Error else Icons.Default.CheckCircle
    
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(16.dp)
        )
        
        Spacer(modifier = Modifier.width(8.dp))
        
        Text(
            text = message,
            style = MaterialTheme.typography.bodySmall.copy(
                color = color
            )
        )
    }
}
