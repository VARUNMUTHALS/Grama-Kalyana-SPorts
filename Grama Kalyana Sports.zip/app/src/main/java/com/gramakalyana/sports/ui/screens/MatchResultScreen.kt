package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchResultScreen(
    matchId: String,
    onBack: () -> Unit,
    onShare: () -> Unit,
    onViewScorecard: () -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(100000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val celebrationPulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val confettiRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    // Match data (sample completed match)
    val match = remember {
        Match(
            id = matchId,
            tournamentId = "tournament_001",
            teamAId = "team_001",
            teamBId = "team_002",
            teamAName = "Royal Warriors",
            teamBName = "Thunder Strikers",
            sportType = SportType.CRICKET,
            venue = "Grama Kalyana Stadium",
            scheduledDate = System.currentTimeMillis() - 86400000, // 1 day ago
            status = MatchStatus.COMPLETED,
            cricketScore = CricketScore(
                teamARuns = 178,
                teamAWickets = 6,
                teamAOvers = 20.0,
                teamBRuns = 145,
                teamBWickets = 8,
                teamBOvers = 18.4
            ),
            winnerId = "team_001",
            resultSummary = "Royal Warriors won by 33 runs",
            mvpPlayerId = "player_001",
            mvpPlayerName = "Rahul Sharma",
            mvpStats = "78 runs (45 balls), 2 wickets"
        )
    }
    
    val scrollState = rememberScrollState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Victory celebration background
        VictoryBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            confettiRotation = confettiRotation,
            glowAlpha = celebrationPulse
        )
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Header
            MatchResultHeader(
                onBack = onBack,
                onShare = onShare,
                celebrationPulse = celebrationPulse
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Winner banner
            WinnerBanner(
                match = match,
                celebrationPulse = celebrationPulse
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Final scoreboard
            FinalScoreboard(
                match = match,
                celebrationPulse = celebrationPulse
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Match summary
            MatchSummarySection(
                match = match
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // MVP section
            MVPSection(
                match = match,
                celebrationPulse = celebrationPulse
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Key statistics
            KeyStatisticsSection(
                match = match
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Action buttons
            ActionButtonsSection(
                onViewScorecard = onViewScorecard,
                onShare = onShare,
                celebrationPulse = celebrationPulse
            )
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun VictoryBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    confettiRotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Victory gradient background
        val gradient = androidx.compose.ui.graphics.LinearGradientShader(
            from = Offset(0f, 0f),
            to = Offset(canvasWidth, canvasHeight),
            colors = listOf(
                NeonOrange.copy(alpha = glowAlpha * 0.1f),
                NeonGreen.copy(alpha = glowAlpha * 0.05f),
                MatteBlack
            ),
            colorStops = listOf(0f, 0.5f, 1f)
        )
        
        drawRect(
            brush = ShaderBrush(gradient),
            size = size
        )
        
        // Confetti effects
        drawConfetti(canvasWidth, canvasHeight, confettiRotation, glowAlpha)
        
        // Spotlight effects on winner
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 3
        
        val spotlightGradient = androidx.compose.ui.graphics.RadialGradientShader(
            center = Offset(centerX, centerY),
            radius = min(canvasWidth, canvasHeight) * 0.4f,
            colors = listOf(
                NeonOrange.copy(alpha = glowAlpha * 0.2f),
                NeonGreen.copy(alpha = glowAlpha * 0.1f),
                Color.Transparent
            ),
            colorStops = listOf(0f, 0.5f, 1f)
        )
        
        drawRect(
            brush = ShaderBrush(spotlightGradient),
            size = size
        )
    }
}

private fun DrawScope.drawConfetti(
    canvasWidth: Float,
    canvasHeight: Float,
    rotation: Float,
    glowAlpha: Float
) {
    val confettiColors = listOf(
        NeonOrange,
        NeonGreen,
        NeonYellow,
        NeonRed,
        VolleyballBlue,
        KabaddiRed,
        CricketGreen
    )
    
    repeat(20) { index ->
        val angle = (index * 18f + rotation) * (PI / 180f)
        val distance = 100f + (index % 3) * 50f
        val x = canvasWidth / 2 + cos(angle).toFloat() * distance
        val y = canvasHeight / 4 + sin(angle).toFloat() * distance
        val size = 4f + (index % 3) * 2f
        
        drawCircle(
            color = confettiColors[index % confettiColors.size].copy(alpha = glowAlpha * 0.8f),
            radius = size,
            center = Offset(x, y)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchResultHeader(
    onBack: () -> Unit,
    onShare: () -> Unit,
    celebrationPulse: Float
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "MATCH RESULT",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange,
                    letterSpacing = 2.sp
                )
            )
            
            Text(
                text = "Championship Victory!",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = NeonGreen,
                    fontWeight = FontWeight.Medium
                )
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        IconButton(
            onClick = onShare,
            modifier = Modifier
                .background(NeonGreen.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                .size(48.dp)
                .scale(celebrationPulse)
        ) {
            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = "Share",
                tint = NeonGreen,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun WinnerBanner(
    match: Match,
    celebrationPulse: Float
) {
    val winnerName = if (match.winnerId == match.teamAId) match.teamAName else match.teamBName
    val winnerColor = if (match.winnerId == match.teamAId) NeonOrange else White
    val loserName = if (match.winnerId == match.teamAId) match.teamBName else match.teamAName
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(celebrationPulse),
        colors = CardDefaults.cardColors(
            containerColor = NeonGreen.copy(alpha = 0.1f)
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 12.dp
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 3.dp,
            brush = Brush.horizontalGradient(
                colors = listOf(NeonGreen, NeonOrange)
            )
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Trophy icon
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = "Trophy",
                    tint = NeonOrange,
                    modifier = Modifier.size(48.dp)
                )
                
                Spacer(modifier = Modifier.width(16.dp))
                
                Icon(
                    imageVector = Icons.Default.Stars,
                    contentDescription = "Stars",
                    tint = NeonYellow,
                    modifier = Modifier.size(32.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = "WINNER",
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Black,
                    color = NeonGreen,
                    letterSpacing = 4.sp
                )
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = winnerName,
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Black,
                    color = winnerColor,
                    fontFamily = FontFamily.SansSerif,
                    textAlign = TextAlign.Center
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = match.resultSummary ?: "Victory Achieved!",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange,
                    textAlign = TextAlign.Center
                )
            )
        }
    }
}

@Composable
fun FinalScoreboard(
    match: Match,
    celebrationPulse: Float
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Text(
                text = "FINAL SCORE",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange,
                    textAlign = TextAlign.Center
                ),
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(20.dp))
            
            when (match.sportType) {
                SportType.CRICKET -> FinalCricketScoreboard(match, celebrationPulse)
                SportType.KABADDI -> FinalKabaddiScoreboard(match, celebrationPulse)
                SportType.VOLLEYBALL -> FinalVolleyballScoreboard(match, celebrationPulse)
            }
        }
    }
}

@Composable
fun FinalCricketScoreboard(
    match: Match,
    celebrationPulse: Float
) {
    val cricketScore = match.cricketScore ?: return
    val isTeamAWinner = match.winnerId == match.teamAId
    
    Column {
        // Team A
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.Start
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isTeamAWinner) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Winner",
                            tint = NeonOrange,
                            modifier = Modifier.size(24.dp)
                        )
                        
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    
                    Text(
                        text = match.teamAName,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isTeamAWinner) NeonOrange else White60
                        )
                    )
                }
            }
            
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "${cricketScore.teamARuns}/${cricketScore.teamAWickets}",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isTeamAWinner) NeonOrange else White60,
                        fontFamily = FontFamily.SansSerif
                    ),
                    modifier = Modifier.scale(if (isTeamAWinner) celebrationPulse else 1f)
                )
                
                Text(
                    text = "(${cricketScore.teamAOvers} ov)",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = if (isTeamAWinner) NeonOrange.copy(alpha = 0.8f) else White40
                    )
                )
            }
        }
        
        Spacer(modifier = Modifier.height(20.dp))
        
        // VS indicator
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "VS",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = White40,
                    letterSpacing = 6.sp,
                    fontFamily = FontFamily.SansSerif
                )
            )
        }
        
        Spacer(modifier = Modifier.height(20.dp))
        
        // Team B
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.Start
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isTeamAWinner) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Winner",
                            tint = NeonOrange,
                            modifier = Modifier.size(24.dp)
                        )
                        
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    
                    Text(
                        text = match.teamBName,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (!isTeamAWinner) NeonOrange else White60
                        )
                    )
                }
            }
            
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "${cricketScore.teamBRuns}/${cricketScore.teamBWickets}",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black,
                        color = if (!isTeamAWinner) NeonOrange else White60,
                        fontFamily = FontFamily.SansSerif
                    ),
                    modifier = Modifier.scale(if (!isTeamAWinner) celebrationPulse else 1f)
                )
                
                Text(
                    text = "(${cricketScore.teamBOvers} ov)",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = if (!isTeamAWinner) NeonOrange.copy(alpha = 0.8f) else White40
                    )
                )
            }
        }
    }
}

@Composable
fun FinalKabaddiScoreboard(
    match: Match,
    celebrationPulse: Float
) {
    val kabaddiScore = match.kabaddiScore ?: return
    val isTeamAWinner = match.winnerId == match.teamAId
    
    Column {
        // Team A
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.Start
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isTeamAWinner) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Winner",
                            tint = NeonOrange,
                            modifier = Modifier.size(24.dp)
                        )
                        
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    
                    Text(
                        text = match.teamAName,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isTeamAWinner) NeonOrange else White60
                        )
                    )
                }
            }
            
            Text(
                text = kabaddiScore.teamAPoints.toString(),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Black,
                    color = if (isTeamAWinner) NeonOrange else White60,
                    fontFamily = FontFamily.SansSerif
                ),
                modifier = Modifier.scale(if (isTeamAWinner) celebrationPulse else 1f)
            )
        }
        
        Spacer(modifier = Modifier.height(20.dp))
        
        // VS indicator
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "VS",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = White40,
                    letterSpacing = 6.sp,
                    fontFamily = FontFamily.SansSerif
                )
            )
        }
        
        Spacer(modifier = Modifier.height(20.dp))
        
        // Team B
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.Start
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isTeamAWinner) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Winner",
                            tint = NeonOrange,
                            modifier = Modifier.size(24.dp)
                        )
                        
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    
                    Text(
                        text = match.teamBName,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (!isTeamAWinner) NeonOrange else White60
                        )
                    )
                }
            }
            
            Text(
                text = kabaddiScore.teamBPoints.toString(),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Black,
                    color = if (!isTeamAWinner) NeonOrange else White60,
                    fontFamily = FontFamily.SansSerif
                ),
                modifier = Modifier.scale(if (!isTeamAWinner) celebrationPulse else 1f)
            )
        }
    }
}

@Composable
fun FinalVolleyballScoreboard(
    match: Match,
    celebrationPulse: Float
) {
    val volleyballScore = match.volleyballScore ?: return
    val isTeamAWinner = match.winnerId == match.teamAId
    
    Column {
        // Team A
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.Start
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isTeamAWinner) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Winner",
                            tint = NeonOrange,
                            modifier = Modifier.size(24.dp)
                        )
                        
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    
                    Text(
                        text = match.teamAName,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isTeamAWinner) NeonOrange else White60
                        )
                    )
                }
            }
            
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "${volleyballScore.teamASets} sets",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isTeamAWinner) NeonOrange else White60,
                        fontFamily = FontFamily.SansSerif
                    ),
                    modifier = Modifier.scale(if (isTeamAWinner) celebrationPulse else 1f)
                )
                
                Text(
                    text = "(${volleyballScore.teamAPoints} pts)",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = if (isTeamAWinner) NeonOrange.copy(alpha = 0.8f) else White40
                    )
                )
            }
        }
        
        Spacer(modifier = Modifier.height(20.dp))
        
        // VS indicator
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "VS",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = White40,
                    letterSpacing = 6.sp,
                    fontFamily = FontFamily.SansSerif
                )
            )
        }
        
        Spacer(modifier = Modifier.height(20.dp))
        
        // Team B
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.Start
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isTeamAWinner) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Winner",
                            tint = NeonOrange,
                            modifier = Modifier.size(24.dp)
                        )
                        
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    
                    Text(
                        text = match.teamBName,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (!isTeamAWinner) NeonOrange else White60
                        )
                    )
                }
            }
            
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "${volleyballScore.teamBSets} sets",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black,
                        color = if (!isTeamAWinner) NeonOrange else White60,
                        fontFamily = FontFamily.SansSerif
                    ),
                    modifier = Modifier.scale(if (!isTeamAWinner) celebrationPulse else 1f)
                )
                
                Text(
                    text = "(${volleyballScore.teamBPoints} pts)",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = if (!isTeamAWinner) NeonOrange.copy(alpha = 0.8f) else White40
                    )
                )
            }
        }
    }
}

@Composable
fun MatchSummarySection(
    match: Match
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 6.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "MATCH SUMMARY",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            SummaryItem(
                icon = Icons.Default.CalendarToday,
                label = "Date",
                value = match.getFormattedDate()
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            SummaryItem(
                icon = Icons.Default.LocationOn,
                label = "Venue",
                value = match.venue
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            SummaryItem(
                icon = Icons.Default.SportsCricket,
                label = "Sport",
                value = match.sportType.name
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            SummaryItem(
                icon = Icons.Default.Timer,
                label = "Duration",
                value = "3h 25m"
            )
        }
    }
}

@Composable
fun SummaryItem(
    icon: ImageVector,
    label: String,
    value: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = NeonOrange,
            modifier = Modifier.size(20.dp)
        )
        
        Spacer(modifier = Modifier.width(12.dp))
        
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = White60,
                fontWeight = FontWeight.Medium
            ),
            modifier = Modifier.width(80.dp)
        )
        
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = White,
                fontWeight = FontWeight.Bold
            )
        )
    }
}

@Composable
fun MVPSection(
    match: Match,
    celebrationPulse: Float
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(celebrationPulse),
        colors = CardDefaults.cardColors(
            containerColor = NeonOrange.copy(alpha = 0.1f)
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 2.dp,
            color = NeonOrange
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Stars,
                    contentDescription = "MVP",
                    tint = NeonOrange,
                    modifier = Modifier.size(24.dp)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = "MAN OF THE MATCH",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange,
                        letterSpacing = 1.sp
                    )
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .background(
                            color = NeonOrange.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(28.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = match.mvpPlayerName?.getInitials() ?: "MVP",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = NeonOrange
                        )
                    )
                }
                
                Spacer(modifier = Modifier.width(16.dp))
                
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = match.mvpPlayerName ?: "Player Name",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NeonOrange
                        )
                    )
                    
                    Text(
                        text = match.mvpStats ?: "Outstanding Performance",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = White80
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun KeyStatisticsSection(
    match: Match
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 6.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "KEY STATISTICS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            when (match.sportType) {
                SportType.CRICKET -> CricketKeyStats(match)
                SportType.KABADDI -> KabaddiKeyStats(match)
                SportType.VOLLEYBALL -> VolleyballKeyStats(match)
            }
        }
    }
}

@Composable
fun CricketKeyStats(match: Match) {
    val cricketScore = match.cricketScore ?: return
    
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        StatRow(
            label = "Total Runs",
            teamAValue = cricketScore.teamARuns.toString(),
            teamBValue = cricketScore.teamBRuns.toString()
        )
        
        StatRow(
            label = "Wickets",
            teamAValue = cricketScore.teamAWickets.toString(),
            teamBValue = cricketScore.teamBWickets.toString()
        )
        
        StatRow(
            label = "Run Rate",
            teamAValue = String.format("%.2f", cricketScore.teamARuns / cricketScore.teamAOvers),
            teamBValue = String.format("%.2f", cricketScore.teamBRuns / cricketScore.teamBOvers)
        )
    }
}

@Composable
fun KabaddiKeyStats(match: Match) {
    val kabaddiScore = match.kabaddiScore ?: return
    
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        StatRow(
            label = "Total Points",
            teamAValue = kabaddiScore.teamAPoints.toString(),
            teamBValue = kabaddiScore.teamBPoints.toString()
        )
        
        StatRow(
            label = "Successful Raids",
            teamAValue = kabaddiScore.teamASuccessfulRaids.toString(),
            teamBValue = kabaddiScore.teamBSuccessfulRaids.toString()
        )
        
        StatRow(
            label = "Successful Tackles",
            teamAValue = kabaddiScore.teamASuccessfulTackles.toString(),
            teamBValue = kabaddiScore.teamBSuccessfulTackles.toString()
        )
    }
}

@Composable
fun VolleyballKeyStats(match: Match) {
    val volleyballScore = match.volleyballScore ?: return
    
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        StatRow(
            label = "Sets Won",
            teamAValue = volleyballScore.teamASets.toString(),
            teamBValue = volleyballScore.teamBSets.toString()
        )
        
        StatRow(
            label = "Total Points",
            teamAValue = volleyballScore.teamAPoints.toString(),
            teamBValue = volleyballScore.teamBPoints.toString()
        )
    }
}

@Composable
fun StatRow(
    label: String,
    teamAValue: String,
    teamBValue: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = White60,
                fontWeight = FontWeight.Medium
            ),
            modifier = Modifier.weight(1f)
        )
        
        Text(
            text = teamAValue,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = NeonOrange
            ),
            modifier = Modifier.width(60.dp),
            textAlign = TextAlign.Center
        )
        
        Text(
            text = teamBValue,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = White
            ),
            modifier = Modifier.width(60.dp),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun ActionButtonsSection(
    onViewScorecard: () -> Unit,
    onShare: () -> Unit,
    celebrationPulse: Float
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Button(
            onClick = onViewScorecard,
            modifier = Modifier
                .weight(1f)
                .height(56.dp)
                .scale(celebrationPulse),
            colors = ButtonDefaults.buttonColors(
                containerColor = NeonOrange
            ),
            elevation = ButtonDefaults.buttonElevation(
                defaultElevation = 8.dp
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Assessment,
                contentDescription = "Scorecard",
                tint = White,
                modifier = Modifier.size(20.dp)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = "SCORECARD",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = White,
                    letterSpacing = 1.sp
                )
            )
        }
        
        Button(
            onClick = onShare,
            modifier = Modifier
                .weight(1f)
                .height(56.dp)
                .scale(celebrationPulse),
            colors = ButtonDefaults.buttonColors(
                containerColor = NeonGreen
            ),
            elevation = ButtonDefaults.buttonElevation(
                defaultElevation = 8.dp
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = "Share",
                tint = White,
                modifier = Modifier.size(20.dp)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = "SHARE",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = White,
                    letterSpacing = 1.sp
                )
            )
        }
    }
}

// Extension function for getting initials
fun String.getInitials(): String {
    return this.split(" ").take(2).joinToString("") { 
        it.firstOrNull()?.uppercase() ?: "" 
    }
}

// Extension function for Match
fun Match.getFormattedDate(): String {
    val date = java.util.Date(scheduledDate)
    val formatter = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault())
    return formatter.format(date)
}
