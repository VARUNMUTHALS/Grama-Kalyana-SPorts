package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    onBack: () -> Unit,
    onEditProfile: () -> Unit,
    onSettings: () -> Unit,
    onLogout: () -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(200000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val profileGlow by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // User data
    val user = remember {
        User(
            id = "user_001",
            name = "Admin User",
            email = "admin@gramakalyana.sports",
            phone = "+919876543210",
            role = UserRole.ADMIN,
            profileImage = "",
            joinDate = System.currentTimeMillis() - 86400000 * 365 * 2, // 2 years ago
            totalTournaments = 15,
            totalMatches = 45,
            totalTeams = 8,
            totalPlayers = 96,
            achievements = listOf(
                "Tournament Master",
                "Scorer Pro",
                "Community Leader"
            ),
            statistics = UserStatistics(
                tournamentsCreated = 12,
                matchesScored = 38,
                teamsManaged = 8,
                playersAdded = 96,
                hoursActive = 156
            )
        )
    }
    
    val scrollState = rememberScrollState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Profile background
        ProfileBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = profileGlow
        )
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Header
            ProfileHeader(
                onBack = onBack,
                onEditProfile = onEditProfile,
                profileGlow = profileGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Profile card
            ProfileCard(
                user = user,
                profileGlow = profileGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Statistics overview
            StatisticsOverviewSection(
                user = user,
                profileGlow = profileGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Achievements section
            AchievementsSection(
                achievements = user.achievements,
                profileGlow = profileGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Activity summary
            ActivitySummarySection(
                statistics = user.statistics,
                profileGlow = profileGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Account actions
            AccountActionsSection(
                onSettings = onSettings,
                onLogout = onLogout,
                profileGlow = profileGlow
            )
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

data class User(
    val id: String,
    val name: String,
    val email: String,
    val phone: String,
    val role: UserRole,
    val profileImage: String,
    val joinDate: Long,
    val totalTournaments: Int,
    val totalMatches: Int,
    val totalTeams: Int,
    val totalPlayers: Int,
    val achievements: List<String>,
    val statistics: UserStatistics
)

data class UserStatistics(
    val tournamentsCreated: Int,
    val matchesScored: Int,
    val teamsManaged: Int,
    val playersAdded: Int,
    val hoursActive: Int
)

enum class UserRole {
    ADMIN,
    ORGANIZER,
    SCORER,
    PLAYER,
    VIEWER
}

@Composable
fun ProfileBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle profile background effect
        val positions = listOf(
            Offset(canvasWidth * 0.1f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.1f, canvasHeight * 0.9f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.9f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.5f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center pattern
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        drawCircle(
            color = NeonOrange.copy(alpha = glowAlpha * 0.05f),
            radius = min(canvasWidth, canvasHeight) * 0.3f,
            center = Offset(centerX, centerY)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileHeader(
    onBack: () -> Unit,
    onEditProfile: () -> Unit,
    profileGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val logoPulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "PROFILE",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange,
                    letterSpacing = 2.sp
                )
            )
            
            Text(
                text = "Account Overview",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White80
                )
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        IconButton(
            onClick = onEditProfile,
            modifier = Modifier
                .background(NeonOrange.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                .size(48.dp)
                .scale(logoPulse)
        ) {
            Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "Edit",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun ProfileCard(
    user: User,
    profileGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val cardPulse by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(cardPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 12.dp
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 2.dp,
            color = NeonOrange.copy(alpha = profileGlow)
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            // Profile header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Profile avatar
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(
                            color = NeonOrange.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(40.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = user.name.getInitials(),
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = NeonOrange
                        )
                    )
                }
                
                Spacer(modifier = Modifier.width(20.dp))
                
                // User info
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = user.name,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NeonOrange
                        )
                    )
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Text(
                        text = user.email,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = White80
                        )
                    )
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Text(
                        text = user.phone,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = White60
                        )
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Role badge
                    Box(
                        modifier = Modifier
                            .background(
                                color = NeonGreen.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = user.role.name,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NeonGreen,
                                letterSpacing = 1.sp
                            )
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(20.dp))
            
            // Member since
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarToday,
                    contentDescription = null,
                    tint = NeonOrange,
                    modifier = Modifier.size(20.dp)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = "Member since ${getFormattedDate(user.joinDate)}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White80
                    )
                )
            }
        }
    }
}

@Composable
fun StatisticsOverviewSection(
    user: User,
    profileGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val statsPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(statsPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "OVERVIEW STATISTICS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(20.dp))
            
            // Statistics grid
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // First row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatCard(
                        label = "TOURNAMENTS",
                        value = user.totalTournaments.toString(),
                        color = NeonOrange,
                        modifier = Modifier.weight(1f)
                    )
                    
                    StatCard(
                        label = "MATCHES",
                        value = user.totalMatches.toString(),
                        color = NeonGreen,
                        modifier = Modifier.weight(1f)
                    )
                    
                    StatCard(
                        label = "TEAMS",
                        value = user.totalTeams.toString(),
                        color = VolleyballBlue,
                        modifier = Modifier.weight(1f)
                    )
                }
                
                // Second row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatCard(
                        label = "PLAYERS",
                        value = user.totalPlayers.toString(),
                        color = KabaddiRed,
                        modifier = Modifier.weight(1f)
                    )
                    
                    StatCard(
                        label = "HOURS",
                        value = user.statistics.hoursActive.toString(),
                        color = NeonYellow,
                        modifier = Modifier.weight(1f)
                    )
                    
                    StatCard(
                        label = "ACHIEVEMENTS",
                        value = user.achievements.size.toString(),
                        color = CricketGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun StatCard(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.1f)
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Black,
                    color = color,
                    fontFamily = FontFamily.SansSerif
                )
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = White60,
                    letterSpacing = 1.sp
                )
            )
        }
    }
}

@Composable
fun AchievementsSection(
    achievements: List<String>,
    profileGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val achievementsPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(achievementsPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "ACHIEVEMENTS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                achievements.forEachIndexed { index, achievement ->
                    AchievementItem(
                        achievement = achievement,
                        index = index + 1
                    )
                }
            }
        }
    }
}

@Composable
fun AchievementItem(
    achievement: String,
    index: Int
) {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .background(
                    color = NeonOrange.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(16.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = index.toString(),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
        }
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = achievement,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = White
                )
            )
            
            Text(
                text = "Unlocked",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NeonGreen
                )
            )
        }
        
        Icon(
            imageVector = Icons.Default.EmojiEvents,
            contentDescription = null,
            tint = NeonYellow,
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
fun ActivitySummarySection(
    statistics: UserStatistics,
    profileGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val activityPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(activityPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "ACTIVITY SUMMARY",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ActivityItem(
                    icon = Icons.Default.EmojiEvents,
                    label = "Tournaments Created",
                    value = statistics.tournamentsCreated.toString(),
                    color = NeonOrange
                )
                
                ActivityItem(
                    icon = Icons.Default.SportsScore,
                    label = "Matches Scored",
                    value = statistics.matchesScored.toString(),
                    color = NeonGreen
                )
                
                ActivityItem(
                    icon = Icons.Default.Group,
                    label = "Teams Managed",
                    value = statistics.teamsManaged.toString(),
                    color = VolleyballBlue
                )
                
                ActivityItem(
                    icon = Icons.Default.PersonAdd,
                    label = "Players Added",
                    value = statistics.playersAdded.toString(),
                    color = KabaddiRed
                )
                
                ActivityItem(
                    icon = Icons.Default.Schedule,
                    label = "Hours Active",
                    value = "${statistics.hoursActive}h",
                    color = NeonYellow
                )
            }
        }
    }
}

@Composable
fun ActivityItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    color: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(24.dp)
        )
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White60
                )
            )
        }
        
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = color,
                fontFamily = FontFamily.SansSerif
            )
        )
    }
}

@Composable
fun AccountActionsSection(
    onSettings: () -> Unit,
    onLogout: () -> Unit,
    profileGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val actionsPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(actionsPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "ACCOUNT ACTIONS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Settings button
            Button(
                onClick = onSettings,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonOrange
                ),
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation = 8.dp
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = White,
                    modifier = Modifier.size(20.dp)
                )
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Text(
                    text = "SETTINGS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = White,
                        letterSpacing = 1.sp
                    )
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Logout button
            Button(
                onClick = onLogout,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonRed
                ),
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation = 8.dp
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Logout,
                    contentDescription = "Logout",
                    tint = White,
                    modifier = Modifier.size(20.dp)
                )
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Text(
                    text = "LOGOUT",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = White,
                        letterSpacing = 1.sp
                    )
                )
            }
        }
    }
}

// Helper function for getting initials
fun String.getInitials(): String {
    return this.split(" ").take(2).joinToString("") { 
        it.firstOrNull()?.uppercase() ?: "" 
    }
}

// Helper function for formatting date
fun getFormattedDate(timestamp: Long): String {
    val date = java.util.Date(timestamp)
    val formatter = java.text.SimpleDateFormat("MMM yyyy", java.util.Locale.getDefault())
    return formatter.format(date)
}
