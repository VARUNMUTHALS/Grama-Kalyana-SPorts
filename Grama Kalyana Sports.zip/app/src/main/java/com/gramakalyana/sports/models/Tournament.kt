package com.gramakalyana.sports.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.Date

@Parcelize
data class Tournament(
    val id: String = "",
    val name: String = "",
    val description: String = "",
    val sportType: SportType = SportType.CRICKET,
    val bannerImage: String = "",
    val startDate: Date = Date(),
    val endDate: Date = Date(),
    val venue: String = "",
    val address: String = "",
    val organizerName: String = "",
    val organizerContact: String = "",
    val organizerEmail: String = "",
    val teamIds: List<String> = emptyList(),
    val matchIds: List<String> = emptyList(),
    val totalTeams: Int = 0,
    val totalMatches: Int = 0,
    val matchesPlayed: Int = 0,
    val status: TournamentStatus = TournamentStatus.UPCOMING,
    val format: TournamentFormat = TournamentFormat.KNOCKOUT,
    val prizePool: String = "",
    val rules: String = "",
    val isActive: Boolean = true,
    val createdAt: Date = Date(),
    val updatedAt: Date = Date()
) : Parcelable {
    
    fun getProgressPercentage(): Float {
        return if (totalMatches > 0) (matchesPlayed.toFloat() / totalMatches.toFloat()) * 100f else 0f
    }
    
    fun getStatusDisplay(): String {
        return when (status) {
            TournamentStatus.UPCOMING -> "Upcoming"
            TournamentStatus.LIVE -> "Live"
            TournamentStatus.COMPLETED -> "Completed"
            TournamentStatus.CANCELLED -> "Cancelled"
            TournamentStatus.POSTPONED -> "Postponed"
        }
    }
    
    fun getFormatDisplay(): String {
        return when (format) {
            TournamentFormat.KNOCKOUT -> "Knockout"
            TournamentFormat.LEAGUE -> "League"
            TournamentFormat.ROUND_ROBIN -> "Round Robin"
            TournamentFormat.DOUBLE_ELIMINATION -> "Double Elimination"
            TournamentFormat.GROUP_STAGE_KNOCKOUT -> "Group Stage + Knockout"
        }
    }
    
    fun isTournamentActive(): Boolean {
        return status == TournamentStatus.LIVE || status == TournamentStatus.UPCOMING
    }
}

enum class TournamentStatus {
    UPCOMING,
    LIVE,
    COMPLETED,
    CANCELLED,
    POSTPONED
}

enum class TournamentFormat {
    KNOCKOUT,
    LEAGUE,
    ROUND_ROBIN,
    DOUBLE_ELIMINATION,
    GROUP_STAGE_KNOCKOUT
}
