package com.gramakalyana.sports.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.Date

@Parcelize
data class Team(
    val id: String = "",
    val name: String = "",
    val sportType: SportType = SportType.CRICKET,
    val logo: String = "",
    val captain: String = "",
    val contactPerson: String = "",
    val contactNumber: String = "",
    val email: String = "",
    val address: String = "",
    val description: String = "",
    val playerIds: List<String> = emptyList(),
    val totalMatches: Int = 0,
    val wins: Int = 0,
    val losses: Int = 0,
    val draws: Int = 0,
    val points: Int = 0,
    val isActive: Boolean = true,
    val createdAt: Date = Date(),
    val updatedAt: Date = Date()
) : Parcelable {
    
    fun getWinRate(): Float {
        return if (totalMatches > 0) (wins.toFloat() / totalMatches.toFloat()) * 100f else 0f
    }
    
    fun getWinRateString(): String {
        return String.format("%.1f%%", getWinRate())
    }
    
    fun getRecordString(): String {
        return "$wins-$losses${if (draws > 0) "-$draws" else ""}"
    }
}
