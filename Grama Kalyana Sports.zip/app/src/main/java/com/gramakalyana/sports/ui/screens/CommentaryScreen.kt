package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommentaryScreen(
    matchId: String,
    onBack: () -> Unit,
    onAddCommentary: () -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(100000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val liveGlow by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Commentary data (sample)
    val commentaryList = remember {
        listOf(
            CommentaryItem(
                over = "19.2",
                text = "SIX! Massive shot over deep mid-wicket! What a way to reach 180!",
                time = "Just now",
                isWicket = false,
                isBoundary = true,
                player = "Rahul Sharma"
            ),
            CommentaryItem(
                over = "19.1",
                text = "Excellent yorker, just a single to long-on.",
                time = "1 min ago",
                isWicket = false,
                isBoundary = false,
                player = "Rahul Sharma"
            ),
            CommentaryItem(
                over = "19.0",
                text = "WICKET! Bowled him! Great delivery to end the over. Clean bowled!",
                time = "2 min ago",
                isWicket = true,
                isBoundary = false,
                player = "Vikram Singh"
            ),
            CommentaryItem(
                over = "18.5",
                text = "FOUR! Beautiful cover drive, races to the boundary.",
                time = "3 min ago",
                isWicket = false,
                isBoundary = true,
                player = "Rahul Sharma"
            ),
            CommentaryItem(
                over = "18.4",
                text = "Dot ball. Good length, defended back to the bowler.",
                time = "4 min ago",
                isWicket = false,
                isBoundary = false,
                player = "Rahul Sharma"
            ),
            CommentaryItem(
                over = "18.3",
                text = "SIX! Huge hit over square leg! That's gone into the crowd!",
                time = "5 min ago",
                isWicket = false,
                isBoundary = true,
                player = "Amit Kumar"
            ),
            CommentaryItem(
                over = "18.2",
                text = "Single pushed to mid-wicket for an easy run.",
                time = "6 min ago",
                isWicket = false,
                isBoundary = false,
                player = "Rahul Sharma"
            ),
            CommentaryItem(
                over = "18.1",
                text = "WICKET! Caught behind! Excellent delivery from the bowler.",
                time = "7 min ago",
                isWicket = true,
                isBoundary = false,
                player = "Vikram Singh"
            )
        )
    }
    
    val listState = rememberLazyListState()
    
    // Auto-scroll to bottom when new commentary arrives
    LaunchedEffect(key1 = commentaryList.size) {
        delay(100)
        listState.animateScrollToItem(commentaryList.size - 1)
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Commentary background
        CommentaryBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = liveGlow
        )
        
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            CommentaryHeader(
                onBack = onBack,
                onAddCommentary = onAddCommentary,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Match info bar
            MatchInfoBar(
                matchId = matchId,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Commentary feed
            CommentaryFeed(
                commentaryList = commentaryList,
                listState = listState,
                liveGlow = liveGlow
            )
        }
    }
}

data class CommentaryItem(
    val over: String,
    val text: String,
    val time: String,
    val isWicket: Boolean,
    val isBoundary: Boolean,
    val player: String
)

@Composable
fun CommentaryBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle background effect for commentary
        val positions = listOf(
            Offset(canvasWidth * 0.1f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.1f, canvasHeight * 0.9f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.9f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.4f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.05f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommentaryHeader(
    onBack: () -> Unit,
    onAddCommentary: () -> Unit,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val livePulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        // Live indicator
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .background(
                    color = LiveRed.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(20.dp)
                )
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(LiveRed, RoundedCornerShape(4.dp))
                    .scale(livePulse)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = "LIVE COMMENTARY",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Black,
                    color = LiveRed,
                    letterSpacing = 2.sp
                )
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        // Add commentary button
        IconButton(
            onClick = onAddCommentary,
            modifier = Modifier
                .background(NeonOrange, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Add Commentary",
                tint = White,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun MatchInfoBar(
    matchId: String,
    liveGlow: Float
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Royal Warriors",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange
                    )
                )
                
                Text(
                    text = "178/5",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Black,
                        color = NeonOrange,
                        fontFamily = FontFamily.SansSerif
                    ),
                    modifier = Modifier.scale(1f + liveGlow * 0.05f)
                )
            }
            
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "VS",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = White60,
                        letterSpacing = 4.sp
                    )
                )
                
                Text(
                    text = "19.2 OV",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange
                    )
                )
            }
            
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Thunder Strikers",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = White
                    )
                )
                
                Text(
                    text = "145/8",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Black,
                        color = White,
                        fontFamily = FontFamily.SansSerif
                    )
                )
            }
        }
    }
}

@Composable
fun CommentaryFeed(
    commentaryList: List<CommentaryItem>,
    listState: androidx.compose.foundation.lazy.LazyListState,
    liveGlow: Float
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        state = listState,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(commentaryList) { commentary ->
            CommentaryCard(
                commentary = commentary,
                liveGlow = liveGlow
            )
        }
        
        // Loading indicator at bottom
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = NeonOrange,
                        strokeWidth = 2.dp
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Text(
                        text = "Loading live commentary...",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NeonOrange,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun CommentaryCard(
    commentary: CommentaryItem,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val cardGlow by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(if (commentary.isWicket || commentary.isBoundary) cardGlow else 1f),
        colors = CardDefaults.cardColors(
            containerColor = when {
                commentary.isWicket -> NeonRed.copy(alpha = 0.1f)
                commentary.isBoundary -> NeonGreen.copy(alpha = 0.1f)
                else -> MatteBlackLight
            }
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = when {
                commentary.isWicket -> 8.dp
                commentary.isBoundary -> 6.dp
                else -> 4.dp
            }
        ),
        border = when {
            commentary.isWicket -> androidx.compose.foundation.BorderStroke(
                width = 2.dp,
                color = NeonRed.copy(alpha = liveGlow)
            )
            commentary.isBoundary -> androidx.compose.foundation.BorderStroke(
                width = 2.dp,
                color = NeonGreen.copy(alpha = liveGlow)
            )
            else -> null
        }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            // Over number
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.width(60.dp)
            ) {
                Text(
                    text = commentary.over,
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = when {
                            commentary.isWicket -> NeonRed
                            commentary.isBoundary -> NeonGreen
                            else -> NeonOrange
                        },
                        fontFamily = FontFamily.SansSerif
                    )
                )
                
                if (commentary.isWicket) {
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Wicket",
                        tint = NeonRed,
                        modifier = Modifier.size(16.dp)
                    )
                } else if (commentary.isBoundary) {
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Text(
                        text = when {
                            commentary.text.contains("SIX") -> "6"
                            commentary.text.contains("FOUR") -> "4"
                            else -> "4"
                        },
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = NeonGreen
                        )
                    )
                }
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Commentary content
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = commentary.text,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White,
                        fontWeight = if (commentary.isWicket || commentary.isBoundary) FontWeight.Bold else FontWeight.Medium
                    )
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Player name
                    if (commentary.player.isNotEmpty()) {
                        Text(
                            text = commentary.player,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NeonOrange,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        Text(
                            text = "•",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = White40
                            )
                        )
                        
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    
                    // Time
                    Text(
                        text = commentary.time,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = White60
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun AddCommentaryDialog(
    isVisible: Boolean,
    onDismiss: () -> Unit,
    onAddCommentary: (String, String) -> Unit
) {
    var over by remember { mutableStateOf("") }
    var commentary by remember { mutableStateOf("") }
    
    if (isVisible) {
        AlertDialog(
            onDismissRequest = onDismiss,
            modifier = Modifier
                .fillMaxWidth()
                .background(MatteBlackLight, RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Text(
                    text = "Add Commentary",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange
                    )
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Over input
                OutlinedTextField(
                    value = over,
                    onValueChange = { over = it },
                    label = {
                        Text(
                            text = "Over",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = White80
                            )
                        )
                    },
                    placeholder = {
                        Text(
                            text = "e.g., 19.2",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = White40
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonOrange,
                        unfocusedBorderColor = White20,
                        focusedTextColor = White,
                        unfocusedTextColor = White,
                        cursorColor = NeonOrange
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Commentary input
                OutlinedTextField(
                    value = commentary,
                    onValueChange = { commentary = it },
                    label = {
                        Text(
                            text = "Commentary",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = White80
                            )
                        )
                    },
                    placeholder = {
                        Text(
                            text = "Enter match commentary...",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = White40
                            )
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonOrange,
                        unfocusedBorderColor = White20,
                        focusedTextColor = White,
                        unfocusedTextColor = White,
                        cursorColor = NeonOrange
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = White60
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            width = 1.dp,
                            color = White20
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "CANCEL",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                    
                    Button(
                        onClick = {
                            if (over.isNotEmpty() && commentary.isNotEmpty()) {
                                onAddCommentary(over, commentary)
                                onDismiss()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonOrange
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "ADD COMMENTARY",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = White
                            )
                        )
                    }
                }
            }
        }
    }
}
