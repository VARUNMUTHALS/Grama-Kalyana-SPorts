package com.gramakalyana.sports.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.gramakalyana.sports.models.Tournament
import com.gramakalyana.sports.models.TournamentStatus
import com.gramakalyana.sports.ui.theme.*
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TournamentListScreen(
    onNavigateBack: () -> Unit,
    onNavigateToTournamentDetail: (String) -> Unit,
    onNavigateToCreateTournament: () -> Unit
) {
    var selectedFilter by remember { mutableStateOf("All") }
    val filters = listOf("All", "Live", "Upcoming", "Completed")
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .background(MatteBlackLight, RoundedCornerShape(12.dp))
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = NeonOrange
                )
            }
            
            Text(
                text = "Tournaments",
                style = MaterialTheme.typography.headlineMedium,
                color = White,
                fontWeight = FontWeight.Bold
            )
            
            IconButton(
                onClick = onNavigateToCreateTournament,
                modifier = Modifier
                    .background(NeonOrange, RoundedCornerShape(12.dp))
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Create Tournament",
                    tint = White
                )
            }
        }
        
        // Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            filters.forEach { filter ->
                FilterChip(
                    onClick = { selectedFilter = filter },
                    label = {
                        Text(
                            text = filter,
                            color = if (selectedFilter == filter) MatteBlack else White
                        )
                    },
                    selected = selectedFilter == filter,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonOrange,
                        selectedLabelColor = MatteBlack,
                        containerColor = MatteBlackLight
                    )
                )
            }
        }
        
        // Tournament List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Sample tournaments - in real app, these would come from ViewModel
            val sampleTournaments = getSampleTournaments()
            
            items(sampleTournaments.filter { tournament ->
                when (selectedFilter) {
                    "All" -> true
                    "Live" -> tournament.status == TournamentStatus.LIVE
                    "Upcoming" -> tournament.status == TournamentStatus.UPCOMING
                    "Completed" -> tournament.status == TournamentStatus.COMPLETED
                    else -> true
                }
            }) { tournament ->
                TournamentCard(
                    tournament = tournament,
                    onClick = { onNavigateToTournamentDetail(tournament.id) }
                )
            }
        }
    }
}

@Composable
fun TournamentCard(
    tournament: Tournament,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Tournament Info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = tournament.name,
                        style = MaterialTheme.typography.titleLarge,
                        color = White,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    // Status Badge
                    StatusBadge(
                        status = tournament.status
                    )
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = tournament.sportType.displayName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = NeonOrange,
                    fontWeight = FontWeight.Medium
                )
                
                Text(
                    text = "${tournament.totalTeams} Teams • ${tournament.totalMatches} Matches",
                    style = MaterialTheme.typography.bodySmall,
                    color = White60
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = tournament.venue,
                    style = MaterialTheme.typography.bodySmall,
                    color = White80,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            
            // Progress Indicator
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "${tournament.getProgressPercentage().toInt()}%",
                    style = MaterialTheme.typography.headlineSmall,
                    color = NeonOrange,
                    fontWeight = FontWeight.Bold
                )
                
                Text(
                    text = "Complete",
                    style = MaterialTheme.typography.bodySmall,
                    color = White60
                )
            }
        }
    }
}

@Composable
fun StatusBadge(
    status: TournamentStatus
) {
    val (color, text) = when (status) {
        TournamentStatus.LIVE -> LiveRed to "LIVE"
        TournamentStatus.UPCOMING -> NeonYellow to "UPCOMING"
        TournamentStatus.COMPLETED -> NeonGreen to "COMPLETED"
        TournamentStatus.CANCELLED -> NeonRed to "CANCELLED"
        TournamentStatus.POSTPONED -> NeonOrange to "POSTPONED"
    }
    
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp)),
        color = color.copy(alpha = 0.2f)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}

// Sample data function - in real app, this would come from repository
private fun getSampleTournaments(): List<Tournament> {
    return listOf(
        Tournament(
            id = "1",
            name = "Grama Kalyana Cricket Championship",
            sportType = com.gramakalyana.sports.models.SportType.CRICKET,
            venue = "Village Ground, Main Street",
            totalTeams = 8,
            totalMatches = 16,
            matchesPlayed = 8,
            status = TournamentStatus.LIVE,
            startDate = Date(),
            endDate = Date(System.currentTimeMillis() + 7 * 24 * 60 * 60 * 1000)
        ),
        Tournament(
            id = "2",
            name = "Summer Kabaddi League",
            sportType = com.gramakalyana.sports.models.SportType.KABADDI,
            venue = "Community Sports Complex",
            totalTeams = 6,
            totalMatches = 15,
            matchesPlayed = 0,
            status = TournamentStatus.UPCOMING,
            startDate = Date(System.currentTimeMillis() + 2 * 24 * 60 * 60 * 1000),
            endDate = Date(System.currentTimeMillis() + 9 * 24 * 60 * 60 * 1000)
        ),
        Tournament(
            id = "3",
            name = "Village Volleyball Tournament",
            sportType = com.gramakalyana.sports.models.SportType.VOLLEYBALL,
            venue = "School Playground",
            totalTeams = 4,
            totalMatches = 6,
            matchesPlayed = 6,
            status = TournamentStatus.COMPLETED,
            startDate = Date(System.currentTimeMillis() - 7 * 24 * 60 * 60 * 1000),
            endDate = Date(System.currentTimeMillis() - 1 * 24 * 60 * 60 * 1000)
        )
    )
}
