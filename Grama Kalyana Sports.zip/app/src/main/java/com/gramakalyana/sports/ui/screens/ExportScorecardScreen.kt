package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportScorecardScreen(
    matchId: String,
    onBack: () -> Unit,
    onExport: (ExportFormat, ShareOption) -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(150000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val exportGlow by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Export states
    var selectedFormat by remember { mutableStateOf(ExportFormat.PDF) }
    var selectedShareOptions by remember { mutableStateOf(setOf<ShareOption>()) }
    var includeStatistics by remember { mutableStateOf(true) }
    var includeCommentary by remember { mutableStateOf(true) }
    var includePhotos by remember { mutableStateOf(false) }
    var isExporting by remember { mutableStateOf(false) }
    
    // Match data
    val match = remember {
        Match(
            id = matchId,
            tournamentId = "tournament_001",
            teamAId = "team_001",
            teamBId = "team_002",
            teamAName = "Royal Warriors",
            teamBName = "Thunder Strikers",
            sportType = SportType.CRICKET,
            venue = "Grama Kalyana Stadium",
            scheduledDate = System.currentTimeMillis() - 86400000,
            status = MatchStatus.COMPLETED,
            cricketScore = CricketScore(
                teamARuns = 178,
                teamAWickets = 6,
                teamAOvers = 20.0,
                teamBRuns = 145,
                teamBWickets = 8,
                teamBOvers = 18.4
            ),
            winnerId = "team_001",
            resultSummary = "Royal Warriors won by 33 runs",
            mvpPlayerName = "Rahul Sharma",
            mvpStats = "78 runs (45 balls), 2 wickets"
        )
    }
    
    val scrollState = rememberScrollState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Export background
        ExportBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = exportGlow
        )
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Header
            ExportHeader(
                onBack = onBack,
                exportGlow = exportGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Match preview card
            MatchPreviewCard(
                match = match,
                exportGlow = exportGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Export format selection
            ExportFormatSection(
                selectedFormat = selectedFormat,
                onFormatSelected = { selectedFormat = it },
                exportGlow = exportGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Share options
            ShareOptionsSection(
                selectedOptions = selectedShareOptions,
                onOptionToggle = { option, selected ->
                    if (selected) {
                        selectedShareOptions += option
                    } else {
                        selectedShareOptions -= option
                    }
                },
                exportGlow = exportGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Export options
            ExportOptionsSection(
                includeStatistics = includeStatistics,
                includeCommentary = includeCommentary,
                includePhotos = includePhotos,
                onStatisticsToggle = { includeStatistics = it },
                onCommentaryToggle = { includeCommentary = it },
                onPhotosToggle = { includePhotos = it },
                exportGlow = exportGlow
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Export button
            ExportButton(
                onClick = {
                    isExporting = true
                    onExport(selectedFormat, selectedShareOptions.firstOrNull() ?: ShareOption.DOWNLOAD)
                },
                isExporting = isExporting,
                exportGlow = exportGlow,
                isFormValid = selectedShareOptions.isNotEmpty()
            )
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

enum class ExportFormat {
    PDF,
    IMAGE,
    EXCEL,
    JSON
}

enum class ShareOption {
    DOWNLOAD,
    WHATSAPP,
    EMAIL,
    TELEGRAM,
    INSTAGRAM,
    TWITTER
}

@Composable
fun ExportBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle export background effect
        val positions = listOf(
            Offset(canvasWidth * 0.1f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.1f, canvasHeight * 0.9f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.9f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.5f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center pattern
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        drawCircle(
            color = NeonOrange.copy(alpha = glowAlpha * 0.05f),
            radius = min(canvasWidth, canvasHeight) * 0.3f,
            center = Offset(centerX, centerY)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportHeader(
    onBack: () -> Unit,
    exportGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val logoPulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "EXPORT SCORECARD",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange,
                    letterSpacing = 2.sp
                )
            )
            
            Text(
                text = "Share match results",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White80
                )
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    color = NeonOrange.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(20.dp)
                )
                .scale(logoPulse),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = "Export",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun MatchPreviewCard(
    match: Match,
    exportGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val cardPulse by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(cardPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 2.dp,
            color = NeonOrange.copy(alpha = exportGlow)
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "MATCH PREVIEW",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Match details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = match.teamAName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NeonOrange
                        )
                    )
                    
                    Text(
                        text = "${match.cricketScore?.teamARuns}/${match.cricketScore?.teamAWickets}",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = NeonOrange,
                            fontFamily = FontFamily.SansSerif
                        )
                    )
                }
                
                Text(
                    text = "VS",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = White40,
                        letterSpacing = 4.sp
                    )
                )
                
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = match.teamBName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = White
                        )
                    )
                    
                    Text(
                        text = "${match.cricketScore?.teamBRuns}/${match.cricketScore?.teamBWickets}",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = White,
                            fontFamily = FontFamily.SansSerif
                        )
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Result
            Text(
                text = match.resultSummary ?: "Match completed",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = NeonGreen,
                    fontWeight = FontWeight.Medium
                )
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "${getFormattedDate(match.scheduledDate)} • ${match.venue}",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = White60
                )
            )
        }
    }
}

@Composable
fun ExportFormatSection(
    selectedFormat: ExportFormat,
    onFormatSelected: (ExportFormat) -> Unit,
    exportGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val selectorPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "EXPORT FORMAT",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .scale(selectorPulse),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExportFormat.values().forEach { format ->
                    FormatChip(
                        format = format,
                        isSelected = selectedFormat == format,
                        onClick = { onFormatSelected(format) },
                        exportGlow = exportGlow
                    )
                }
            }
        }
    }
}

@Composable
fun FormatChip(
    format: ExportFormat,
    isSelected: Boolean,
    onClick: () -> Unit,
    exportGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val chipGlow by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val formatInfo = when (format) {
        ExportFormat.PDF -> Triple(Icons.Default.PictureAsPdf, "PDF", NeonRed)
        ExportFormat.IMAGE -> Triple(Icons.Default.Image, "IMAGE", NeonGreen)
        ExportFormat.EXCEL -> Triple(Icons.Default.TableChart, "EXCEL", VolleyballBlue)
        ExportFormat.JSON -> Triple(Icons.Default.Code, "JSON", NeonOrange)
    }
    
    Button(
        onClick = onClick,
        modifier = Modifier
            .scale(if (isSelected) chipGlow else 1f),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) formatInfo.third else MatteBlackLight,
            contentColor = if (isSelected) White else formatInfo.third
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = if (isSelected) 8.dp else 4.dp
        ),
        shape = RoundedCornerShape(20.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Icon(
            imageVector = formatInfo.first,
            contentDescription = null,
            modifier = Modifier.size(20.dp)
        )
        
        Spacer(modifier = Modifier.width(8.dp))
        
        Text(
            text = formatInfo.second,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )
    }
}

@Composable
fun ShareOptionsSection(
    selectedOptions: Set<ShareOption>,
    onOptionToggle: (ShareOption, Boolean) -> Unit,
    exportGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val selectorPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "SHARE OPTIONS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.scale(selectorPulse)
            ) {
                ShareOption.values().forEach { option ->
                    ShareOptionChip(
                        option = option,
                        isSelected = selectedOptions.contains(option),
                        onToggle = { onOptionToggle(option, it) },
                        exportGlow = exportGlow
                    )
                }
            }
        }
    }
}

@Composable
fun ShareOptionChip(
    option: ShareOption,
    isSelected: Boolean,
    onToggle: (Boolean) -> Unit,
    exportGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val chipGlow by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val optionInfo = when (option) {
        ShareOption.DOWNLOAD -> Triple(Icons.Default.Download, "Download", NeonGreen)
        ShareOption.WHATSAPP -> Triple(Icons.Default.Chat, "WhatsApp", NeonGreen)
        ShareOption.EMAIL -> Triple(Icons.Default.Email, "Email", NeonOrange)
        ShareOption.TELEGRAM -> Triple(Icons.Default.Send, "Telegram", VolleyballBlue)
        ShareOption.INSTAGRAM -> Triple(Icons.Default.CameraAlt, "Instagram", NeonRed)
        ShareOption.TWITTER -> Triple(Icons.Default.AlternateEmail, "Twitter", NeonBlue)
    }
    
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = isSelected,
            onCheckedChange = { onToggle(it) },
            colors = CheckboxDefaults.colors(
                checkedColor = optionInfo.third,
                uncheckedColor = White40
            )
        )
        
        Spacer(modifier = Modifier.width(12.dp))
        
        Card(
            onClick = { onToggle(!isSelected) },
            modifier = Modifier
                .fillMaxWidth()
                .scale(if (isSelected) chipGlow else 1f),
            colors = CardDefaults.cardColors(
                containerColor = if (isSelected) optionInfo.third.copy(alpha = 0.2f) else MatteBlackLight
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = if (isSelected) 4.dp else 2.dp
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = optionInfo.first,
                    contentDescription = null,
                    tint = optionInfo.third,
                    modifier = Modifier.size(24.dp)
                )
                
                Spacer(modifier = Modifier.width(16.dp))
                
                Text(
                    text = optionInfo.second,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) optionInfo.third else White
                    )
                )
            }
        }
    }
}

@Composable
fun ExportOptionsSection(
    includeStatistics: Boolean,
    includeCommentary: Boolean,
    includePhotos: Boolean,
    onStatisticsToggle: (Boolean) -> Unit,
    onCommentaryToggle: (Boolean) -> Unit,
    onPhotosToggle: (Boolean) -> Unit,
    exportGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val optionsPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "EXPORT OPTIONS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.scale(optionsPulse)
            ) {
                ExportOptionRow(
                    icon = Icons.Default.BarChart,
                    title = "Include Statistics",
                    description = "Detailed match statistics and player performance",
                    isChecked = includeStatistics,
                    onToggle = onStatisticsToggle,
                    color = NeonOrange
                )
                
                ExportOptionRow(
                    icon = Icons.Default.Comment,
                    title = "Include Commentary",
                    description = "Live commentary and match highlights",
                    isChecked = includeCommentary,
                    onToggle = onCommentaryToggle,
                    color = VolleyballBlue
                )
                
                ExportOptionRow(
                    icon = Icons.Default.PhotoLibrary,
                    title = "Include Photos",
                    description = "Match photos and team images",
                    isChecked = includePhotos,
                    onToggle = onPhotosToggle,
                    color = NeonGreen
                )
            }
        }
    }
}

@Composable
fun ExportOptionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    isChecked: Boolean,
    onToggle: (Boolean) -> Unit,
    color: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Switch(
            checked = isChecked,
            onCheckedChange = { onToggle(it) },
            colors = SwitchDefaults.colors(
                checkedThumbColor = color,
                checkedTrackColor = color.copy(alpha = 0.3f),
                uncheckedThumbColor = White40,
                uncheckedTrackColor = White20
            )
        )
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isChecked) color else White
                )
            )
            
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = White60
                )
            )
        }
    }
}

@Composable
fun ExportButton(
    onClick: () -> Unit,
    isExporting: Boolean,
    exportGlow: Float,
    isFormValid: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition()
    val buttonPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .scale(buttonPulse),
        enabled = !isExporting && isFormValid,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent
        ),
        contentPadding = PaddingValues(0.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            NeonOrangeDark,
                            NeonOrange,
                            NeonOrangeLight
                        )
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
                .border(
                    width = 2.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            NeonOrange.copy(alpha = exportGlow),
                            NeonOrangeLight.copy(alpha = exportGlow)
                        )
                    ),
                    shape = RoundedCornerShape(16.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isExporting) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = White,
                        strokeWidth = 2.dp
                    )
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    Text(
                        text = "EXPORTING...",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = White,
                            letterSpacing = 2.sp
                        )
                    )
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Export",
                        tint = White,
                        modifier = Modifier.size(24.dp)
                    )
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    Text(
                        text = "EXPORT SCORECARD",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = White,
                            letterSpacing = 2.sp
                        )
                    )
                }
            }
        }
    }
}

// Helper function for formatting date
fun getFormattedDate(timestamp: Long): String {
    val date = java.util.Date(timestamp)
    val formatter = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault())
    return formatter.format(date)
}
