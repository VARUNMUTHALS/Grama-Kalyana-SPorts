package com.gramakalyana.sports.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.Date

@Parcelize
data class LiveScore(
    val matchId: String = "",
    val tournamentId: String = "",
    val team1Id: String = "",
    val team2Id: String = "",
    val team1Name: String = "",
    val team2Name: String = "",
    val sportType: SportType = SportType.CRICKET,
    val isLive: Boolean = false,
    val startTime: Date = Date(),
    val currentOver: Int = 0,
    val currentBall: Int = 0,
    val lastUpdated: Date = Date(),
    
    // Cricket live data
    val team1LiveScore: CricketLiveScore = CricketLiveScore(),
    val team2LiveScore: CricketLiveScore = CricketLiveScore(),
    val currentBatsman1: String = "",
    val currentBatsman2: String = "",
    val currentBowler: String = "",
    val partnershipRuns: Int = 0,
    val partnershipBalls: Int = 0,
    val lastWicket: String = "",
    val lastWicketScore: String = "",
    
    // Kabaddi live data
    val team1KabaddiLive: KabaddiLiveScore = KabaddiLiveScore(),
    val team2KabaddiLive: KabaddiLiveScore = KabaddiLiveScore(),
    val currentRaidTeam: String = "",
    val currentRaidTime: Int = 0,
    val lastRaidResult: String = "",
    val lastTackleResult: String = "",
    
    // Volleyball live data
    val team1VolleyballLive: VolleyballLiveScore = VolleyballLiveScore(),
    val team2VolleyballLive: VolleyballLiveScore = VolleyballLiveScore(),
    val currentSet: Int = 1,
    val servingTeam: String = "",
    val lastPointWinner: String = "",
    val lastPointType: String = "",
    
    // Common live data
    val commentary: List<String> = emptyList(),
    val highlights: List<String> = emptyList(),
    val viewers: Int = 0,
    val streamUrl: String = "",
    val weather: String = "",
    val pitchCondition: String = ""
) : Parcelable

@Parcelize
data class CricketLiveScore(
    val runs: Int = 0,
    val wickets: Int = 0,
    val overs: Double = 0.0,
    val extras: Int = 0,
    val currentRunRate: Double = 0.0,
    val requiredRunRate: Double = 0.0,
    val target: Int = 0,
    val ballsRemaining: Int = 0,
    val lastBall: String = "",
    val thisOver: List<String> = emptyList(),
    val powerplay: Int = 0,
    val battingPowerplayTaken: Boolean = false
) : Parcelable

@Parcelize
data class KabaddiLiveScore(
    val totalPoints: Int = 0,
    val raidPoints: Int = 0,
    val tacklePoints: Int = 0,
    val allOutPoints: Int = 0,
    val playersOnCourt: Int = 7,
    val lastRaidPoints: Int = 0,
    val lastTacklePoints: Int = 0,
    val superTackles: Int = 0,
    val superRaids: Int = 0,
    val allOutsInflicted: Int = 0,
    val allOutsConceded: Int = 0
) : Parcelable

@Parcelize
data class VolleyballLiveScore(
    val currentSetPoints: Int = 0,
    val setsWon: Int = 0,
    val totalPoints: Int = 0,
    val timeOutsRemaining: Int = 2,
    val substitutions: Int = 0,
    val rotations: Int = 0,
    val serveAdvantage: Boolean = false,
    val lastPointScorer: String = "",
    val lastPointType: String = "",
    val currentSetTime: Long = 0L
) : Parcelable
