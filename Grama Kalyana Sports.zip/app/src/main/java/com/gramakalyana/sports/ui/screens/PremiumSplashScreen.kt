package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RadialGradientShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.R
import com.gramakalyana.sports.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.*

@Composable
fun PremiumSplashScreen(
    onNavigateToHome: () -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val neonGlow by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Staggered animations for sport icons
    val cricketAnimation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic, delayMillis = 0),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val kabaddiAnimation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic, delayMillis = 400),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val volleyballAnimation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic, delayMillis = 800),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Navigate after animation
    LaunchedEffect(key1 = true) {
        delay(3500)
        onNavigateToHome()
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Stadium floodlight background effect
        StadiumFloodlightEffect(
            modifier = Modifier.fillMaxSize(),
            glowAlpha = glowAlpha
        )
        
        // Animated sports arena atmosphere
        SportsArenaBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = rotation
        )
        
        // Main content
        Column(
            modifier = Modifier
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Premium league branding
            PremiumLeagueBadge(
                modifier = Modifier
                    .scale(pulseScale)
                    .padding(bottom = 32.dp)
            )
            
            // App logo with neon glow
            AppLogoWithGlow(
                modifier = Modifier
                    .scale(1f + neonGlow * 0.1f),
                glowIntensity = neonGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Sport icons with animations
            SportIconsRow(
                cricketAnimation = cricketAnimation,
                kabaddiAnimation = kabaddiAnimation,
                volleyballAnimation = volleyballAnimation
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // App title with premium styling
            PremiumAppTitle(
                modifier = Modifier.scale(1f + neonGlow * 0.05f)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Professional tagline
            ProfessionalTagline()
        }
        
        // Bottom branding
        BottomBranding()
    }
}

@Composable
fun StadiumFloodlightEffect(
    modifier: Modifier = Modifier,
    glowAlpha: Float
) {
    Canvas(modifier = modifier) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Create floodlight beams from corners
        val floodlightPositions = listOf(
            Offset(0f, 0f),
            Offset(canvasWidth, 0f),
            Offset(0f, canvasHeight),
            Offset(canvasWidth, canvasHeight)
        )
        
        floodlightPositions.forEach { position ->
            val gradient = RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.8f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.3f),
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 0.5f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center spotlight
        val centerGradient = RadialGradientShader(
            center = Offset(canvasWidth / 2, canvasHeight / 2),
            radius = min(canvasWidth, canvasHeight) * 0.4f,
            colors = listOf(
                Color.White.copy(alpha = glowAlpha * 0.1f),
                Color.Transparent
            ),
            colorStops = listOf(0f, 1f)
        )
        
        drawRect(
            brush = ShaderBrush(centerGradient),
            size = size
        )
    }
}

@Composable
fun SportsArenaBackground(
    modifier: Modifier = Modifier,
    rotation: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        // Draw arena circle
        drawCircle(
            color = NeonOrange.copy(alpha = 0.05f),
            radius = min(canvasWidth, canvasHeight) * 0.3f,
            center = Offset(centerX, centerY)
        )
        
        // Draw arena lines
        val numLines = 8
        for (i in 0 until numLines) {
            val angle = (i * 360f / numLines) * (PI / 180f)
            val startX = centerX + cos(angle).toFloat() * 50f
            val startY = centerY + sin(angle).toFloat() * 50f
            val endX = centerX + cos(angle).toFloat() * min(canvasWidth, canvasHeight) * 0.35f
            val endY = centerY + sin(angle).toFloat() * min(canvasWidth, canvasHeight) * 0.35f
            
            drawLine(
                color = NeonOrange.copy(alpha = 0.1f),
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = 2f
            )
        }
    }
}

@Composable
fun PremiumLeagueBadge(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(80.dp)
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(
                        NeonOrange,
                        NeonOrange.copy(alpha = 0.7f),
                        NeonOrangeDark
                    )
                ),
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "PRO",
            style = MaterialTheme.typography.labelLarge.copy(
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = White
            )
        )
    }
}

@Composable
fun AppLogoWithGlow(
    modifier: Modifier = Modifier,
    glowIntensity: Float
) {
    Box(
        modifier = modifier
    ) {
        // Glow effect
        Image(
            painter = painterResource(id = R.drawable.ic_sports_splash),
            contentDescription = "Sports App Logo",
            modifier = Modifier
                .size(140.dp)
                .blur(8.dp)
                .scale(1.2f + glowIntensity * 0.1f)
        )
        
        // Main logo
        Image(
            painter = painterResource(id = R.drawable.ic_sports_splash),
            contentDescription = "Sports App Logo",
            modifier = Modifier.size(140.dp)
        )
    }
}

@Composable
fun SportIconsRow(
    cricketAnimation: Float,
    kabaddiAnimation: Float,
    volleyballAnimation: Float
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Cricket
        SportIconWithAnimation(
            icon = "🏏",
            animation = cricketAnimation,
            color = CricketGreen
        )
        
        // Kabaddi
        SportIconWithAnimation(
            icon = "🤼",
            animation = kabaddiAnimation,
            color = KabaddiRed
        )
        
        // Volleyball
        SportIconWithAnimation(
            icon = "🏐",
            animation = volleyballAnimation,
            color = VolleyballBlue
        )
    }
}

@Composable
fun SportIconWithAnimation(
    icon: String,
    animation: Float,
    color: Color
) {
    Box(
        modifier = Modifier
            .size(60.dp)
            .scale(1f + animation * 0.2f),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = icon,
            fontSize = 36.sp,
            modifier = Modifier
                .background(
                    color = color.copy(alpha = 0.2f),
                    shape = CircleShape
                )
                .padding(12.dp)
        )
    }
}

@Composable
fun PremiumAppTitle(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "GRAMA KALYANA",
            style = MaterialTheme.typography.displayLarge.copy(
                fontSize = 42.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.SansSerif,
                color = NeonOrange,
                textAlign = TextAlign.Center
            )
        )
        
        Text(
            text = "SPORTS",
            style = MaterialTheme.typography.displayLarge.copy(
                fontSize = 36.sp,
                fontWeight = FontWeight.Light,
                fontFamily = FontFamily.SansSerif,
                color = White,
                textAlign = TextAlign.Center
            )
        )
    }
}

@Composable
fun ProfessionalTagline() {
    Text(
        text = "PROFESSIONAL TOURNAMENT MANAGEMENT",
        style = MaterialTheme.typography.bodyMedium.copy(
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = White80,
            letterSpacing = 2.sp,
            textAlign = TextAlign.Center
        ),
        modifier = Modifier.padding(horizontal = 32.dp)
    )
    
    Spacer(modifier = Modifier.height(4.dp))
    
    Text(
        text = "LIVE • SCORE • ANALYZE",
        style = MaterialTheme.typography.bodySmall.copy(
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = LimeGreen,
            letterSpacing = 4.sp,
            textAlign = TextAlign.Center
        )
    )
}

@Composable
fun BottomBranding() {
    Column(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .padding(bottom = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Premium indicator
        Text(
            text = "PREMIUM LEAGUE EDITION",
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                color = NeonOrange.copy(alpha = 0.8f),
                letterSpacing = 2.sp
            )
        )
        
        Spacer(modifier = Modifier.height(4.dp))
        
        // Version info
        Text(
            text = "v1.0.0",
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                color = White40
            )
        )
    }
}
