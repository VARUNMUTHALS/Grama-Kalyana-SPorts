package com.gramakalyana.sports.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.ui.theme.*

@Composable
fun CricketScorerControls(
    onRunsAdded: (Int) -> Unit,
    onWicketTaken: () -> Unit,
    onWideBall: () -> Unit,
    onNoBall: () -> Unit,
    onUndo: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Scoring Controls",
                style = MaterialTheme.typography.titleMedium,
                color = White,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Run buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ScorerButton(
                    text = "0",
                    onClick = { onRunsAdded(0) },
                    modifier = Modifier.weight(1f)
                )
                
                ScorerButton(
                    text = "1",
                    onClick = { onRunsAdded(1) },
                    modifier = Modifier.weight(1f)
                )
                
                ScorerButton(
                    text = "2",
                    onClick = { onRunsAdded(2) },
                    modifier = Modifier.weight(1f)
                )
                
                ScorerButton(
                    text = "3",
                    onClick = { onRunsAdded(3) },
                    modifier = Modifier.weight(1f)
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ScorerButton(
                    text = "4",
                    onClick = { onRunsAdded(4) },
                    modifier = Modifier.weight(1f),
                    color = NeonGreen
                )
                
                ScorerButton(
                    text = "6",
                    onClick = { onRunsAdded(6) },
                    modifier = Modifier.weight(1f),
                    color = NeonGreen
                )
                
                ScorerButton(
                    text = "WKT",
                    onClick = onWicketTaken,
                    modifier = Modifier.weight(1f),
                    color = NeonRed
                )
                
                ScorerButton(
                    text = "UNDO",
                    onClick = onUndo,
                    modifier = Modifier.weight(1f),
                    color = NeonOrange
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ScorerButton(
                    text = "WIDE",
                    onClick = onWideBall,
                    modifier = Modifier.weight(1f),
                    color = NeonYellow
                )
                
                ScorerButton(
                    text = "NO BALL",
                    onClick = onNoBall,
                    modifier = Modifier.weight(1f),
                    color = NeonYellow
                )
                
                Spacer(modifier = Modifier.weight(2f))
            }
        }
    }
}

@Composable
fun KabaddiScorerControls(
    onRaidPoints: (Int) -> Unit,
    onTacklePoints: (Int) -> Unit,
    onAllOut: () -> Unit,
    onSuperRaid: () -> Unit,
    onSuperTackle: () -> Unit,
    onUndo: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Kabaddi Controls",
                style = MaterialTheme.typography.titleMedium,
                color = White,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Raid Points
            Text(
                text = "Raid Points",
                style = MaterialTheme.typography.bodyMedium,
                color = NeonOrange,
                fontWeight = FontWeight.Medium
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ScorerButton(
                    text = "0",
                    onClick = { onRaidPoints(0) },
                    modifier = Modifier.weight(1f)
                )
                
                ScorerButton(
                    text = "1",
                    onClick = { onRaidPoints(1) },
                    modifier = Modifier.weight(1f)
                )
                
                ScorerButton(
                    text = "2",
                    onClick = { onRaidPoints(2) },
                    modifier = Modifier.weight(1f)
                )
                
                ScorerButton(
                    text = "3",
                    onClick = { onRaidPoints(3) },
                    modifier = Modifier.weight(1f),
                    color = NeonGreen
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Special Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ScorerButton(
                    text = "SUPER RAID",
                    onClick = onSuperRaid,
                    modifier = Modifier.weight(1f),
                    color = NeonGreen
                )
                
                ScorerButton(
                    text = "ALL OUT",
                    onClick = onAllOut,
                    modifier = Modifier.weight(1f),
                    color = NeonRed
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Tackle Points
            Text(
                text = "Tackle Points",
                style = MaterialTheme.typography.bodyMedium,
                color = NeonOrange,
                fontWeight = FontWeight.Medium
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ScorerButton(
                    text = "0",
                    onClick = { onTacklePoints(0) },
                    modifier = Modifier.weight(1f)
                )
                
                ScorerButton(
                    text = "1",
                    onClick = { onTacklePoints(1) },
                    modifier = Modifier.weight(1f)
                )
                
                ScorerButton(
                    text = "2",
                    onClick = { onTacklePoints(2) },
                    modifier = Modifier.weight(1f)
                )
                
                ScorerButton(
                    text = "SUPER",
                    onClick = onSuperTackle,
                    modifier = Modifier.weight(1f),
                    color = NeonGreen
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ScorerButton(
                    text = "UNDO",
                    onClick = onUndo,
                    modifier = Modifier.weight(1f),
                    color = NeonOrange
                )
                
                Spacer(modifier = Modifier.weight(3f))
            }
        }
    }
}

@Composable
fun VolleyballScorerControls(
    onPointScored: () -> Unit,
    onPointLost: () -> Unit,
    onTimeout: () -> Unit,
    onSubstitution: () -> Unit,
    onRotation: () -> Unit,
    onUndo: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Volleyball Controls",
                style = MaterialTheme.typography.titleMedium,
                color = White,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Point Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ScorerButton(
                    text = "POINT +",
                    onClick = onPointScored,
                    modifier = Modifier.weight(1f),
                    color = NeonGreen
                )
                
                ScorerButton(
                    text = "POINT -",
                    onClick = onPointLost,
                    modifier = Modifier.weight(1f),
                    color = NeonRed
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Game Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ScorerButton(
                    text = "TIMEOUT",
                    onClick = onTimeout,
                    modifier = Modifier.weight(1f),
                    color = NeonYellow
                )
                
                ScorerButton(
                    text = "SUB",
                    onClick = onSubstitution,
                    modifier = Modifier.weight(1f),
                    color = NeonBlue
                )
                
                ScorerButton(
                    text = "ROTATE",
                    onClick = onRotation,
                    modifier = Modifier.weight(1f),
                    color = NeonOrange
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ScorerButton(
                    text = "UNDO",
                    onClick = onUndo,
                    modifier = Modifier.weight(1f),
                    color = NeonOrange
                )
                
                Spacer(modifier = Modifier.weight(2f))
            }
        }
    }
}

@Composable
fun ScorerButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = NeonOrange
) {
    Button(
        onClick = onClick,
        modifier = modifier
            .height(56.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = color,
            contentColor = White
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 8.dp
        )
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
    }
}

@Composable
fun MatchControlButtons(
    isMatchStarted: Boolean,
    isMatchPaused: Boolean,
    onStartMatch: () -> Unit,
    onPauseMatch: () -> Unit,
    onResumeMatch: () -> Unit,
    onEndMatch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (!isMatchStarted) {
            MatchControlButton(
                text = "START MATCH",
                onClick = onStartMatch,
                color = NeonGreen,
                modifier = Modifier.weight(1f)
            )
        } else if (isMatchPaused) {
            MatchControlButton(
                text = "RESUME",
                onClick = onResumeMatch,
                color = NeonGreen,
                modifier = Modifier.weight(1f)
            )
        } else {
            MatchControlButton(
                text = "PAUSE",
                onClick = onPauseMatch,
                color = NeonYellow,
                modifier = Modifier.weight(1f)
            )
        }
        
        if (isMatchStarted) {
            MatchControlButton(
                text = "END MATCH",
                onClick = onEndMatch,
                color = NeonRed,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun MatchControlButton(
    text: String,
    onClick: () -> Unit,
    color: Color,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier
            .height(48.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = color,
            contentColor = White
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 8.dp
        )
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
        )
    }
}
