package com.gramakalyana.sports.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Dark Color Scheme for Sports Theme
private val DarkColorScheme = darkColorScheme(
    primary = NeonOrange,
    onPrimary = White,
    primaryContainer = NeonOrangeDark,
    onPrimaryContainer = White,
    secondary = NeonOrangeLight,
    onSecondary = MatteBlack,
    secondaryContainer = NeonOrange,
    onSecondaryContainer = White,
    tertiary = NeonGreen,
    onTertiary = MatteBlack,
    tertiaryContainer = NeonGreen,
    onTertiaryContainer = MatteBlack,
    error = NeonRed,
    onError = White,
    errorContainer = NeonRed,
    onErrorContainer = White,
    background = MatteBlack,
    onBackground = White,
    surface = MatteBlackLight,
    onSurface = White,
    surfaceVariant = MatteBlackDark,
    onSurfaceVariant = White80,
    outline = White40,
    outlineVariant = White20,
    scrim = Color.Black,
    inverseSurface = Color(0xFFEDE0DB),
    inverseOnSurface = Color(0xFF362B27),
    inversePrimary = NeonOrange
)

// Light Color Scheme (fallback)
private val LightColorScheme = lightColorScheme(
    primary = NeonOrange,
    onPrimary = White,
    primaryContainer = NeonOrangeLight,
    onPrimaryContainer = Color(0xFF1A0A00),
    secondary = NeonOrangeLight,
    onSecondary = Color(0xFF4A2C00),
    secondaryContainer = Color(0xFFFFD180),
    onSecondaryContainer = Color(0xFF2A1600),
    tertiary = NeonOrange,
    onTertiary = White,
    tertiaryContainer = NeonOrangeLight,
    onTertiaryContainer = Color(0xFF2A1600),
    error = Color(0xFFBA1A1A),
    onError = White,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    background = MatteBlack,
    onBackground = White,
    surface = MatteBlackLight,
    onSurface = White,
    surfaceVariant = Color(0xFF5D4037),
    onSurfaceVariant = Color(0xFFFFD7CC),
    outline = Color(0xFF9E6B58),
    outlineVariant = Color(0xFF5D4037),
    scrim = Color.Black,
    inverseSurface = Color(0xFFEDE0DB),
    inverseOnSurface = Color(0xFF362B27),
    inversePrimary = NeonOrange
)

@Composable
fun GramaKalyanaSportsTheme(
    darkTheme: Boolean = true, // Always use dark theme for sports app
    // Dynamic color is available on Android 12+
    dynamicColor: Boolean = false, // Disable dynamic color for custom sports theme
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }
    
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
