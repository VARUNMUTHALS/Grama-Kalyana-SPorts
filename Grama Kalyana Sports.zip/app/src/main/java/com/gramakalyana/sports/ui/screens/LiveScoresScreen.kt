package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.gramakalyana.sports.models.Match
import com.gramakalyana.sports.models.MatchStatus
import com.gramakalyana.sports.models.SportType
import com.gramakalyana.sports.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveScoresScreen(
    onNavigateBack: () -> Unit,
    onNavigateToMatchDetail: (String) -> Unit,
    onNavigateToLiveView: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .background(MatteBlackLight, RoundedCornerShape(12.dp))
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = NeonOrange
                )
            }
            
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(LiveRed, RoundedCornerShape(4.dp))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Live Scores",
                    style = MaterialTheme.typography.headlineMedium,
                    color = White,
                    fontWeight = FontWeight.Bold
                )
            }
            
            IconButton(
                onClick = { /* Refresh */ },
                modifier = Modifier
                    .background(MatteBlackLight, RoundedCornerShape(12.dp))
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh",
                    tint = NeonOrange
                )
            }
        }
        
        // Live Matches
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Sample live matches - in real app, these would come from ViewModel
            val liveMatches = getSampleLiveMatches()
            
            items(liveMatches) { match ->
                LiveMatchCard(
                    match = match,
                    onMatchClick = { onNavigateToMatchDetail(match.id) },
                    onLiveViewClick = { onNavigateToLiveView(match.id) }
                )
            }
        }
    }
}

@Composable
fun LiveMatchCard(
    match: Match,
    onMatchClick: () -> Unit,
    onLiveViewClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition()
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        onClick = onMatchClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp),
        colors = CardDefaults.cardColors(
            containerColor = ScoreboardBg
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header with Live indicator and sport
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(LiveRed, RoundedCornerShape(6.dp))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LIVE",
                        style = MaterialTheme.typography.labelMedium,
                        color = LiveRed,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Text(
                    text = match.sportType.displayName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = NeonOrange,
                    fontWeight = FontWeight.Medium
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Teams and Score
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Team 1
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = match.team1Name,
                        style = MaterialTheme.typography.titleMedium,
                        color = White,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        maxLines = 2
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = getTeamScore(match, 1),
                        style = ScoreboardTypography.MediumScore,
                        color = NeonOrange
                    )
                }
                
                // VS
                Text(
                    text = "VS",
                    style = MaterialTheme.typography.titleMedium,
                    color = White40,
                    fontWeight = FontWeight.Bold
                )
                
                // Team 2
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = match.team2Name,
                        style = MaterialTheme.typography.titleMedium,
                        color = White,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        maxLines = 2
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = getTeamScore(match, 2),
                        style = ScoreboardTypography.MediumScore,
                        color = NeonOrange
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Footer with venue and live view button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = match.venue,
                    style = MaterialTheme.typography.bodySmall,
                    color = White60,
                    maxLines = 1
                )
                
                FilledTonalButton(
                    onClick = onLiveViewClick,
                    modifier = Modifier.height(32.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = NeonOrange,
                        contentColor = White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.LiveTv,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Watch",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}

@Composable
fun getTeamScore(match: Match, teamNumber: Int): String {
    return when (match.sportType) {
        SportType.CRICKET -> {
            val score = if (teamNumber == 1) match.team1Score else match.team2Score
            "${score.totalRuns}/${score.wickets}"
        }
        SportType.KABADDI -> {
            val score = if (teamNumber == 1) match.team1KabaddiScore else match.team2KabaddiScore
            "${score.totalPoints}"
        }
        SportType.VOLLEYBALL -> {
            val score = if (teamNumber == 1) match.team1VolleyballScore else match.team2VolleyballScore
            "${score.points} (${score.setsWon})"
        }
    }
}

// Sample data function - in real app, this would come from repository
private fun getSampleLiveMatches(): List<Match> {
    return listOf(
        Match(
            id = "1",
            team1Name = "Royal Warriors",
            team2Name = "Thunder Strikers",
            sportType = SportType.CRICKET,
            venue = "Main Ground",
            status = MatchStatus.LIVE,
            team1Score = com.gramakalyana.sports.models.CricketScore(
                totalRuns = 145,
                totalWickets = 3,
                totalOvers = 18.5
            ),
            team2Score = com.gramakalyana.sports.models.CricketScore(
                totalRuns = 89,
                totalWickets = 2,
                totalOvers = 12.3
            )
        ),
        Match(
            id = "2",
            team1Name = "Red Raiders",
            team2Name = "Blue Eagles",
            sportType = SportType.KABADDI,
            venue = "Indoor Court",
            status = MatchStatus.LIVE,
            team1KabaddiScore = com.gramakalyana.sports.models.KabaddiScore(
                totalPoints = 28,
                raidPoints = 22,
                tacklePoints = 6
            ),
            team2KabaddiScore = com.gramakalyana.sports.models.KabaddiScore(
                totalPoints = 25,
                raidPoints = 18,
                tacklePoints = 7
            )
        ),
        Match(
            id = "3",
            team1Name = "Spartans",
            team2Name = "Titans",
            sportType = SportType.VOLLEYBALL,
            venue = "Sports Complex",
            status = MatchStatus.LIVE,
            team1VolleyballScore = com.gramakalyana.sports.models.VolleyballScore(
                points = 18,
                setsWon = 1,
                sets = listOf(25, 18)
            ),
            team2VolleyballScore = com.gramakalyana.sports.models.VolleyballScore(
                points = 21,
                setsWon = 1,
                sets = listOf(22, 21)
            )
        )
    )
}
