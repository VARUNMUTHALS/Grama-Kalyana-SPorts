package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.R
import com.gramakalyana.sports.ui.theme.*
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit,
    onForgotPassword: () -> Unit,
    onCreateAccount: () -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val stadiumRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(30000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val logoScale by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Form states
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()
    
    // Auto-scroll when keyboard appears
    LaunchedEffect(key1 = email, key2 = password) {
        delay(100)
        scrollState.animateScrollTo(scrollState.maxValue)
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Stadium background effect
        StadiumLoginBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = stadiumRotation,
            glowAlpha = glowPulse
        )
        
        // Login form content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top section with logo and welcome
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 40.dp)
            ) {
                // App logo with glow
                LoginLogoWithGlow(
                    modifier = Modifier.scale(logoScale),
                    glowIntensity = glowPulse
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Welcome text
                Text(
                    text = "Welcome Back",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Black,
                        color = NeonOrange,
                        textAlign = TextAlign.Center,
                        fontSize = 32.sp
                    )
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Enter your credentials to access your sports dashboard",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = White80,
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Sports tagline
                Text(
                    text = "PROFESSIONAL • TOURNAMENTS • LIVE SCORING",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = LimeGreen,
                        textAlign = TextAlign.Center,
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
            
            // Login form
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 32.dp)
            ) {
                // Email field
                PremiumTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = "Email Address",
                    placeholder = "Enter your email",
                    leadingIcon = Icons.Default.Email,
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next,
                    onImeAction = {
                        focusManager.moveFocus(FocusDirection.Down)
                    },
                    errorMessage = if (email.isNotEmpty() && !email.isValidEmail()) 
                        "Please enter a valid email address" else null
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Password field
                PremiumTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = "Password",
                    placeholder = "Enter your password",
                    leadingIcon = Icons.Default.Lock,
                    trailingIcon = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                    isPassword = !isPasswordVisible,
                    onTrailingIconClick = { isPasswordVisible = !isPasswordVisible },
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done,
                    onImeAction = {
                        focusManager.clearFocus()
                        // Handle login
                    },
                    errorMessage = if (password.isNotEmpty() && password.length < 6)
                        "Password must be at least 6 characters" else null
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Error message
                errorMessage?.let {
                    Text(
                        text = it,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NeonRed
                        ),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                }
                
                // Login button
                PremiumGradientButton(
                    text = "SIGN IN",
                    onClick = {
                        if (email.isValidEmail() && password.length >= 6) {
                            isLoading = true
                            // TODO: Implement Firebase authentication
                            // For now, simulate login
                            kotlinx.coroutines.GlobalScope.launch {
                                delay(2000)
                                isLoading = false
                                onLoginSuccess()
                            }
                        } else {
                            errorMessage = "Please enter valid credentials"
                        }
                    },
                    isLoading = isLoading,
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Forgot password
                TextButton(
                    onClick = onForgotPassword,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Forgot Password?",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = NeonOrange,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
            
            // Bottom section
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 32.dp)
            ) {
                // Divider with OR
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HorizontalDivider(
                        modifier = Modifier.weight(1f),
                        color = White20
                    )
                    
                    Text(
                        text = "OR",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = White60
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    
                    HorizontalDivider(
                        modifier = Modifier.weight(1f),
                        color = White20
                    )
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Create account button
                OutlinedButton(
                    onClick = onCreateAccount,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = NeonOrange
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        width = 2.dp,
                        color = NeonOrange
                    )
                ) {
                    Text(
                        text = "CREATE NEW ACCOUNT",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Premium badge
                PremiumLoginBadge()
            }
        }
    }
}

@Composable
fun StadiumLoginBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        // Stadium floodlight effect
        val floodlightPositions = listOf(
            Offset(0f, 0f),
            Offset(canvasWidth, 0f),
            Offset(0f, canvasHeight),
            Offset(canvasWidth, canvasHeight)
        )
        
        floodlightPositions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.6f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.2f),
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 0.5f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center arena circle
        drawCircle(
            color = NeonOrange.copy(alpha = glowAlpha * 0.05f),
            radius = min(canvasWidth, canvasHeight) * 0.4f,
            center = Offset(centerX, centerY)
        )
        
        // Arena lines
        val numLines = 6
        for (i in 0 until numLines) {
            val angle = (i * 360f / numLines) * (PI / 180f)
            val startX = centerX + cos(angle).toFloat() * 100f
            val startY = centerY + sin(angle).toFloat() * 100f
            val endX = centerX + cos(angle).toFloat() * min(canvasWidth, canvasHeight) * 0.35f
            val endY = centerY + sin(angle).toFloat() * min(canvasWidth, canvasHeight) * 0.35f
            
            drawLine(
                color = NeonOrange.copy(alpha = glowAlpha * 0.1f),
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = 2f
            )
        }
    }
}

@Composable
fun LoginLogoWithGlow(
    modifier: Modifier = Modifier,
    glowIntensity: Float
) {
    Box(
        modifier = modifier
    ) {
        // Glow effect
        Image(
            painter = painterResource(id = R.drawable.ic_premium_sports),
            contentDescription = "Sports App Logo",
            modifier = Modifier
                .size(120.dp)
                .blur(12.dp)
                .scale(1.3f + glowIntensity * 0.2f)
        )
        
        // Main logo
        Image(
            painter = painterResource(id = R.drawable.ic_premium_sports),
            contentDescription = "Sports App Logo",
            modifier = Modifier.size(120.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PremiumTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    leadingIcon: ImageVector,
    trailingIcon: ImageVector? = null,
    isPassword: Boolean = false,
    onTrailingIconClick: (() -> Unit)? = null,
    keyboardType: KeyboardType,
    imeAction: ImeAction,
    onImeAction: () -> Unit,
    errorMessage: String? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White80
                    )
                )
            },
            placeholder = {
                Text(
                    text = placeholder,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White40
                    )
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = leadingIcon,
                    contentDescription = null,
                    tint = NeonOrange,
                    modifier = Modifier.size(24.dp)
                )
            },
            trailingIcon = trailingIcon?.let { icon ->
                {
                    IconButton(
                        onClick = { onTrailingIconClick?.invoke() }
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = White60,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            },
            visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(
                keyboardType = keyboardType,
                imeAction = imeAction
            ),
            keyboardActions = KeyboardActions(
                onAny = { onImeAction() }
            ),
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonOrange,
                unfocusedBorderColor = White20,
                focusedTextColor = White,
                unfocusedTextColor = White,
                cursorColor = NeonOrange,
                focusedLabelColor = NeonOrange,
                unfocusedLabelColor = White60
            ),
            shape = RoundedCornerShape(12.dp),
            isError = errorMessage != null
        )
        
        // Error message
        errorMessage?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NeonRed
                ),
                modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
        }
    }
}

@Composable
fun PremiumGradientButton(
    text: String,
    onClick: () -> Unit,
    isLoading: Boolean = false,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition()
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Button(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp),
        enabled = !isLoading,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent
        ),
        contentPadding = PaddingValues(0.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            NeonOrangeDark,
                            NeonOrange,
                            NeonOrangeLight
                        )
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                .border(
                    width = 2.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            NeonOrange.copy(alpha = glowPulse),
                            NeonOrangeLight.copy(alpha = glowPulse)
                        )
                    ),
                    shape = RoundedCornerShape(12.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = White,
                    strokeWidth = 2.dp
                )
            } else {
                Text(
                    text = text,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = White,
                        letterSpacing = 2.sp
                    )
                )
            }
        }
    }
}

@Composable
fun PremiumLoginBadge() {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .background(
                    color = NeonOrange.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(12.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "PRO",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black,
                    color = NeonOrange
                )
            )
        }
        
        Spacer(modifier = Modifier.width(8.dp))
        
        Text(
            text = "Premium League Edition",
            style = MaterialTheme.typography.bodySmall.copy(
                color = White60,
                fontWeight = FontWeight.Medium
            )
        )
    }
}

// Extension function for email validation
fun String.isValidEmail(): Boolean {
    return android.util.Patterns.EMAIL_ADDRESS.matcher(this).matches()
}
