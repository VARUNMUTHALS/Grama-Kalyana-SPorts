package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamManagementScreen(
    tournamentId: String,
    onBack: () -> Unit,
    onAddTeam: () -> Unit,
    onTeamClick: (String) -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(140000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val liveGlow by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Team data
    val teams = remember {
        listOf(
            Team(
                id = "team_001",
                name = "Royal Warriors",
                logo = "https://example.com/logo1.png",
                captain = "Rahul Sharma",
                totalPlayers = 11,
                wins = 8,
                losses = 2,
                points = 16,
                status = TeamStatus.ACTIVE,
                sportType = SportType.CRICKET,
                foundedYear = 2020,
                homeGround = "Grama Kalyana Stadium"
            ),
            Team(
                id = "team_002",
                name = "Thunder Strikers",
                logo = "https://example.com/logo2.png",
                captain = "Vikram Singh",
                totalPlayers = 11,
                wins = 6,
                losses = 4,
                points = 12,
                status = TeamStatus.ACTIVE,
                sportType = SportType.CRICKET,
                foundedYear = 2019,
                homeGround = "Community Sports Ground"
            ),
            Team(
                id = "team_003",
                name = "Lions Club",
                logo = "https://example.com/logo3.png",
                captain = "Amit Kumar",
                totalPlayers = 7,
                wins = 5,
                losses = 1,
                points = 10,
                status = TeamStatus.ACTIVE,
                sportType = SportType.KABADDI,
                foundedYear = 2021,
                homeGround = "Youth Sports Complex"
            ),
            Team(
                id = "team_004",
                name = "Eagles Team",
                logo = "https://example.com/logo4.png",
                captain = "Sanjay Patel",
                totalPlayers = 6,
                wins = 3,
                losses = 3,
                points = 6,
                status = TeamStatus.ACTIVE,
                sportType = SportType.KABADDI,
                foundedYear = 2020,
                homeGround = "Beach Sports Arena"
            ),
            Team(
                id = "team_005",
                name = "Sharks Volleyball",
                logo = "https://example.com/logo5.png",
                captain = "Rohit Verma",
                totalPlayers = 12,
                wins = 7,
                losses = 3,
                points = 14,
                status = TeamStatus.ACTIVE,
                sportType = SportType.VOLLEYBALL,
                foundedYear = 2018,
                homeGround = "Indoor Sports Complex"
            )
        )
    }
    
    val listState = rememberLazyListState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Team management background
        TeamManagementBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = liveGlow
        )
        
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            TeamManagementHeader(
                onBack = onBack,
                onAddTeam = onAddTeam,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Tournament info
            TournamentInfoCard(
                tournamentId = tournamentId,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Team statistics summary
            TeamStatisticsSummary(
                teams = teams,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Team list
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                state = listState,
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(teams) { team ->
                    TeamCard(
                        team = team,
                        onClick = { onTeamClick(team.id) },
                        liveGlow = liveGlow
                    )
                }
            }
        }
    }
}

@Composable
fun TeamManagementBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle team management background effect
        val positions = listOf(
            Offset(canvasWidth * 0.1f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.1f, canvasHeight * 0.9f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.9f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.5f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center pattern
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        drawCircle(
            color = NeonOrange.copy(alpha = glowAlpha * 0.05f),
            radius = min(canvasWidth, canvasHeight) * 0.3f,
            center = Offset(centerX, centerY)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamManagementHeader(
    onBack: () -> Unit,
    onAddTeam: () -> Unit,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val buttonPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Text(
            text = "TEAM MANAGEMENT",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                color = NeonOrange,
                letterSpacing = 2.sp
            )
        )
        
        Spacer(modifier = Modifier.weight(1f))
        
        Button(
            onClick = onAddTeam,
            modifier = Modifier
                .scale(buttonPulse),
            colors = ButtonDefaults.buttonColors(
                containerColor = NeonOrange
            ),
            elevation = ButtonDefaults.buttonElevation(
                defaultElevation = 8.dp
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Add Team",
                tint = White,
                modifier = Modifier.size(20.dp)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = "ADD TEAM",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = White,
                    letterSpacing = 1.sp
                )
            )
        }
    }
}

@Composable
fun TournamentInfoCard(
    tournamentId: String,
    liveGlow: Float
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 6.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "Grama Kalyana Premier League",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange
                    )
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = "Cricket Tournament • 8 Teams",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White80
                    )
                )
            }
            
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(LiveRed, RoundedCornerShape(4.dp))
                        .scale(1f + liveGlow * 0.3f)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = "LIVE",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = LiveRed,
                        letterSpacing = 1.sp
                    )
                )
            }
        }
    }
}

@Composable
fun TeamStatisticsSummary(
    teams: List<Team>,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val statsPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .scale(statsPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TeamStatItem(
                label = "TOTAL TEAMS",
                value = teams.size.toString(),
                color = NeonOrange
            )
            
            VerticalDivider(
                modifier = Modifier.height(40.dp),
                color = White20
            )
            
            TeamStatItem(
                label = "ACTIVE",
                value = teams.count { it.status == TeamStatus.ACTIVE }.toString(),
                color = NeonGreen
            )
            
            VerticalDivider(
                modifier = Modifier.height(40.dp),
                color = White20
            )
            
            TeamStatItem(
                label = "TOTAL PLAYERS",
                value = teams.sumOf { it.totalPlayers }.toString(),
                color = VolleyballBlue
            )
        }
    }
}

@Composable
fun TeamStatItem(
    label: String,
    value: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Black,
                color = color,
                fontFamily = FontFamily.SansSerif
            )
        )
        
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = White60,
                letterSpacing = 1.sp
            )
        )
    }
}

@Composable
fun TeamCard(
    team: Team,
    onClick: () -> Unit,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val cardPulse by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .scale(cardPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header with team info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Team logo placeholder
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(
                                color = NeonOrange.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(24.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = team.name.getInitials(),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                color = NeonOrange
                            )
                        )
                    }
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    Column {
                        Text(
                            text = team.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = White
                            )
                        )
                        
                        Text(
                            text = "Captain: ${team.captain}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = White60
                            )
                        )
                    }
                }
                
                // Sport type badge
                SportTypeBadge(
                    sportType = team.sportType,
                    isLive = false,
                    size = SportBadgeSize.SMALL
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Team statistics
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TeamPerformanceStat(
                    label = "PLAYERS",
                    value = team.totalPlayers.toString(),
                    color = White80
                )
                
                TeamPerformanceStat(
                    label = "WINS",
                    value = team.wins.toString(),
                    color = NeonGreen
                )
                
                TeamPerformanceStat(
                    label = "LOSSES",
                    value = team.losses.toString(),
                    color = NeonRed
                )
                
                TeamPerformanceStat(
                    label = "POINTS",
                    value = team.points.toString(),
                    color = NeonOrange
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Footer with additional info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = White60,
                        modifier = Modifier.size(16.dp)
                    )
                    
                    Spacer(modifier = Modifier.width(6.dp))
                    
                    Text(
                        text = team.homeGround,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = White80
                        ),
                        maxLines = 1
                    )
                }
                
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "EST. ${team.foundedYear}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = White60
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun TeamPerformanceStat(
    label: String,
    value: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = color,
                fontFamily = FontFamily.SansSerif
            )
        )
        
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = White60,
                letterSpacing = 1.sp
            )
        )
    }
}

// Extension function for getting initials
fun String.getInitials(): String {
    return this.split(" ").take(2).joinToString("") { 
        it.firstOrNull()?.uppercase() ?: "" 
    }
}
