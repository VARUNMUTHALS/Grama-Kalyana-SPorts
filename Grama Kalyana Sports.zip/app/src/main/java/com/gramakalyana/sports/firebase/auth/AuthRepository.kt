package com.gramakalyana.sports.firebase.auth

import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.gramakalyana.sports.firebase.FirebaseManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * Authentication Repository - Handles all Firebase Authentication operations
 * Provides a clean interface for authentication-related operations
 */
class AuthRepository private constructor() {
    
    private val auth: FirebaseAuth by lazy { FirebaseManager.getAuth() }
    private val database = FirebaseManager.getDatabase()
    
    /**
     * Get current user
     */
    val currentUser: FirebaseUser?
        get() = auth.currentUser
    
    /**
     * Check if user is authenticated
     */
    val isUserAuthenticated: Boolean
        get() = currentUser != null
    
    /**
     * Authentication state flow - emits authentication state changes
     */
    val authenticationStateFlow: Flow<AuthenticationState> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            val state = if (user != null) {
                AuthenticationState.Authenticated(user)
            } else {
                AuthenticationState.Unauthenticated
            }
            trySend(state)
        }
        
        auth.addAuthStateListener(listener)
        
        awaitClose {
            auth.removeAuthStateListener(listener)
        }
    }
    
    /**
     * Sign up with email and password
     */
    suspend fun signUp(
        email: String,
        password: String,
        name: String
    ): Result<AuthResult> {
        return try {
            // Validate input
            if (email.isBlank() || password.isBlank() || name.isBlank()) {
                Result.failure(AuthException.InvalidInput("Email, password, and name cannot be empty"))
            } else if (password.length < 6) {
                Result.failure(AuthException.WeakPassword("Password must be at least 6 characters"))
            } else if (!isValidEmail(email)) {
                Result.failure(AuthException.InvalidEmail("Invalid email format"))
            } else {
                // Create user with email and password
                val authResult = auth.createUserWithEmailAndPassword(email, password).await()
                
                // Update user profile with name
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(name)
                    .build()
                
                authResult.user?.updateProfile(profileUpdates)?.await()
                
                // Create user profile in database
                authResult.user?.let { firebaseUser ->
                    createUserProfileInDatabase(firebaseUser, name)
                }
                
                Result.success(authResult)
            }
        } catch (e: Exception) {
            Result.failure(handleAuthException(e))
        }
    }
    
    /**
     * Sign in with email and password
     */
    suspend fun signIn(email: String, password: String): Result<AuthResult> {
        return try {
            if (email.isBlank() || password.isBlank()) {
                Result.failure(AuthException.InvalidInput("Email and password cannot be empty"))
            } else {
                val authResult = auth.signInWithEmailAndPassword(email, password).await()
                Result.success(authResult)
            }
        } catch (e: Exception) {
            Result.failure(handleAuthException(e))
        }
    }
    
    /**
     * Sign out current user
     */
    suspend fun signOut(): Result<Unit> {
        return try {
            auth.signOut()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(AuthException.SignOutFailed("Failed to sign out: ${e.message}"))
        }
    }
    
    /**
     * Send password reset email
     */
    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        return try {
            if (email.isBlank()) {
                Result.failure(AuthException.InvalidInput("Email cannot be empty"))
            } else if (!isValidEmail(email)) {
                Result.failure(AuthException.InvalidEmail("Invalid email format"))
            } else {
                auth.sendPasswordResetEmail(email).await()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(handleAuthException(e))
        }
    }
    
    /**
     * Update user profile
     */
    suspend fun updateProfile(name: String): Result<Unit> {
        return try {
            if (name.isBlank()) {
                Result.failure(AuthException.InvalidInput("Name cannot be empty"))
            } else {
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(name)
                    .build()
                
                currentUser?.updateProfile(profileUpdates)?.await()
                
                // Update name in database
                currentUser?.let { firebaseUser ->
                    FirebaseManager.getCurrentUserReference()
                        ?.child("name")
                        ?.setValue(name)
                        ?.await()
                }
                
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(AuthException.ProfileUpdateFailed("Failed to update profile: ${e.message}"))
        }
    }
    
    /**
     * Update user email
     */
    suspend fun updateEmail(newEmail: String): Result<Unit> {
        return try {
            if (newEmail.isBlank()) {
                Result.failure(AuthException.InvalidInput("Email cannot be empty"))
            } else if (!isValidEmail(newEmail)) {
                Result.failure(AuthException.InvalidEmail("Invalid email format"))
            } else {
                currentUser?.updateEmail(newEmail)?.await()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(handleAuthException(e))
        }
    }
    
    /**
     * Update user password
     */
    suspend fun updatePassword(newPassword: String): Result<Unit> {
        return try {
            if (newPassword.isBlank()) {
                Result.failure(AuthException.InvalidInput("Password cannot be empty"))
            } else if (newPassword.length < 6) {
                Result.failure(AuthException.WeakPassword("Password must be at least 6 characters"))
            } else {
                currentUser?.updatePassword(newPassword)?.await()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(handleAuthException(e))
        }
    }
    
    /**
     * Delete user account
     */
    suspend fun deleteAccount(): Result<Unit> {
        return try {
            // Delete user profile from database
            currentUser?.let { firebaseUser ->
                FirebaseManager.getCurrentUserReference()?.removeValue()?.await()
            }
            
            // Delete Firebase Auth account
            currentUser?.delete()?.await()
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(AuthException.AccountDeletionFailed("Failed to delete account: ${e.message}"))
        }
    }
    
    /**
     * Reload user data
     */
    suspend fun reloadUser(): Result<FirebaseUser> {
        return try {
            currentUser?.reload()?.await()
            Result.success(currentUser!!)
        } catch (e: Exception) {
            Result.failure(AuthException.UserReloadFailed("Failed to reload user: ${e.message}"))
        }
    }
    
    /**
     * Create user profile in Firebase Realtime Database
     */
    private suspend fun createUserProfileInDatabase(user: FirebaseUser, name: String) {
        val userProfile = mapOf(
            "uid" to user.uid,
            "email" to user.email,
            "name" to name,
            "createdAt" to System.currentTimeMillis(),
            "lastLoginAt" to System.currentTimeMillis(),
            "isEmailVerified" to user.isEmailVerified,
            "role" to "USER"
        )
        
        FirebaseManager.usersRef.child(user.uid).setValue(userProfile).await()
    }
    
    /**
     * Validate email format
     */
    private fun isValidEmail(email: String): Boolean {
        val emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"
        return email.matches(emailPattern.toRegex())
    }
    
    /**
     * Handle Firebase authentication exceptions and convert to custom exceptions
     */
    private fun handleAuthException(exception: Exception): AuthException {
        return when (exception.message) {
            "The email address is badly formatted." -> AuthException.InvalidEmail("Invalid email format")
            "The password is invalid or the user does not have a password." -> AuthException.InvalidPassword("Invalid password")
            "The email address is already in use by another account." -> AuthException.EmailAlreadyInUse("Email already registered")
            "There is no user record corresponding to this identifier." -> AuthException.UserNotFound("User not found")
            "The password is invalid or the user does not have a password." -> AuthException.InvalidPassword("Invalid password")
            "A network error (such as timeout, interrupted connection, or unreachable host) has occurred." -> AuthException.NetworkError("Network error. Please check your connection.")
            else -> AuthException.UnknownError("Authentication failed: ${exception.message}")
        }
    }
    
    companion object {
        @Volatile
        private var INSTANCE: AuthRepository? = null
        
        fun getInstance(): AuthRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AuthRepository().also { INSTANCE = it }
            }
        }
    }
}

/**
 * Authentication state sealed class
 */
sealed class AuthenticationState {
    data class Authenticated(val user: FirebaseUser) : AuthenticationState()
    object Unauthenticated : AuthenticationState()
}

/**
 * Custom authentication exceptions
 */
sealed class AuthException(message: String) : Exception(message) {
    class InvalidInput(message: String) : AuthException(message)
    class InvalidEmail(message: String) : AuthException(message)
    class InvalidPassword(message: String) : AuthException(message)
    class WeakPassword(message: String) : AuthException(message)
    class EmailAlreadyInUse(message: String) : AuthException(message)
    class UserNotFound(message: String) : AuthException(message)
    class NetworkError(message: String) : AuthException(message)
    class SignOutFailed(message: String) : AuthException(message)
    class ProfileUpdateFailed(message: String) : AuthException(message)
    class AccountDeletionFailed(message: String) : AuthException(message)
    class UserReloadFailed(message: String) : AuthException(message)
    class UnknownError(message: String) : AuthException(message)
}
