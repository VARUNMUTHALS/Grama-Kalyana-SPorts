package com.gramakalyana.sports.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.Date

@Parcelize
data class Match(
    val id: String = "",
    val tournamentId: String = "",
    val team1Id: String = "",
    val team2Id: String = "",
    val team1Name: String = "",
    val team2Name: String = "",
    val team1Logo: String = "",
    val team2Logo: String = "",
    val sportType: SportType = SportType.CRICKET,
    val venue: String = "",
    val scheduledDate: Date = Date(),
    val scheduledTime: String = "",
    val status: MatchStatus = MatchStatus.SCHEDULED,
    val matchType: MatchType = MatchType.GROUP,
    val round: String = "",
    val matchNumber: Int = 0,
    
    // Cricket specific
    val team1Score: CricketScore = CricketScore(),
    val team2Score: CricketScore = CricketScore(),
    val overs: Int = 0,
    val innings: Int = 2,
    val currentInnings: Int = 1,
    val tossWinner: String = "",
    val tossDecision: String = "",
    
    // Kabaddi specific
    val team1KabaddiScore: KabaddiScore = KabaddiScore(),
    val team2KabaddiScore: KabaddiScore = KabaddiScore(),
    val raidTime: Int = 30,
    val totalRaidTime: Int = 40,
    
    // Volleyball specific
    val team1VolleyballScore: VolleyballScore = VolleyballScore(),
    val team2VolleyballScore: VolleyballScore = VolleyballScore(),
    val setsToWin: Int = 3,
    val pointsPerSet: Int = 25,
    
    // Common
    val manOfTheMatch: String = "",
    val bestPlayer: String = "",
    val highlights: List<String> = emptyList(),
    val commentary: List<String> = emptyList(),
    val startTime: Date? = null,
    val endTime: Date? = null,
    val duration: Long = 0L,
    val isActive: Boolean = true,
    val createdAt: Date = Date(),
    val updatedAt: Date = Date()
) : Parcelable {
    
    fun getWinner(): String {
        return when (sportType) {
            SportType.CRICKET -> {
                when {
                    team1Score.totalRuns > team2Score.totalRuns -> team1Name
                    team2Score.totalRuns > team1Score.totalRuns -> team2Name
                    else -> "Draw"
                }
            }
            SportType.KABADDI -> {
                when {
                    team1KabaddiScore.totalPoints > team2KabaddiScore.totalPoints -> team1Name
                    team2KabaddiScore.totalPoints > team1KabaddiScore.totalPoints -> team2Name
                    else -> "Draw"
                }
            }
            SportType.VOLLEYBALL -> {
                when {
                    team1VolleyballScore.setsWon > team2VolleyballScore.setsWon -> team1Name
                    team2VolleyballScore.setsWon > team1VolleyballScore.setsWon -> team2Name
                    else -> "Draw"
                }
            }
        }
    }
    
    fun getScoreDisplay(): String {
        return when (sportType) {
            SportType.CRICKET -> "${team1Score.totalRuns}/${team1Score.wickets} (${team1Score.overs}) vs ${team2Score.totalRuns}/${team2Score.wickets} (${team2Score.overs})"
            SportType.KABADDI -> "${team1KabaddiScore.totalPoints} vs ${team2KabaddiScore.totalPoints}"
            SportType.VOLLEYBALL -> "${team1VolleyballScore.setsWon} sets vs ${team2VolleyballScore.setsWon} sets"
        }
    }
    
    fun isLive(): Boolean {
        return status == MatchStatus.LIVE || status == MatchStatus.BREAK || status == MatchStatus.IN_PROGRESS
    }
    
    fun isCompleted(): Boolean {
        return status == MatchStatus.COMPLETED || status == MatchStatus.ABANDONED || status == MatchStatus.CANCELLED
    }
}

@Parcelize
data class CricketScore(
    val runs: Int = 0,
    val wickets: Int = 0,
    val overs: Double = 0.0,
    val totalRuns: Int = 0,
    val totalWickets: Int = 0,
    val totalOvers: Double = 0.0,
    val extras: Int = 0,
    val byes: Int = 0,
    val legByes: Int = 0,
    val wides: Int = 0,
    val noBalls: Int = 0,
    val fours: Int = 0,
    val sixes: Int = 0,
    val strikeRate: Double = 0.0,
    val runRate: Double = 0.0
) : Parcelable

@Parcelize
data class KabaddiScore(
    val raidPoints: Int = 0,
    val tacklePoints: Int = 0,
    val allOutPoints: Int = 0,
    val extraPoints: Int = 0,
    val totalPoints: Int = 0,
    val totalRaids: Int = 0,
    val successfulRaids: Int = 0,
    val unsuccessfulRaids: Int = 0,
    val totalTackles: Int = 0,
    val successfulTackles: Int = 0,
    val unsuccessfulTackles: Int = 0,
    val allOutsConceded: Int = 0,
    val allOutsInflicted: Int = 0,
    val superRaids: Int = 0,
    val superTackles: Int = 0
) : Parcelable

@Parcelize
data class VolleyballScore(
    val points: Int = 0,
    val sets: List<Int> = emptyList(),
    val setsWon: Int = 0,
    val setsLost: Int = 0,
    val totalPoints: Int = 0,
    val servicePoints: Int = 0,
    val attackPoints: Int = 0,
    val blockPoints: Int = 0,
    val opponentErrors: Int = 0,
    val timeOutsTaken: Int = 0,
    val substitutions: Int = 0
) : Parcelable

enum class MatchStatus {
    SCHEDULED,
    LIVE,
    IN_PROGRESS,
    BREAK,
    COMPLETED,
    ABANDONED,
    CANCELLED,
    POSTPONED
}

enum class MatchType {
    GROUP,
    QUARTER_FINAL,
    SEMI_FINAL,
    FINAL,
    THIRD_PLACE,
    QUALIFIER,
    FRIENDLY
}
