package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeaderboardScreen(
    tournamentId: String,
    onBack: () -> Unit,
    onFilterChange: (LeaderboardFilter) -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(160000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val rankingGlow by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Leaderboard data
    var selectedFilter by remember { mutableStateOf(LeaderboardFilter.TEAMS) }
    val leaderboardData = remember {
        when (selectedFilter) {
            LeaderboardFilter.TEAMS -> getTeamsLeaderboard()
            LeaderboardFilter.RUNS -> getRunsLeaderboard()
            LeaderboardFilter.WICKETS -> getWicketsLeaderboard()
            LeaderboardFilter.POINTS -> getPointsLeaderboard()
            LeaderboardFilter.MVP -> getMVPLeaderboard()
        }
    }
    
    val listState = rememberLazyListState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Leaderboard background
        LeaderboardBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = rankingGlow
        )
        
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            LeaderboardHeader(
                onBack = onBack,
                rankingGlow = rankingGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Filter tabs
            LeaderboardFilterTabs(
                selectedFilter = selectedFilter,
                onFilterSelected = { filter ->
                    selectedFilter = filter
                    onFilterChange(filter)
                },
                rankingGlow = rankingGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Top 3 podium
            TopThreePodium(
                data = leaderboardData.take(3),
                filter = selectedFilter,
                rankingGlow = rankingGlow
            )
            
            Spacer(modifier = Modifier.height(20.dp))
            
            // Leaderboard list
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                state = listState,
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(leaderboardData.drop(3).size) { index ->
                    LeaderboardItem(
                        rank = index + 4,
                        item = leaderboardData[index + 3],
                        filter = selectedFilter,
                        rankingGlow = rankingGlow
                    )
                }
            }
        }
    }
}

enum class LeaderboardFilter {
    TEAMS,
    RUNS,
    WICKETS,
    POINTS,
    MVP
}

data class LeaderboardItem(
    val id: String,
    val name: String,
    val value: String,
    val subtitle: String,
    val avatar: String,
    val stats: Map<String, String>,
    val trend: Trend
)

enum class Trend {
    UP,
    DOWN,
    SAME
}

@Composable
fun LeaderboardBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle background effect
        val positions = listOf(
            Offset(canvasWidth * 0.1f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.1f, canvasHeight * 0.9f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.9f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.5f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center pattern
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        drawCircle(
            color = NeonOrange.copy(alpha = glowAlpha * 0.05f),
            radius = min(canvasWidth, canvasHeight) * 0.3f,
            center = Offset(centerX, centerY)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeaderboardHeader(
    onBack: () -> Unit,
    rankingGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val logoPulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "LEADERBOARD",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange,
                    letterSpacing = 2.sp
                )
            )
            
            Text(
                text = "Tournament Rankings",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White80
                )
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    color = NeonOrange.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(20.dp)
                )
                .scale(logoPulse),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Leaderboard,
                contentDescription = "Leaderboard",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun LeaderboardFilterTabs(
    selectedFilter: LeaderboardFilter,
    onFilterSelected: (LeaderboardFilter) -> Unit,
    rankingGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val tabGlow by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        LeaderboardFilter.values().forEach { filter ->
            FilterTab(
                text = when (filter) {
                    LeaderboardFilter.TEAMS -> "TEAMS"
                    LeaderboardFilter.RUNS -> "RUNS"
                    LeaderboardFilter.WICKETS -> "WICKETS"
                    LeaderboardFilter.POINTS -> "POINTS"
                    LeaderboardFilter.MVP -> "MVP"
                },
                isSelected = selectedFilter == filter,
                onClick = { onFilterSelected(filter) },
                tabGlow = if (selectedFilter == filter) tabGlow else 1f,
                rankingGlow = rankingGlow
            )
        }
    }
}

@Composable
fun FilterTab(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    tabGlow: Float,
    rankingGlow: Float
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .scale(tabGlow),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) NeonOrange else MatteBlackLight,
            contentColor = if (isSelected) White else White80
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = if (isSelected) 8.dp else 4.dp
        ),
        shape = RoundedCornerShape(20.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        )
    }
}

@Composable
fun TopThreePodium(
    data: List<LeaderboardItem>,
    filter: LeaderboardFilter,
    rankingGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val podiumPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .scale(podiumPulse),
        colors = CardDefaults.cardColors(
            containerColor = NeonOrange.copy(alpha = 0.05f)
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 12.dp
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 2.dp,
            brush = Brush.horizontalGradient(
                colors = listOf(
                    NeonOrange.copy(alpha = rankingGlow),
                    NeonGreen.copy(alpha = rankingGlow),
                    VolleyballBlue.copy(alpha = rankingGlow)
                )
            )
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Podium title
            Text(
                text = "TOP 3",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange,
                    textAlign = TextAlign.Center
                ),
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(20.dp))
            
            // Podium layout
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                // 2nd place
                if (data.size >= 2) {
                    PodiumPosition(
                        rank = 2,
                        item = data[1],
                        filter = filter,
                        height = 120.dp,
                        color = VolleyballBlue,
                        rankingGlow = rankingGlow
                    )
                }
                
                // 1st place
                if (data.isNotEmpty()) {
                    PodiumPosition(
                        rank = 1,
                        item = data[0],
                        filter = filter,
                        height = 160.dp,
                        color = NeonOrange,
                        rankingGlow = rankingGlow
                    )
                }
                
                // 3rd place
                if (data.size >= 3) {
                    PodiumPosition(
                        rank = 3,
                        item = data[2],
                        filter = filter,
                        height = 80.dp,
                        color = NeonGreen,
                        rankingGlow = rankingGlow
                    )
                }
            }
        }
    }
}

@Composable
fun PodiumPosition(
    rank: Int,
    item: LeaderboardItem,
    filter: LeaderboardFilter,
    height: Dp,
    color: Color,
    rankingGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val positionPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.scale(positionPulse)
    ) {
        // Rank badge
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    color = color.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(20.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = rank.toString(),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = color,
                    fontFamily = FontFamily.SansSerif
                )
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // Podium platform
        Card(
            modifier = Modifier
                .width(100.dp)
                .height(height),
            colors = CardDefaults.cardColors(
                containerColor = color.copy(alpha = 0.1f)
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 8.dp
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Avatar
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(
                            color = color.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(16.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = item.name.getInitials(),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Black,
                            color = color
                        )
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Name
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = color,
                        textAlign = TextAlign.Center
                    ),
                    maxLines = 2
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                // Value
                Text(
                    text = item.value,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Black,
                        color = color,
                        fontFamily = FontFamily.SansSerif
                    )
                )
            }
        }
    }
}

@Composable
fun LeaderboardItem(
    rank: Int,
    item: LeaderboardItem,
    filter: LeaderboardFilter,
    rankingGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val cardPulse by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(cardPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 6.dp
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Rank number
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        color = when (rank) {
                            1 -> NeonOrange.copy(alpha = 0.2f)
                            2 -> VolleyballBlue.copy(alpha = 0.2f)
                            3 -> NeonGreen.copy(alpha = 0.2f)
                            else -> White20
                        },
                        shape = RoundedCornerShape(20.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = rank.toString(),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = when (rank) {
                            1 -> NeonOrange
                            2 -> VolleyballBlue
                            3 -> NeonGreen
                            else -> White60
                        },
                        fontFamily = FontFamily.SansSerif
                    )
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Avatar
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        color = NeonOrange.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(24.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = item.name.getInitials(),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = NeonOrange
                    )
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Name and stats
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = White
                    )
                )
                
                Text(
                    text = item.subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = White60
                    )
                )
                
                // Additional stats
                if (item.stats.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        item.stats.entries.take(2).forEach { (key, value) ->
                            Text(
                                text = "$key: $value",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = White40,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                            
                            if (item.stats.entries.indexOfFirst { it.key == key } < 1) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "•",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = White20
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                        }
                    }
                }
            }
            
            // Value
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = item.value,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = NeonOrange,
                        fontFamily = FontFamily.SansSerif
                    )
                )
                
                // Trend indicator
                TrendIndicator(
                    trend = item.trend,
                    rankingGlow = rankingGlow
                )
            }
        }
    }
}

@Composable
fun TrendIndicator(
    trend: Trend,
    rankingGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val trendPulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        when (trend) {
            Trend.UP -> {
                Icon(
                    imageVector = Icons.Default.TrendingUp,
                    contentDescription = "Up",
                    tint = NeonGreen,
                    modifier = Modifier.size(20.dp).scale(trendPulse)
                )
            }
            Trend.DOWN -> {
                Icon(
                    imageVector = Icons.Default.TrendingDown,
                    contentDescription = "Down",
                    tint = NeonRed,
                    modifier = Modifier.size(20.dp).scale(trendPulse)
                )
            }
            Trend.SAME -> {
                Icon(
                    imageVector = Icons.Default.TrendingFlat,
                    contentDescription = "Same",
                    tint = White60,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

// Helper functions to generate leaderboard data
fun getTeamsLeaderboard(): List<LeaderboardItem> {
    return listOf(
        LeaderboardItem(
            id = "team_001",
            name = "Royal Warriors",
            value = "16",
            subtitle = "8 wins, 2 losses",
            avatar = "RW",
            stats = mapOf(
                "Points" to "16",
                "Won" to "8",
                "Lost" to "2"
            ),
            trend = Trend.UP
        ),
        LeaderboardItem(
            id = "team_002",
            name = "Thunder Strikers",
            value = "12",
            subtitle = "6 wins, 4 losses",
            avatar = "TS",
            stats = mapOf(
                "Points" to "12",
                "Won" to "6",
                "Lost" to "4"
            ),
            trend = Trend.DOWN
        ),
        LeaderboardItem(
            id = "team_003",
            name = "Lions Club",
            value = "10",
            subtitle = "5 wins, 1 loss",
            avatar = "LC",
            stats = mapOf(
                "Points" to "10",
                "Won" to "5",
                "Lost" to "1"
            ),
            trend = Trend.UP
        ),
        LeaderboardItem(
            id = "team_004",
            name = "Eagles Team",
            value = "6",
            subtitle = "3 wins, 3 losses",
            avatar = "ET",
            stats = mapOf(
                "Points" to "6",
                "Won" to "3",
                "Lost" to "3"
            ),
            trend = Trend.SAME
        ),
        LeaderboardItem(
            id = "team_005",
            name = "Sharks Volleyball",
            value = "14",
            subtitle = "7 wins, 3 losses",
            avatar = "SV",
            stats = mapOf(
                "Points" to "14",
                "Won" to "7",
                "Lost" to "3"
            ),
            trend = Trend.UP
        )
    )
}

fun getRunsLeaderboard(): List<LeaderboardItem> {
    return listOf(
        LeaderboardItem(
            id = "player_001",
            name = "Rahul Sharma",
            value = "1250",
            subtitle = "25 matches",
            avatar = "RS",
            stats = mapOf(
                "Avg" to "52.5",
                "SR" to "145.8",
                "HS" to "98"
            ),
            trend = Trend.UP
        ),
        LeaderboardItem(
            id = "player_002",
            name = "Vikram Singh",
            value = "980",
            subtitle = "22 matches",
            avatar = "VS",
            stats = mapOf(
                "Avg" to "44.5",
                "SR" to "132.1",
                "HS" to "87"
            ),
            trend = Trend.DOWN
        ),
        LeaderboardItem(
            id = "player_003",
            name = "Amit Kumar",
            value = "856",
            subtitle = "20 matches",
            avatar = "AK",
            stats = mapOf(
                "Avg" to "42.8",
                "SR" to "138.9",
                "HS" to "76"
            ),
            trend = Trend.UP
        )
    )
}

fun getWicketsLeaderboard(): List<LeaderboardItem> {
    return listOf(
        LeaderboardItem(
            id = "player_004",
            name = "Sanjay Patel",
            value = "28",
            subtitle = "18 matches",
            avatar = "SP",
            stats = mapOf(
                "Avg" to "22.5",
                "Eco" to "6.2",
                "BB" to "4/18"
            ),
            trend = Trend.UP
        ),
        LeaderboardItem(
            id = "player_005",
            name = "Rohit Verma",
            value = "24",
            subtitle = "16 matches",
            avatar = "RV",
            stats = mapOf(
                "Avg" to "25.8",
                "Eco" to "6.8",
                "BB" to "3/24"
            ),
            trend = Trend.SAME
        )
    )
}

fun getPointsLeaderboard(): List<LeaderboardItem> {
    return listOf(
        LeaderboardItem(
            id = "player_006",
            name = "Arjun Reddy",
            value = "156",
            subtitle = "12 matches",
            avatar = "AR",
            stats = mapOf(
                "Raid" to "89",
                "Tackle" to "67",
                "Success" to "78%"
            ),
            trend = Trend.UP
        ),
        LeaderboardItem(
            id = "player_007",
            name = "Karan Malhotra",
            value = "142",
            subtitle = "11 matches",
            avatar = "KM",
            stats = mapOf(
                "Raid" to "78",
                "Tackle" to "64",
                "Success" to "75%"
            ),
            trend = Trend.DOWN
        )
    )
}

fun getMVPLeaderboard(): List<LeaderboardItem> {
    return listOf(
        LeaderboardItem(
            id = "player_001",
            name = "Rahul Sharma",
            value = "5",
            subtitle = "MOTM Awards",
            avatar = "RS",
            stats = mapOf(
                "Runs" to "1250",
                "Wickets" to "12",
                "Matches" to "25"
            ),
            trend = Trend.UP
        ),
        LeaderboardItem(
            id = "player_006",
            name = "Arjun Reddy",
            value = "4",
            subtitle = "MOTM Awards",
            avatar = "AR",
            stats = mapOf(
                "Points" to "156",
                "Raid" to "89",
                "Matches" to "12"
            ),
            trend = Trend.UP
        )
    )
}

// Extension function for getting initials
fun String.getInitials(): String {
    return this.split(" ").take(2).joinToString("") { 
        it.firstOrNull()?.uppercase() ?: "" 
    }
}
