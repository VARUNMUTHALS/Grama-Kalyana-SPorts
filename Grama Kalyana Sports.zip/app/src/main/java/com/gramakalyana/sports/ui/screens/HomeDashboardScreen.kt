package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.R
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeDashboardScreen(
    onNavigateToTournaments: () -> Unit,
    onNavigateToLiveScores: () -> Unit,
    onNavigateToStatistics: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToMatch: (String) -> Unit,
    onNavigateToTournament: (String) -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(120000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val liveGlow by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val cardPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Sample data
    val liveMatches = remember {
        listOf(
            Match(
                id = "match_001",
                teamAName = "Royal Warriors",
                teamBName = "Thunder Strikers",
                sportType = SportType.CRICKET,
                status = MatchStatus.LIVE,
                cricketScore = CricketScore(
                    teamARuns = 156,
                    teamAWickets = 4,
                    teamAOvers = 18.5,
                    teamBRuns = 89,
                    teamBWickets = 2,
                    teamBOvers = 12.3
                )
            ),
            Match(
                id = "match_002",
                teamAName = "Lions Club",
                teamBName = "Eagles Team",
                sportType = SportType.KABADDI,
                status = MatchStatus.LIVE,
                kabaddiScore = KabaddiScore(
                    teamAPoints = 28,
                    teamBPoints = 22
                )
            )
        )
    }
    
    val upcomingTournaments = remember {
        listOf(
            Tournament(
                id = "tournament_001",
                name = "Grama Kalyana Premier League",
                sportType = SportType.CRICKET,
                status = TournamentStatus.LIVE,
                totalTeams = 8,
                totalMatches = 28,
                completedMatches = 12
            ),
            Tournament(
                id = "tournament_002",
                name = "Summer Kabaddi Championship",
                sportType = SportType.KABADDI,
                status = TournamentStatus.UPCOMING,
                totalTeams = 6,
                totalMatches = 15,
                completedMatches = 0
            )
        )
    }
    
    val scrollState = rememberScrollState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Dashboard background
        DashboardBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = liveGlow
        )
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Header with app branding
            DashboardHeader(
                onNavigateToSettings = onNavigateToSettings,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Quick actions
            QuickActionsSection(
                onNavigateToTournaments = onNavigateToTournaments,
                onNavigateToLiveScores = onNavigateToLiveScores,
                onNavigateToStatistics = onNavigateToStatistics,
                cardPulse = cardPulse
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Live matches carousel
            LiveMatchesSection(
                liveMatches = liveMatches,
                onNavigateToMatch = onNavigateToMatch,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Featured tournaments
            FeaturedTournamentsSection(
                tournaments = upcomingTournaments,
                onNavigateToTournament = onNavigateToTournament,
                cardPulse = cardPulse
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Sports showcase
            SportsShowcaseSection()
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Recent activity
            RecentActivitySection()
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun DashboardBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        // Stadium floodlight effect
        val floodlightPositions = listOf(
            Offset(0f, 0f),
            Offset(canvasWidth, 0f),
            Offset(0f, canvasHeight),
            Offset(canvasWidth, canvasHeight),
            Offset(centerX, 0f),
            Offset(centerX, canvasHeight)
        )
        
        floodlightPositions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.7f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.2f),
                    NeonGreen.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 0.5f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center dashboard spotlight
        val centerGradient = androidx.compose.ui.graphics.RadialGradientShader(
            center = Offset(centerX, centerY),
            radius = min(canvasWidth, canvasHeight) * 0.4f,
            colors = listOf(
                NeonOrange.copy(alpha = glowAlpha * 0.1f),
                Color.Transparent
            ),
            colorStops = listOf(0f, 1f)
        )
        
        drawRect(
            brush = ShaderBrush(centerGradient),
            size = size
        )
        
        // Dashboard grid pattern
        drawDashboardGrid(centerX, centerY, min(canvasWidth, canvasHeight), glowAlpha)
    }
}

private fun DrawScope.drawDashboardGrid(
    centerX: Float,
    centerY: Float,
    canvasSize: Float,
    glowAlpha: Float
) {
    val numLines = 6
    for (i in 0 until numLines) {
        val angle = (i * 360f / numLines) * (PI / 180f)
        val startX = centerX + cos(angle).toFloat() * 40f
        val startY = centerY + sin(angle).toFloat() * 40f
        val endX = centerX + cos(angle).toFloat() * canvasSize * 0.35f
        val endY = centerY + sin(angle).toFloat() * canvasSize * 0.35f
        
        drawLine(
            color = NeonOrange.copy(alpha = glowAlpha * 0.08f),
            start = Offset(startX, startY),
            end = Offset(endX, endY),
            strokeWidth = 2f
        )
    }
    
    // Center circle
    drawCircle(
        color = NeonOrange.copy(alpha = glowAlpha * 0.05f),
        radius = canvasSize * 0.25f,
        center = Offset(centerX, centerY)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardHeader(
    onNavigateToSettings: () -> Unit,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val logoPulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_premium_sports),
                    contentDescription = "App Logo",
                    modifier = Modifier
                        .size(40.dp)
                        .scale(logoPulse)
                )
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Column {
                    Text(
                        text = "GRAMA KALYANA",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Black,
                            color = NeonOrange,
                            letterSpacing = 1.sp
                        )
                    )
                    
                    Text(
                        text = "SPORTS",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Light,
                            color = White
                        )
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "PREMIER LEAGUE EDITION",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange.copy(alpha = 0.8f),
                    letterSpacing = 2.sp
                )
            )
        }
        
        IconButton(
            onClick = onNavigateToSettings,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Settings",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun QuickActionsSection(
    onNavigateToTournaments: () -> Unit,
    onNavigateToLiveScores: () -> Unit,
    onNavigateToStatistics: () -> Unit,
    cardPulse: Float
) {
    Column {
        Text(
            text = "QUICK ACTIONS",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = NeonOrange
            )
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            QuickActionCard(
                icon = Icons.Default.EmojiEvents,
                title = "Tournaments",
                subtitle = "8 Active",
                color = NeonOrange,
                onClick = onNavigateToTournaments,
                modifier = Modifier
                    .weight(1f)
                    .height(100.dp)
                    .scale(cardPulse)
            )
            
            QuickActionCard(
                icon = Icons.Default.LiveTv,
                title = "Live Scores",
                subtitle = "2 Live",
                color = LiveRed,
                onClick = onNavigateToLiveScores,
                modifier = Modifier
                    .weight(1f)
                    .height(100.dp)
                    .scale(cardPulse)
            )
            
            QuickActionCard(
                icon = Icons.Default.BarChart,
                title = "Statistics",
                subtitle = "View All",
                color = NeonGreen,
                onClick = onNavigateToStatistics,
                modifier = Modifier
                    .weight(1f)
                    .height(100.dp)
                    .scale(cardPulse)
            )
        }
    }
}

@Composable
fun QuickActionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        color = color.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(24.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(24.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = White
                ),
                textAlign = TextAlign.Center
            )
            
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = White60
                ),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun LiveMatchesSection(
    liveMatches: List<Match>,
    onNavigateToMatch: (String) -> Unit,
    liveGlow: Float
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "LIVE MATCHES",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(LiveRed, RoundedCornerShape(4.dp))
                        .scale(1f + liveGlow * 0.3f)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = "${liveMatches.size} LIVE",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = LiveRed,
                        letterSpacing = 1.sp
                    )
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
            items(liveMatches) { match ->
                LiveMatchCard(
                    match = match,
                    onClick = { onNavigateToMatch(match.id) },
                    liveGlow = liveGlow
                )
            }
        }
    }
}

@Composable
fun LiveMatchCard(
    match: Match,
    onClick: () -> Unit,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val cardGlow by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        onClick = onClick,
        modifier = Modifier
            .width(200.dp)
            .height(140.dp)
            .scale(cardGlow),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 12.dp
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 2.dp,
            color = LiveRed.copy(alpha = liveGlow)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Sport type and live indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SportTypeBadge(
                    sportType = match.sportType,
                    isLive = true,
                    size = SportBadgeSize.SMALL
                )
                
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(LiveRed, RoundedCornerShape(3.dp))
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Team names
            Column {
                Text(
                    text = match.teamAName,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange
                    ),
                    maxLines = 1
                )
                
                Text(
                    text = "VS",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Black,
                        color = White60,
                        letterSpacing = 2.sp
                    )
                )
                
                Text(
                    text = match.teamBName,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = White
                    ),
                    maxLines = 1
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Score
            when (match.sportType) {
                SportType.CRICKET -> {
                    val score = match.cricketScore
                    if (score != null) {
                        Text(
                            text = "${score.teamARuns}/${score.teamAWickets} - ${score.teamBRuns}/${score.teamBWickets}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = NeonOrange,
                                fontFamily = FontFamily.SansSerif
                            )
                        )
                    }
                }
                SportType.KABADDI -> {
                    val score = match.kabaddiScore
                    if (score != null) {
                        Text(
                            text = "${score.teamAPoints} - ${score.teamBPoints}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = NeonOrange,
                                fontFamily = FontFamily.SansSerif
                            )
                        )
                    }
                }
                SportType.VOLLEYBALL -> {
                    val score = match.volleyballScore
                    if (score != null) {
                        Text(
                            text = "${score.teamASets} - ${score.teamBSets}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = NeonOrange,
                                fontFamily = FontFamily.SansSerif
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FeaturedTournamentsSection(
    tournaments: List<Tournament>,
    onNavigateToTournament: (String) -> Unit,
    cardPulse: Float
) {
    Column {
        Text(
            text = "FEATURED TOURNAMENTS",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = NeonOrange
            )
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
            items(tournaments) { tournament ->
                TournamentCard(
                    tournament = tournament,
                    onClick = { onNavigateToTournament(tournament.id) },
                    cardPulse = cardPulse
                )
            }
        }
    }
}

@Composable
fun TournamentCard(
    tournament: Tournament,
    onClick: () -> Unit,
    cardPulse: Float
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .width(200.dp)
            .height(140.dp)
            .scale(cardPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Tournament name and status
            Column {
                Text(
                    text = tournament.name,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = White
                    ),
                    maxLines = 2
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = tournament.status.getDisplayText(),
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = tournament.status.getDisplayColor()
                    )
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Tournament info
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                SportTypeBadge(
                    sportType = tournament.sportType,
                    isLive = tournament.status == TournamentStatus.LIVE,
                    size = SportBadgeSize.SMALL
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = "${tournament.totalTeams} Teams",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = White60
                    )
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Progress
            val progress = tournament.completedMatches.toFloat() / tournament.totalMatches.toFloat()
            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp),
                color = NeonOrange,
                trackColor = White20,
            )
        }
    }
}

@Composable
fun SportsShowcaseSection() {
    Column {
        Text(
            text = "SPORTS SHOWCASE",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = NeonOrange
            )
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SportShowcaseCard(
                sport = "CRICKET",
                icon = "🏏",
                color = CricketGreen,
                modifier = Modifier.weight(1f)
            )
            
            SportShowcaseCard(
                sport = "KABADDI",
                icon = "🤼",
                color = KabaddiRed,
                modifier = Modifier.weight(1f)
            )
            
            SportShowcaseCard(
                sport = "VOLLEYBALL",
                icon = "🏐",
                color = VolleyballBlue,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun SportShowcaseCard(
    sport: String,
    icon: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(100.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 6.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = icon,
                fontSize = 32.sp
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = sport,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = color
                ),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun RecentActivitySection() {
    Column {
        Text(
            text = "RECENT ACTIVITY",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = NeonOrange
            )
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MatteBlackLight
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 6.dp
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                RecentActivityItem(
                    icon = Icons.Default.EmojiEvents,
                    title = "Tournament Created",
                    subtitle = "Summer Cricket League",
                    time = "2 hours ago"
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                RecentActivityItem(
                    icon = Icons.Default.PersonAdd,
                    title = "Player Added",
                    subtitle = "Rahul Sharma to Royal Warriors",
                    time = "5 hours ago"
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                RecentActivityItem(
                    icon = Icons.Default.SportsCricket,
                    title = "Match Completed",
                    subtitle = "Lions vs Eagles - Lions Won",
                    time = "1 day ago"
                )
            }
        }
    }
}

@Composable
fun RecentActivityItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    time: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    color = NeonOrange.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(20.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = NeonOrange,
                modifier = Modifier.size(20.dp)
            )
        }
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = White
                )
            )
            
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = White60
                )
            )
        }
        
        Text(
            text = time,
            style = MaterialTheme.typography.labelSmall.copy(
                color = White40
            )
        )
    }
}

enum class SportBadgeSize {
    SMALL,
    MEDIUM
}

@Composable
fun SportTypeBadge(
    sportType: SportType,
    isLive: Boolean,
    size: SportBadgeSize = SportBadgeSize.MEDIUM
) {
    val sportInfo = when (sportType) {
        SportType.CRICKET -> Triple("🏏", "CRICKET", CricketGreen)
        SportType.KABADDI -> Triple("🤼", "KABADDI", KabaddiRed)
        SportType.VOLLEYBALL -> Triple("🏐", "VOLLEYBALL", VolleyballBlue)
    }
    
    val badgeSize = when (size) {
        SportBadgeSize.SMALL -> 8.dp
        SportBadgeSize.MEDIUM -> 12.dp
    }
    
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(
                color = sportInfo.third.copy(alpha = 0.2f),
                shape = RoundedCornerShape(12.dp)
            )
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = sportInfo.first,
            fontSize = when (size) {
                SportBadgeSize.SMALL -> 12.sp
                SportBadgeSize.MEDIUM -> 16.sp
            }
        )
        
        Spacer(modifier = Modifier.width(4.dp))
        
        Text(
            text = sportInfo.second,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = sportInfo.third
            )
        )
        
        if (isLive) {
            Spacer(modifier = Modifier.width(4.dp))
            
            Box(
                modifier = Modifier
                    .size(badgeSize)
                    .background(LiveRed, RoundedCornerShape(badgeSize / 2))
            )
        }
    }
}
