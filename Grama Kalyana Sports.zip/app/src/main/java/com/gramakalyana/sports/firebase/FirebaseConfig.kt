package com.gramakalyana.sports.firebase

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirebaseConfig @Inject constructor() {
    
    // Firebase Auth
    val auth: FirebaseAuth = FirebaseAuth.getInstance()
    
    // Firebase Database
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()
    
    // Database References
    val tournamentsRef: DatabaseReference = database.getReference("tournaments")
    val teamsRef: DatabaseReference = database.getReference("teams")
    val playersRef: DatabaseReference = database.getReference("players")
    val matchesRef: DatabaseReference = database.getReference("matches")
    val liveScoresRef: DatabaseReference = database.getReference("live_scores")
    val statisticsRef: DatabaseReference = database.getReference("statistics")
    
    // Firebase Storage
    private val storage: FirebaseStorage = FirebaseStorage.getInstance()
    
    // Storage References
    val storageRef: StorageReference = storage.reference
    val teamLogosRef: StorageReference = storageRef.child("team_logos")
    val playerPhotosRef: StorageReference = storageRef.child("player_photos")
    val tournamentImagesRef: StorageReference = storageRef.child("tournament_images")
    
    // Database paths
    companion object {
        const val TOURNAMENTS_PATH = "tournaments"
        const val TEAMS_PATH = "teams"
        const val PLAYERS_PATH = "players"
        const val MATCHES_PATH = "matches"
        const val LIVE_SCORES_PATH = "live_scores"
        const val STATISTICS_PATH = "statistics"
        const val USERS_PATH = "users"
        
        // Storage paths
        const val TEAM_LOGOS_PATH = "team_logos"
        const val PLAYER_PHOTOS_PATH = "player_photos"
        const val TOURNAMENT_IMAGES_PATH = "tournament_images"
    }
    
    // Helper methods for database references
    fun getTournamentReference(tournamentId: String): DatabaseReference {
        return tournamentsRef.child(tournamentId)
    }
    
    fun getTeamReference(teamId: String): DatabaseReference {
        return teamsRef.child(teamId)
    }
    
    fun getPlayerReference(playerId: String): DatabaseReference {
        return playersRef.child(playerId)
    }
    
    fun getMatchReference(matchId: String): DatabaseReference {
        return matchesRef.child(matchId)
    }
    
    fun getLiveScoreReference(matchId: String): DatabaseReference {
        return liveScoresRef.child(matchId)
    }
    
    fun getTournamentTeamsReference(tournamentId: String): DatabaseReference {
        return tournamentsRef.child(tournamentId).child("teams")
    }
    
    fun getTournamentMatchesReference(tournamentId: String): DatabaseReference {
        return tournamentsRef.child(tournamentId).child("matches")
    }
    
    fun getTeamPlayersReference(teamId: String): DatabaseReference {
        return teamsRef.child(teamId).child("players")
    }
    
    // Helper methods for storage references
    fun getTeamLogoReference(teamId: String): StorageReference {
        return teamLogosRef.child("$teamId.jpg")
    }
    
    fun getPlayerPhotoReference(playerId: String): StorageReference {
        return playerPhotosRef.child("$playerId.jpg")
    }
    
    fun getTournamentImageReference(tournamentId: String): StorageReference {
        return tournamentImagesRef.child("$tournamentId.jpg")
    }
}
