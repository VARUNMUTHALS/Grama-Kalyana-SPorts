package com.gramakalyana.sports.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.gramakalyana.sports.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatisticsScreen(
    onNavigateBack: () -> Unit,
    onNavigateToPlayerStats: (String) -> Unit,
    onNavigateToTeamStats: (String) -> Unit,
    onNavigateToTournamentStats: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .background(MatteBlackLight, RoundedCornerShape(12.dp))
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = NeonOrange
                )
            }
            
            Text(
                text = "Statistics",
                style = MaterialTheme.typography.headlineMedium,
                color = White,
                fontWeight = FontWeight.Bold
            )
            
            IconButton(
                onClick = { /* Filter */ },
                modifier = Modifier
                    .background(MatteBlackLight, RoundedCornerShape(12.dp))
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.FilterList,
                    contentDescription = "Filter",
                    tint = NeonOrange
                )
            }
        }
        
        // Statistics Overview
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "Overview",
                    style = MaterialTheme.typography.headlineSmall,
                    color = White,
                    fontWeight = FontWeight.Bold
                )
            }
            
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatsCard(
                        title = "Total Matches",
                        value = "156",
                        subtitle = "This Month",
                        icon = Icons.Default.SportsCricket,
                        color = NeonOrange,
                        modifier = Modifier.weight(1f)
                    )
                    
                    StatsCard(
                        title = "Active Players",
                        value = "89",
                        subtitle = "Registered",
                        icon = Icons.Default.Person,
                        color = NeonGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatsCard(
                        title = "Teams",
                        value = "24",
                        subtitle = "Participating",
                        icon = Icons.Default.Groups,
                        color = NeonBlue,
                        modifier = Modifier.weight(1f)
                    )
                    
                    StatsCard(
                        title = "Tournaments",
                        value = "8",
                        subtitle = "Active",
                        icon = Icons.Default.EmojiEvents,
                        color = NeonYellow,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Top Performers",
                    style = MaterialTheme.typography.headlineSmall,
                    color = White,
                    fontWeight = FontWeight.Bold
                )
            }
            
            item {
                TopPerformersSection(
                    onPlayerClick = onNavigateToPlayerStats
                )
            }
            
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Recent Achievements",
                    style = MaterialTheme.typography.headlineSmall,
                    color = White,
                    fontWeight = FontWeight.Bold
                )
            }
            
            item {
                RecentAchievementsSection()
            }
        }
    }
}

@Composable
fun StatsCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(100.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                color = color,
                fontWeight = FontWeight.Bold
            )
            
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = White60,
                textAlign = TextAlign.Center
            )
            
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = White40
            )
        }
    }
}

@Composable
fun TopPerformersSection(
    onPlayerClick: (String) -> Unit
) {
    val topPerformers = getSampleTopPerformers()
    
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        topPerformers.forEach { performer ->
            PerformerCard(
                performer = performer,
                onClick = { onPlayerClick(performer.id) }
            )
        }
    }
}

@Composable
fun PerformerCard(
    performer: TopPerformer,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(80.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Rank
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(performer.rankColor, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = performer.rank.toString(),
                    style = MaterialTheme.typography.titleMedium,
                    color = White,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Player Info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = performer.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = White,
                    fontWeight = FontWeight.Bold
                )
                
                Text(
                    text = "${performer.team} • ${performer.sport}",
                    style = MaterialTheme.typography.bodySmall,
                    color = White60
                )
                
                Text(
                    text = performer.stat,
                    style = MaterialTheme.typography.bodySmall,
                    color = NeonOrange,
                    fontWeight = FontWeight.Medium
                )
            }
            
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = "View Details",
                tint = White40,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun RecentAchievementsSection() {
    val achievements = getSampleAchievements()
    
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        achievements.forEach { achievement ->
            AchievementCard(achievement = achievement)
        }
    }
}

@Composable
fun AchievementCard(
    achievement: Achievement
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = achievement.icon,
                contentDescription = null,
                tint = achievement.color,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = achievement.title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = White,
                    fontWeight = FontWeight.Medium
                )
                
                Text(
                    text = achievement.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = White60
                )
            }
            
            Text(
                text = achievement.time,
                style = MaterialTheme.typography.labelSmall,
                color = White40
            )
        }
    }
}

// Data classes for statistics
data class TopPerformer(
    val id: String,
    val name: String,
    val team: String,
    val sport: String,
    val stat: String,
    val rank: Int,
    val rankColor: Color
)

data class Achievement(
    val title: String,
    val description: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color,
    val time: String
)

// Sample data functions
private fun getSampleTopPerformers(): List<TopPerformer> {
    return listOf(
        TopPerformer(
            id = "1",
            name = "Rahul Kumar",
            team = "Royal Warriors",
            sport = "Cricket",
            stat = "485 runs • 3 centuries",
            rank = 1,
            rankColor = NeonOrange
        ),
        TopPerformer(
            id = "2",
            name = "Amit Singh",
            team = "Thunder Strikers",
            sport = "Kabaddi",
            stat = "78 raid points",
            rank = 2,
            rankColor = White80
        ),
        TopPerformer(
            id = "3",
            name = "Vikram Sharma",
            team = "Red Raiders",
            sport = "Volleyball",
            stat = "42 spikes • 15 blocks",
            rank = 3,
            rankColor = White60
        )
    )
}

private fun getSampleAchievements(): List<Achievement> {
    return listOf(
        Achievement(
            title = "Century of the Week",
            description = "Rahul Kumar scored 125* vs Thunder Strikers",
            icon = Icons.Default.EmojiEvents,
            color = NeonOrange,
            time = "2h ago"
        ),
        Achievement(
            title = "Super 10",
            description = "Amit Singh achieved Super 10 in Kabaddi",
            icon = Icons.Default.Star,
            color = NeonGreen,
            time = "5h ago"
        ),
        Achievement(
            title = "Perfect Set",
            description = "Vikram Sharma served 10 consecutive points",
            icon = Icons.Default.SportsVolleyball,
            color = NeonBlue,
            time = "1d ago"
        )
    )
}
