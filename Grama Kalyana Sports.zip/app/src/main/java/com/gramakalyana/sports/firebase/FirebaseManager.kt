package com.gramakalyana.sports.firebase

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.ktx.storage
import kotlinx.coroutines.tasks.await

/**
 * Firebase Manager - Centralized Firebase initialization and configuration
 * Handles all Firebase services initialization and provides access to Firebase instances
 */
object FirebaseManager {
    
    // Firebase Authentication
    private lateinit var auth: FirebaseAuth
    
    // Firebase Realtime Database
    private lateinit var database: FirebaseDatabase
    
    // Firebase Storage
    private lateinit var storage: FirebaseStorage
    
    // Database references
    val usersRef: DatabaseReference get() = database.reference.child("users")
    val tournamentsRef: DatabaseReference get() = database.reference.child("tournaments")
    val teamsRef: DatabaseReference get() = database.reference.child("teams")
    val playersRef: DatabaseReference get() = database.reference.child("players")
    val matchesRef: DatabaseReference get() = database.reference.child("matches")
    val liveScoresRef: DatabaseReference get() = database.reference.child("live_scores")
    val commentaryRef: DatabaseReference get() = database.reference.child("commentary")
    val leaderboardsRef: DatabaseReference get() = database.reference.child("leaderboards")
    val notificationsRef: DatabaseReference get() = database.reference.child("notifications")
    val matchHistoryRef: DatabaseReference get() = database.reference.child("match_history")
    val statisticsRef: DatabaseReference get() = database.reference.child("statistics")
    
    /**
     * Initialize Firebase services
     * Must be called before using any Firebase features
     */
    fun initialize() {
        try {
            // Initialize Firebase Authentication
            auth = Firebase.auth
            
            // Initialize Firebase Realtime Database with offline persistence
            database = Firebase.database.apply {
                setPersistenceEnabled(true)
                // Enable offline cache size
                setPersistenceCacheSizeBytes(10 * 1024 * 1024) // 10MB
            }
            
            // Initialize Firebase Storage
            storage = Firebase.storage
            
            // Configure database to stay synced
            database.reference.keepSynced(true)
            
        } catch (e: Exception) {
            throw FirebaseInitializationException("Failed to initialize Firebase: ${e.message}", e)
        }
    }
    
    /**
     * Get Firebase Authentication instance
     */
    fun getAuth(): FirebaseAuth {
        if (!::auth.isInitialized) {
            throw FirebaseNotInitializedException("Firebase Auth not initialized. Call initialize() first.")
        }
        return auth
    }
    
    /**
     * Get Firebase Database instance
     */
    fun getDatabase(): FirebaseDatabase {
        if (!::database.isInitialized) {
            throw FirebaseNotInitializedException("Firebase Database not initialized. Call initialize() first.")
        }
        return database
    }
    
    /**
     * Get Firebase Storage instance
     */
    fun getStorage(): FirebaseStorage {
        if (!::storage.isInitialized) {
            throw FirebaseNotInitializedException("Firebase Storage not initialized. Call initialize() first.")
        }
        return storage
    }
    
    /**
     * Get current authenticated user
     */
    fun getCurrentUser() = auth.currentUser
    
    /**
     * Check if user is authenticated
     */
    fun isUserAuthenticated(): Boolean = getCurrentUser() != null
    
    /**
     * Get current user ID
     */
    fun getCurrentUserId(): String? = getCurrentUser()?.uid
    
    /**
     * Get database reference for a specific match
     */
    fun getMatchReference(matchId: String): DatabaseReference {
        return matchesRef.child(matchId)
    }
    
    /**
     * Get live score reference for a specific match
     */
    fun getLiveScoreReference(matchId: String): DatabaseReference {
        return liveScoresRef.child(matchId)
    }
    
    /**
     * Get commentary reference for a specific match
     */
    fun getCommentaryReference(matchId: String): DatabaseReference {
        return commentaryRef.child(matchId)
    }
    
    /**
     * Get user reference for current user
     */
    fun getCurrentUserReference(): DatabaseReference? {
        return getCurrentUserId()?.let { usersRef.child(it) }
    }
    
    /**
     * Get tournament reference
     */
    fun getTournamentReference(tournamentId: String): DatabaseReference {
        return tournamentsRef.child(tournamentId)
    }
    
    /**
     * Get team reference
     */
    fun getTeamReference(teamId: String): DatabaseReference {
        return teamsRef.child(teamId)
    }
    
    /**
     * Get player reference
     */
    fun getPlayerReference(playerId: String): DatabaseReference {
        return playersRef.child(playerId)
    }
    
    /**
     * Get leaderboard reference for specific type
     */
    fun getLeaderboardReference(type: String): DatabaseReference {
        return leaderboardsRef.child(type)
    }
    
    /**
     * Get notifications reference for current user
     */
    fun getCurrentUserNotificationsReference(): DatabaseReference? {
        return getCurrentUserId()?.let { notificationsRef.child(it) }
    }
    
    /**
     * Get statistics reference for specific entity
     */
    fun getStatisticsReference(entityType: String, entityId: String): DatabaseReference {
        return statisticsRef.child(entityType).child(entityId)
    }
    
    /**
     * Enable/disable offline persistence for specific reference
     */
    fun setOfflinePersistence(reference: DatabaseReference, enabled: Boolean) {
        reference.keepSynced(enabled)
    }
    
    /**
     * Clear Firebase cache (useful for logout)
     */
    suspend fun clearCache() {
        try {
            // Clear authentication state
            auth.signOut()
            
            // Clear database cache
            database.goOffline()
            database.goOnline()
            
        } catch (e: Exception) {
            throw FirebaseOperationException("Failed to clear Firebase cache: ${e.message}", e)
        }
    }
    
    /**
     * Check network connectivity and sync status
     */
    suspend fun checkConnectivity(): Boolean {
        return try {
            // Try to read a small piece of data to check connectivity
            database.reference.child(".info/connected").get().await().value as? Boolean ?: false
        } catch (e: Exception) {
            false
        }
    }
}

// Custom exceptions for Firebase operations
class FirebaseInitializationException(message: String, cause: Throwable? = null) : Exception(message, cause)
class FirebaseNotInitializedException(message: String) : Exception(message)
class FirebaseOperationException(message: String, cause: Throwable? = null) : Exception(message, cause)
