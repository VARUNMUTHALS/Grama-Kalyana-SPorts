package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchHistoryScreen(
    tournamentId: String,
    onBack: () -> Unit,
    onMatchClick: (String) -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(180000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val archiveGlow by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Match history data
    var selectedFilter by remember { mutableStateOf(MatchHistoryFilter.ALL) }
    val matchHistory = remember {
        listOf(
            MatchHistoryItem(
                matchId = "match_001",
                teamAName = "Royal Warriors",
                teamBName = "Thunder Strikers",
                teamAScore = "178/6",
                teamBScore = "145/8",
                winnerId = "team_001",
                winnerName = "Royal Warriors",
                margin = "33 runs",
                date = System.currentTimeMillis() - 86400000 * 1, // 1 day ago
                sportType = SportType.CRICKET,
                venue = "Grama Kalyana Stadium",
                duration = "3h 25m",
                highlights = "Excellent batting performance"
            ),
            MatchHistoryItem(
                matchId = "match_002",
                teamAName = "Lions Club",
                teamBName = "Eagles Team",
                teamAScore = "32 points",
                teamBScore = "28 points",
                winnerId = "team_003",
                winnerName = "Lions Club",
                margin = "4 points",
                date = System.currentTimeMillis() - 86400000 * 2, // 2 days ago
                sportType = SportType.KABADDI,
                venue = "Community Sports Ground",
                duration = "40m",
                highlights = "Tense final raid"
            ),
            MatchHistoryItem(
                matchId = "match_003",
                teamAName = "Thunder Strikers",
                teamBName = "Royal Warriors",
                teamAScore = "142/8",
                teamBScore = "156/5",
                winnerId = "team_001",
                winnerName = "Royal Warriors",
                margin = "14 runs",
                date = System.currentTimeMillis() - 86400000 * 3, // 3 days ago
                sportType = SportType.CRICKET,
                venue = "Youth Sports Complex",
                duration = "3h 15m",
                highlights = "Chase completed successfully"
            ),
            MatchHistoryItem(
                matchId = "match_004",
                teamAName = "Sharks Volleyball",
                teamBName = "Eagles Team",
                teamAScore = "3 sets",
                teamBScore = "2 sets",
                winnerId = "team_005",
                winnerName = "Sharks Volleyball",
                margin = "1 set",
                date = System.currentTimeMillis() - 86400000 * 4, // 4 days ago
                sportType = SportType.VOLLEYBALL,
                venue = "Indoor Sports Complex",
                duration = "1h 45m",
                highlights = "Close final set"
            ),
            MatchHistoryItem(
                matchId = "match_005",
                teamAName = "Eagles Team",
                teamBName = "Thunder Strikers",
                teamAScore = "118/10",
                teamBScore = "122/8",
                winnerId = "team_002",
                winnerName = "Thunder Strikers",
                margin = "2 wickets",
                date = System.currentTimeMillis() - 86400000 * 5, // 5 days ago
                sportType = SportType.CRICKET,
                venue = "Beach Sports Arena",
                duration = "3h 30m",
                highlights = "Last over thriller"
            ),
            MatchHistoryItem(
                matchId = "match_006",
                teamAName = "Royal Warriors",
                teamBName = "Lions Club",
                teamAScore = "45 points",
                teamBScore = "38 points",
                winnerId = "team_001",
                winnerName = "Royal Warriors",
                margin = "7 points",
                date = System.currentTimeMillis() - 86400000 * 7, // 7 days ago
                sportType = SportType.KABADDI,
                venue = "Grama Kalyana Stadium",
                duration = "38m",
                highlights = "Dominant raiding display"
            ),
            MatchHistoryItem(
                matchId = "match_007",
                teamAName = "Sharks Volleyball",
                teamBName = "Lions Club",
                teamAScore = "2 sets",
                teamBScore = "3 sets",
                winnerId = "team_003",
                winnerName = "Lions Club",
                margin = "1 set",
                date = System.currentTimeMillis() - 86400000 * 10, // 10 days ago
                sportType = SportType.VOLLEYBALL,
                venue = "Beach Sports Arena",
                duration = "1h 50m",
                highlights = "Comeback victory"
            ),
            MatchHistoryItem(
                matchId = "match_008",
                teamAName = "Thunder Strikers",
                teamBName = "Eagles Team",
                teamAScore = "28 points",
                teamBScore = "30 points",
                winnerId = "team_004",
                winnerName = "Eagles Team",
                margin = "2 points",
                date = System.currentTimeMillis() - 86400000 * 14, // 14 days ago
                sportType = SportType.KABADDI,
                venue = "Community Sports Ground",
                duration = "42m",
                highlights = "Defensive masterclass"
            )
        )
    }
    
    val filteredHistory = remember(selectedFilter, matchHistory) {
        when (selectedFilter) {
            MatchHistoryFilter.ALL -> matchHistory
            MatchHistoryFilter.CRICKET -> matchHistory.filter { it.sportType == SportType.CRICKET }
            MatchHistoryFilter.KABADDI -> matchHistory.filter { it.sportType == SportType.KABADDI }
            MatchHistoryFilter.VOLLEYBALL -> matchHistory.filter { it.sportType == SportType.VOLLEYBALL }
        }
    }
    
    val listState = rememberLazyListState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Match history background
        MatchHistoryBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = archiveGlow
        )
        
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            MatchHistoryHeader(
                onBack = onBack,
                archiveGlow = archiveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Filter tabs
            MatchHistoryFilterTabs(
                selectedFilter = selectedFilter,
                onFilterSelected = { selectedFilter = it },
                archiveGlow = archiveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Archive statistics
            ArchiveStatisticsSection(
                matchHistory = matchHistory,
                archiveGlow = archiveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Match history list
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                state = listState,
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredHistory) { match ->
                    MatchHistoryCard(
                        match = match,
                        onClick = { onMatchClick(match.matchId) },
                        archiveGlow = archiveGlow
                    )
                }
            }
        }
    }
}

data class MatchHistoryItem(
    val matchId: String,
    val teamAName: String,
    val teamBName: String,
    val teamAScore: String,
    val teamBScore: String,
    val winnerId: String,
    val winnerName: String,
    val margin: String,
    val date: Long,
    val sportType: SportType,
    val venue: String,
    val duration: String,
    val highlights: String
)

enum class MatchHistoryFilter {
    ALL,
    CRICKET,
    KABADDI,
    VOLLEYBALL
}

@Composable
fun MatchHistoryBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle archive background effect
        val positions = listOf(
            Offset(canvasWidth * 0.1f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.1f, canvasHeight * 0.9f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.9f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.5f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.08f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center pattern
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        drawCircle(
            color = NeonOrange.copy(alpha = glowAlpha * 0.04f),
            radius = min(canvasWidth, canvasHeight) * 0.3f,
            center = Offset(centerX, centerY)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchHistoryHeader(
    onBack: () -> Unit,
    archiveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val logoPulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "MATCH ARCHIVE",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange,
                    letterSpacing = 2.sp
                )
            )
            
            Text(
                text = "Historical Records",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White80
                )
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    color = NeonOrange.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(20.dp)
                )
                .scale(logoPulse),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.History,
                contentDescription = "Archive",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun MatchHistoryFilterTabs(
    selectedFilter: MatchHistoryFilter,
    onFilterSelected: (MatchHistoryFilter) -> Unit,
    archiveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val tabGlow by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        MatchHistoryFilter.values().forEach { filter ->
            HistoryFilterTab(
                text = when (filter) {
                    MatchHistoryFilter.ALL -> "ALL"
                    MatchHistoryFilter.CRICKET -> "CRICKET"
                    MatchHistoryFilter.KABADDI -> "KABADDI"
                    MatchHistoryFilter.VOLLEYBALL -> "VOLLEYBALL"
                },
                isSelected = selectedFilter == filter,
                onClick = { onFilterSelected(filter) },
                tabGlow = if (selectedFilter == filter) tabGlow else 1f,
                archiveGlow = archiveGlow
            )
        }
    }
}

@Composable
fun HistoryFilterTab(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    tabGlow: Float,
    archiveGlow: Float
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .scale(tabGlow),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) NeonOrange else MatteBlackLight,
            contentColor = if (isSelected) White else White80
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = if (isSelected) 8.dp else 4.dp
        ),
        shape = RoundedCornerShape(20.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )
    }
}

@Composable
fun ArchiveStatisticsSection(
    matchHistory: List<MatchHistoryItem>,
    archiveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val statsPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .scale(statsPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ArchiveStatItem(
                label = "TOTAL MATCHES",
                value = matchHistory.size.toString(),
                color = NeonOrange
            )
            
            VerticalDivider(
                modifier = Modifier.height(40.dp),
                color = White20
            )
            
            ArchiveStatItem(
                label = "CRICKET",
                value = matchHistory.count { it.sportType == SportType.CRICKET }.toString(),
                color = CricketGreen
            )
            
            VerticalDivider(
                modifier = Modifier.height(40.dp),
                color = White20
            )
            
            ArchiveStatItem(
                label = "KABADDI",
                value = matchHistory.count { it.sportType == SportType.KABADDI }.toString(),
                color = KabaddiRed
            )
            
            VerticalDivider(
                modifier = Modifier.height(40.dp),
                color = White20
            )
            
            ArchiveStatItem(
                label = "VOLLEYBALL",
                value = matchHistory.count { it.sportType == SportType.VOLLEYBALL }.toString(),
                color = VolleyballBlue
            )
        }
    }
}

@Composable
fun ArchiveStatItem(
    label: String,
    value: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Black,
                color = color,
                fontFamily = FontFamily.SansSerif
            )
        )
        
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = White60,
                letterSpacing = 1.sp
            )
        )
    }
}

@Composable
fun MatchHistoryCard(
    match: MatchHistoryItem,
    onClick: () -> Unit,
    archiveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val cardPulse by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .scale(cardPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 6.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header with date and sport type
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = getFormattedDate(match.date),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = White80,
                            fontWeight = FontWeight.Medium
                        )
                    )
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    SportTypeBadge(
                        sportType = match.sportType,
                        isLive = false,
                        size = SportBadgeSize.SMALL
                    )
                }
                
                Text(
                    text = match.duration,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = White60
                    )
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Match result
            MatchResultSection(match)
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Winner announcement
            WinnerSection(match)
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Footer with venue and highlights
            MatchFooter(match)
        }
    }
}

@Composable
fun MatchResultSection(
    match: MatchHistoryItem
) {
    val isTeamAWinner = match.winnerId.contains("team_a") || match.winnerName == match.teamAName
    
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                horizontalAlignment = Alignment.Start,
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = match.teamAName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isTeamAWinner) NeonGreen else White60
                    ),
                    maxLines = 1
                )
                
                Text(
                    text = match.teamAScore,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isTeamAWinner) NeonGreen else White60,
                        fontFamily = FontFamily.SansSerif
                    )
                )
            }
            
            Text(
                text = "VS",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = White40,
                    letterSpacing = 4.sp
                )
            )
            
            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = match.teamBName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (!isTeamAWinner) NeonGreen else White60
                    ),
                    maxLines = 1
                )
                
                Text(
                    text = match.teamBScore,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (!isTeamAWinner) NeonGreen else White60,
                        fontFamily = FontFamily.SansSerif
                    )
                )
            }
        }
    }
}

@Composable
fun WinnerSection(
    match: MatchHistoryItem
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.EmojiEvents,
            contentDescription = "Winner",
            tint = NeonOrange,
            modifier = Modifier.size(20.dp)
        )
        
        Spacer(modifier = Modifier.width(8.dp))
        
        Text(
            text = "${match.winnerName} won by ${match.margin}",
            style = MaterialTheme.typography.bodyMedium.copy(
                color = NeonOrange,
                fontWeight = FontWeight.Bold
            )
        )
    }
}

@Composable
fun MatchFooter(
    match: MatchHistoryItem
) {
    Column {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = null,
                tint = White60,
                modifier = Modifier.size(16.dp)
            )
            
            Spacer(modifier = Modifier.width(6.dp))
            
            Text(
                text = match.venue,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = White80,
                    fontWeight = FontWeight.Medium
                ),
                maxLines = 1
            )
        }
        
        Spacer(modifier = Modifier.height(6.dp))
        
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Stars,
                contentDescription = null,
                tint = NeonYellow,
                modifier = Modifier.size(16.dp)
            )
            
            Spacer(modifier = Modifier.width(6.dp))
            
            Text(
                text = match.highlights,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NeonYellow,
                    fontWeight = FontWeight.Medium
                ),
                maxLines = 1
            )
        }
    }
}

// Helper function for formatting date
fun getFormattedDate(timestamp: Long): String {
    val date = java.util.Date(timestamp)
    val formatter = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault())
    return formatter.format(date)
}
