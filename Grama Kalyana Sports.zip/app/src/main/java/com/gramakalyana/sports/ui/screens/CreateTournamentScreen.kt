package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateTournamentScreen(
    onBack: () -> Unit,
    onCreateTournament: (Tournament) -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(120000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Form states
    var tournamentName by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedSportType by remember { mutableStateOf(SportType.CRICKET) }
    var venue by remember { mutableStateOf("") }
    var startDate by remember { mutableStateOf("") }
    var endDate by remember { mutableStateOf("") }
    var selectedFormat by remember { mutableStateOf(TournamentFormat.LEAGUE) }
    var prizePool by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Create tournament background
        CreateTournamentBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = glowPulse
        )
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Header
            CreateTournamentHeader(
                onBack = onBack,
                glowPulse = glowPulse
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Form content
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MatteBlackLight
                ),
                elevation = CardDefaults.cardElevation(
                    defaultElevation = 8.dp
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    // Tournament name
                    TournamentTextField(
                        value = tournamentName,
                        onValueChange = { 
                            tournamentName = it
                            errorMessage = null
                        },
                        label = "Tournament Name",
                        placeholder = "Enter tournament name",
                        icon = Icons.Default.EmojiEvents,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next,
                        onImeAction = {
                            focusManager.moveFocus(FocusDirection.Down)
                        },
                        errorMessage = if (tournamentName.isNotEmpty() && tournamentName.length < 3)
                            "Tournament name must be at least 3 characters" else null
                    )
                    
                    // Description
                    TournamentTextField(
                        value = description,
                        onValueChange = { 
                            description = it
                            errorMessage = null
                        },
                        label = "Description",
                        placeholder = "Enter tournament description",
                        icon = Icons.Default.Description,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next,
                        onImeAction = {
                            focusManager.moveFocus(FocusDirection.Down)
                        },
                        errorMessage = if (description.isNotEmpty() && description.length < 10)
                            "Description must be at least 10 characters" else null
                    )
                    
                    // Sport type selection
                    SportTypeSelector(
                        selectedSportType = selectedSportType,
                        onSportTypeSelected = { selectedSportType = it },
                        glowPulse = glowPulse
                    )
                    
                    // Venue
                    TournamentTextField(
                        value = venue,
                        onValueChange = { 
                            venue = it
                            errorMessage = null
                        },
                        label = "Venue",
                        placeholder = "Enter tournament venue",
                        icon = Icons.Default.LocationOn,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next,
                        onImeAction = {
                            focusManager.moveFocus(FocusDirection.Down)
                        },
                        errorMessage = if (venue.isNotEmpty() && venue.length < 5)
                            "Venue must be at least 5 characters" else null
                    )
                    
                    // Date selection
                    DateSelectionRow(
                        startDate = startDate,
                        endDate = endDate,
                        onStartDateChange = { 
                            startDate = it
                            errorMessage = null
                        },
                        onEndDateChange = { 
                            endDate = it
                            errorMessage = null
                        },
                        onImeAction = {
                            focusManager.moveFocus(FocusDirection.Down)
                        },
                        errorMessage = if (startDate.isNotEmpty() && endDate.isNotEmpty() && !isValidDateRange(startDate, endDate))
                            "End date must be after start date" else null
                    )
                    
                    // Tournament format
                    TournamentFormatSelector(
                        selectedFormat = selectedFormat,
                        onFormatSelected = { selectedFormat = it },
                        glowPulse = glowPulse
                    )
                    
                    // Prize pool
                    TournamentTextField(
                        value = prizePool,
                        onValueChange = { 
                            prizePool = it
                            errorMessage = null
                        },
                        label = "Prize Pool (Optional)",
                        placeholder = "Enter prize amount",
                        icon = Icons.Default.EmojiEvents,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done,
                        onImeAction = {
                            focusManager.clearFocus()
                        }
                    )
                    
                    Spacer(modifier = Modifier.height(20.dp))
                    
                    // Error message
                    errorMessage?.let {
                        Text(
                            text = it,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NeonRed
                            ),
                            modifier = Modifier.padding(bottom = 16.dp)
                        )
                    }
                    
                    // Create button
                    TournamentCreateButton(
                        onClick = {
                            if (validateForm(tournamentName, description, venue, startDate, endDate)) {
                                isLoading = true
                                val tournament = Tournament(
                                    id = "",
                                    name = tournamentName,
                                    description = description,
                                    sportType = selectedSportType,
                                    status = TournamentStatus.UPCOMING,
                                    totalTeams = 0,
                                    totalMatches = 0,
                                    completedMatches = 0,
                                    startDate = parseDate(startDate),
                                    endDate = parseDate(endDate),
                                    venue = venue,
                                    format = selectedFormat,
                                    prizePool = prizePool
                                )
                                onCreateTournament(tournament)
                            }
                        },
                        isLoading = isLoading,
                        glowPulse = glowPulse
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun CreateTournamentBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle background effect
        val positions = listOf(
            Offset(canvasWidth * 0.15f, canvasHeight * 0.15f),
            Offset(canvasWidth * 0.85f, canvasHeight * 0.15f),
            Offset(canvasWidth * 0.15f, canvasHeight * 0.85f),
            Offset(canvasWidth * 0.85f, canvasHeight * 0.85f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.4f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center pattern
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        drawCircle(
            color = NeonOrange.copy(alpha = glowAlpha * 0.05f),
            radius = min(canvasWidth, canvasHeight) * 0.2f,
            center = Offset(centerX, centerY)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateTournamentHeader(
    onBack: () -> Unit,
    glowPulse: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val logoPulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "CREATE TOURNAMENT",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange,
                    letterSpacing = 2.sp
                )
            )
            
            Text(
                text = "Set up your professional tournament",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White80
                )
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    color = NeonOrange.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(20.dp)
                )
                .scale(logoPulse),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.EmojiEvents,
                contentDescription = "Tournament",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TournamentTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    keyboardType: KeyboardType,
    imeAction: ImeAction,
    onImeAction: () -> Unit,
    errorMessage: String? = null
) {
    Column {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White80
                    )
                )
            },
            placeholder = {
                Text(
                    text = placeholder,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White40
                    )
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = NeonOrange,
                    modifier = Modifier.size(24.dp)
                )
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = keyboardType,
                imeAction = imeAction
            ),
            keyboardActions = KeyboardActions(
                onAny = { onImeAction() }
            ),
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonOrange,
                unfocusedBorderColor = White20,
                focusedTextColor = White,
                unfocusedTextColor = White,
                cursorColor = NeonOrange,
                errorBorderColor = NeonRed,
                errorTextColor = NeonRed
            ),
            shape = RoundedCornerShape(12.dp),
            isError = errorMessage != null
        )
        
        errorMessage?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NeonRed
                ),
                modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
        }
    }
}

@Composable
fun SportTypeSelector(
    selectedSportType: SportType,
    onSportTypeSelected: (SportType) -> Unit,
    glowPulse: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val selectorPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Column {
        Text(
            text = "Sport Type",
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = White80
            )
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .scale(selectorPulse),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SportType.values().forEach { sportType ->
                SportTypeChip(
                    sportType = sportType,
                    isSelected = selectedSportType == sportType,
                    onClick = { onSportTypeSelected(sportType) },
                    glowPulse = glowPulse
                )
            }
        }
    }
}

@Composable
fun SportTypeChip(
    sportType: SportType,
    isSelected: Boolean,
    onClick: () -> Unit,
    glowPulse: Float
) {
    val sportInfo = when (sportType) {
        SportType.CRICKET -> Triple("🏏", "CRICKET", CricketGreen)
        SportType.KABADDI -> Triple("🤼", "KABADDI", KabaddiRed)
        SportType.VOLLEYBALL -> Triple("🏐", "VOLLEYBALL", VolleyballBlue)
    }
    
    val infiniteTransition = rememberInfiniteTransition()
    val chipGlow by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Button(
        onClick = onClick,
        modifier = Modifier
            .scale(if (isSelected) chipGlow else 1f),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) sportInfo.third else MatteBlackLight,
            contentColor = if (isSelected) White else sportInfo.third
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = if (isSelected) 8.dp else 4.dp
        ),
        shape = RoundedCornerShape(20.dp),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = sportInfo.first,
                fontSize = 20.sp
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = sportInfo.second,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
        }
    }
}

@Composable
fun DateSelectionRow(
    startDate: String,
    endDate: String,
    onStartDateChange: (String) -> Unit,
    onEndDateChange: (String) -> Unit,
    onImeAction: () -> Unit,
    errorMessage: String? = null
) {
    Column {
        Text(
            text = "Tournament Dates",
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = White80
            )
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DateField(
                value = startDate,
                onValueChange = onStartDateChange,
                label = "Start Date",
                placeholder = "DD/MM/YYYY",
                icon = Icons.Default.CalendarToday,
                onImeAction = onImeAction
            )
            
            DateField(
                value = endDate,
                onValueChange = onEndDateChange,
                label = "End Date",
                placeholder = "DD/MM/YYYY",
                icon = Icons.Default.Event,
                onImeAction = onImeAction
            )
        }
        
        errorMessage?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NeonRed
                ),
                modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onImeAction: () -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White80
                )
            )
        },
        placeholder = {
            Text(
                text = placeholder,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White40
                )
            )
        },
        leadingIcon = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Number,
            imeAction = ImeAction.Next
        ),
        keyboardActions = KeyboardActions(
            onAny = { onImeAction() }
        ),
        modifier = Modifier.weight(1f),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonOrange,
            unfocusedBorderColor = White20,
            focusedTextColor = White,
            unfocusedTextColor = White,
            cursorColor = NeonOrange
        ),
        shape = RoundedCornerShape(12.dp)
    )
}

@Composable
fun TournamentFormatSelector(
    selectedFormat: TournamentFormat,
    onFormatSelected: (TournamentFormat) -> Unit,
    glowPulse: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val selectorPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Column {
        Text(
            text = "Tournament Format",
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = White80
            )
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .scale(selectorPulse),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TournamentFormat.values().forEach { format ->
                FormatChip(
                    format = format,
                    isSelected = selectedFormat == format,
                    onClick = { onFormatSelected(format) },
                    glowPulse = glowPulse
                )
            }
        }
    }
}

@Composable
fun FormatChip(
    format: TournamentFormat,
    isSelected: Boolean,
    onClick: () -> Unit,
    glowPulse: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val chipGlow by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Button(
        onClick = onClick,
        modifier = Modifier
            .scale(if (isSelected) chipGlow else 1f),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) NeonOrange else MatteBlackLight,
            contentColor = if (isSelected) White else NeonOrange
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = if (isSelected) 8.dp else 4.dp
        ),
        shape = RoundedCornerShape(20.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = format.getDisplayText(),
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )
    }
}

@Composable
fun TournamentCreateButton(
    onClick: () -> Unit,
    isLoading: Boolean,
    glowPulse: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val buttonPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .scale(buttonPulse),
        enabled = !isLoading,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent
        ),
        contentPadding = PaddingValues(0.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            NeonOrangeDark,
                            NeonOrange,
                            NeonOrangeLight
                        )
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
                .border(
                    width = 2.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            NeonOrange.copy(alpha = glowPulse),
                            NeonOrangeLight.copy(alpha = glowPulse)
                        )
                    ),
                    shape = RoundedCornerShape(16.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = White,
                    strokeWidth = 2.dp
                )
            } else {
                Text(
                    text = "CREATE TOURNAMENT",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = White,
                        letterSpacing = 2.sp
                    )
                )
            }
        }
    }
}

// Validation functions
fun validateForm(
    tournamentName: String,
    description: String,
    venue: String,
    startDate: String,
    endDate: String
): Boolean {
    return tournamentName.length >= 3 &&
           description.length >= 10 &&
           venue.length >= 5 &&
           startDate.isNotEmpty() &&
           endDate.isNotEmpty() &&
           isValidDateRange(startDate, endDate)
}

fun isValidDateRange(startDate: String, endDate: String): Boolean {
    // Simple date validation - in real app, use proper date parsing
    return startDate != endDate
}

fun parseDate(dateString: String): Long {
    // Simple date parsing - in real app, use proper date parsing
    return System.currentTimeMillis()
}
