package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.R
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveMatchScreen(
    matchId: String,
    onBack: () -> Unit,
    onScorerControl: () -> Unit,
    onCommentary: () -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val liveGlow by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(60000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val scorePulse by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Match data (sample)
    val match = remember {
        Match(
            id = "match_001",
            tournamentId = "tournament_001",
            teamAId = "team_a",
            teamBId = "team_b",
            teamAName = "Royal Warriors",
            teamBName = "Thunder Strikers",
            sportType = SportType.CRICKET,
            venue = "Grama Kalyana Stadium",
            scheduledDate = System.currentTimeMillis(),
            status = MatchStatus.LIVE,
            cricketScore = CricketScore(
                teamARuns = 156,
                teamAWickets = 4,
                teamAOvers = 18.5,
                teamBRuns = 89,
                teamBWickets = 2,
                teamBOvers = 12.3
            )
        )
    }
    
    val scrollState = rememberScrollState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Animated broadcast background
        LiveMatchBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = liveGlow
        )
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
        ) {
            // Header with back and actions
            LiveMatchHeader(
                onBack = onBack,
                onScorerControl = onScorerControl,
                onCommentary = onCommentary,
                isLive = match.status == MatchStatus.LIVE
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Main scoreboard
            LiveScoreboard(
                match = match,
                scorePulse = scorePulse,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Match timer and status
            MatchTimerSection(
                match = match,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Player highlights
            PlayerHighlightsSection(
                match = match
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Live commentary preview
            CommentaryPreviewSection(
                onCommentary = onCommentary
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Match statistics
            MatchStatisticsSection(
                match = match
            )
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun LiveMatchBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        // Stadium floodlight effect
        val floodlightPositions = listOf(
            Offset(0f, 0f),
            Offset(canvasWidth, 0f),
            Offset(0f, canvasHeight),
            Offset(canvasWidth, canvasHeight)
        )
        
        floodlightPositions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.8f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.3f),
                    LiveRed.copy(alpha = glowAlpha * 0.2f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 0.5f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center arena spotlight
        val centerGradient = androidx.compose.ui.graphics.RadialGradientShader(
            center = Offset(centerX, centerY),
            radius = min(canvasWidth, canvasHeight) * 0.4f,
            colors = listOf(
                LiveRed.copy(alpha = glowAlpha * 0.1f),
                NeonOrange.copy(alpha = glowAlpha * 0.05f),
                Color.Transparent
            ),
            colorStops = listOf(0f, 0.5f, 1f)
        )
        
        drawRect(
            brush = ShaderBrush(centerGradient),
            size = size
        )
        
        // Dynamic sports arena lines
        drawArenaLines(centerX, centerY, min(canvasWidth, canvasHeight), glowAlpha)
    }
}

private fun DrawScope.drawArenaLines(
    centerX: Float,
    centerY: Float,
    canvasSize: Float,
    glowAlpha: Float
) {
    val numLines = 8
    for (i in 0 until numLines) {
        val angle = (i * 360f / numLines) * (PI / 180f)
        val startX = centerX + cos(angle).toFloat() * 50f
        val startY = centerY + sin(angle).toFloat() * 50f
        val endX = centerX + cos(angle).toFloat() * canvasSize * 0.4f
        val endY = centerY + sin(angle).toFloat() * canvasSize * 0.4f
        
        drawLine(
            color = NeonOrange.copy(alpha = glowAlpha * 0.1f),
            start = Offset(startX, startY),
            end = Offset(endX, endY),
            strokeWidth = 2f
        )
    }
    
    // Center circle
    drawCircle(
        color = NeonOrange.copy(alpha = glowAlpha * 0.05f),
        radius = canvasSize * 0.3f,
        center = Offset(centerX, centerY)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveMatchHeader(
    onBack: () -> Unit,
    onScorerControl: () -> Unit,
    onCommentary: () -> Unit,
    isLive: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition()
    val livePulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        // Live indicator
        if (isLive) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .background(
                        color = LiveRed.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(LiveRed, RoundedCornerShape(4.dp))
                        .scale(livePulse)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = "LIVE",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = LiveRed,
                        letterSpacing = 2.sp
                    )
                )
            }
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        // Action buttons
        Row {
            IconButton(
                onClick = onScorerControl,
                modifier = Modifier
                    .background(MatteBlackLight, RoundedCornerShape(12.dp))
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Scorer Control",
                    tint = NeonOrange
                )
            }
            
            Spacer(modifier = Modifier.width(8.dp))
            
            IconButton(
                onClick = onCommentary,
                modifier = Modifier
                    .background(MatteBlackLight, RoundedCornerShape(12.dp))
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Comment,
                    contentDescription = "Commentary",
                    tint = NeonOrange
                )
            }
        }
    }
}

@Composable
fun LiveScoreboard(
    match: Match,
    scorePulse: Float,
    liveGlow: Float
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .border(
                width = 2.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        NeonOrange.copy(alpha = liveGlow),
                        LiveRed.copy(alpha = liveGlow)
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 12.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            // Sport type badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                SportTypeBadge(
                    sportType = match.sportType,
                    isLive = match.status == MatchStatus.LIVE
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Team scores
            when (match.sportType) {
                SportType.CRICKET -> CricketScoreboard(
                    match = match,
                    scorePulse = scorePulse
                )
                SportType.KABADDI -> KabaddiScoreboard(
                    match = match,
                    scorePulse = scorePulse
                )
                SportType.VOLLEYBALL -> VolleyballScoreboard(
                    match = match,
                    scorePulse = scorePulse
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Match venue
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = White60,
                    modifier = Modifier.size(16.dp)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = match.venue,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White80,
                        fontWeight = FontWeight.Medium
                    )
                )
            }
        }
    }
}

@Composable
fun CricketScoreboard(
    match: Match,
    scorePulse: Float
) {
    val cricketScore = match.cricketScore ?: return
    
    Column {
        // Team A
        TeamScoreRow(
            teamName = match.teamAName,
            score = "${cricketScore.teamARuns}/${cricketScore.teamAWickets}",
            overs = "(${cricketScore.teamAOvers} ov)",
            isBatting = true,
            scorePulse = scorePulse
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // VS indicator
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "VS",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = NeonOrange.copy(alpha = 0.6f),
                    letterSpacing = 4.sp
                )
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Team B
        TeamScoreRow(
            teamName = match.teamBName,
            score = "${cricketScore.teamBRuns}/${cricketScore.teamBWickets}",
            overs = "(${cricketScore.teamBOvers} ov)",
            isBatting = false,
            scorePulse = 1f
        )
    }
}

@Composable
fun TeamScoreRow(
    teamName: String,
    score: String,
    overs: String,
    isBatting: Boolean,
    scorePulse: Float
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = teamName,
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = if (isBatting) NeonOrange else White80
            ),
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Row(
            verticalAlignment = Alignment.Bottom
        ) {
            Text(
                text = score,
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Black,
                    color = if (isBatting) NeonOrange else White,
                    fontFamily = FontFamily.SansSerif
                ),
                modifier = Modifier.scale(if (isBatting) scorePulse else 1f)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = overs,
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = if (isBatting) NeonOrange.copy(alpha = 0.8f) else White60,
                    fontWeight = FontWeight.Medium
                )
            )
        }
        
        if (isBatting) {
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = "BATTING",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Black,
                    color = LiveRed,
                    letterSpacing = 2.sp
                )
            )
        }
    }
}

@Composable
fun KabaddiScoreboard(
    match: Match,
    scorePulse: Float
) {
    val kabaddiScore = match.kabaddiScore ?: return
    
    // Similar implementation for Kabaddi
    Column {
        TeamScoreRow(
            teamName = match.teamAName,
            score = kabaddiScore.teamAPoints.toString(),
            overs = "",
            isBatting = true,
            scorePulse = scorePulse
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "VS",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = NeonOrange.copy(alpha = 0.6f),
                    letterSpacing = 4.sp
                )
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        TeamScoreRow(
            teamName = match.teamBName,
            score = kabaddiScore.teamBPoints.toString(),
            overs = "",
            isBatting = false,
            scorePulse = 1f
        )
    }
}

@Composable
fun VolleyballScoreboard(
    match: Match,
    scorePulse: Float
) {
    val volleyballScore = match.volleyballScore ?: return
    
    Column {
        TeamScoreRow(
            teamName = match.teamAName,
            score = volleyballScore.teamASets.toString(),
            overs = "Sets: ${volleyballScore.teamAPoints}",
            isBatting = true,
            scorePulse = scorePulse
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "VS",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = NeonOrange.copy(alpha = 0.6f),
                    letterSpacing = 4.sp
                )
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        TeamScoreRow(
            teamName = match.teamBName,
            score = volleyballScore.teamBSets.toString(),
            overs = "Sets: ${volleyballScore.teamBPoints}",
            isBatting = false,
            scorePulse = 1f
        )
    }
}

@Composable
fun SportTypeBadge(
    sportType: SportType,
    isLive: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition()
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val sportInfo = when (sportType) {
        SportType.CRICKET -> Triple("🏏", "CRICKET", CricketGreen)
        SportType.KABADDI -> Triple("🤼", "KABADDI", KabaddiRed)
        SportType.VOLLEYBALL -> Triple("🏐", "VOLLEYBALL", VolleyballBlue)
    }
    
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(
                color = sportInfo.third.copy(alpha = 0.2f),
                shape = RoundedCornerShape(20.dp)
            )
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .scale(if (isLive) pulse else 1f)
    ) {
        Text(
            text = sportInfo.first,
            fontSize = 20.sp
        )
        
        Spacer(modifier = Modifier.width(8.dp))
        
        Text(
            text = sportInfo.second,
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.Black,
                color = sportInfo.third,
                letterSpacing = 1.sp
            )
        )
        
        if (isLive) {
            Spacer(modifier = Modifier.width(8.dp))
            
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(LiveRed, RoundedCornerShape(3.dp))
            )
        }
    }
}

@Composable
fun MatchTimerSection(
    match: Match,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val timerPulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "MATCH TIME",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = White60,
                        letterSpacing = 1.sp
                    )
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = "18.5 OV",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = NeonOrange,
                        fontFamily = FontFamily.SansSerif
                    ),
                    modifier = Modifier.scale(timerPulse)
                )
            }
            
            VerticalDivider(
                modifier = Modifier.height(40.dp),
                color = White20
            )
            
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "STATUS",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = White60,
                        letterSpacing = 1.sp
                    )
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = match.status.getDisplayText(),
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = match.status.getDisplayColor()
                    )
                )
            }
        }
    }
}

@Composable
fun PlayerHighlightsSection(
    match: Match
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "PLAYER HIGHLIGHTS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange
                    )
                )
                
                Icon(
                    imageVector = Icons.Default.TrendingUp,
                    contentDescription = null,
                    tint = NeonOrange,
                    modifier = Modifier.size(24.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Sample player highlights
            PlayerHighlightCard(
                playerName = "Rahul Sharma",
                teamName = match.teamAName,
                stats = "45 runs (32 balls)",
                isTopPerformer = true
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            PlayerHighlightCard(
                playerName = "Vikram Singh",
                teamName = match.teamBName,
                stats = "2 wickets (18 runs)",
                isTopPerformer = false
            )
        }
    }
}

@Composable
fun PlayerHighlightCard(
    playerName: String,
    teamName: String,
    stats: String,
    isTopPerformer: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = if (isTopPerformer) NeonOrange.copy(alpha = 0.1f) else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    color = if (isTopPerformer) NeonOrange else White20,
                    shape = RoundedCornerShape(20.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = playerName.getInitials(),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Black,
                    color = if (isTopPerformer) White else White80
                )
            )
        }
        
        Spacer(modifier = Modifier.width(12.dp))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = playerName,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isTopPerformer) NeonOrange else White
                )
            )
            
            Text(
                text = teamName,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = White60
                )
            )
        }
        
        if (isTopPerformer) {
            Icon(
                imageVector = Icons.Default.Stars,
                contentDescription = "Top Performer",
                tint = NeonOrange,
                modifier = Modifier.size(20.dp)
            )
        }
        
        Spacer(modifier = Modifier.width(8.dp))
        
        Text(
            text = stats,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Medium,
                color = White80
            )
        )
    }
}

@Composable
fun CommentaryPreviewSection(
    onCommentary: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LIVE COMMENTARY",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange
                    )
                )
                
                TextButton(
                    onClick = onCommentary,
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = "VIEW ALL",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NeonOrange,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Sample commentary
            CommentaryItem(
                over = "18.5",
                text = "Excellent delivery! Rahul Sharma finds the boundary with a powerful shot.",
                time = "2 min ago"
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            CommentaryItem(
                over = "18.4",
                text = "WICKET! Vikram Singh strikes again, clean bowled the batsman.",
                time = "3 min ago"
            )
        }
    }
}

@Composable
fun CommentaryItem(
    over: String,
    text: String,
    time: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = over,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Black,
                color = NeonOrange,
                fontFamily = FontFamily.SansSerif
            ),
            modifier = Modifier.width(40.dp)
        )
        
        Spacer(modifier = Modifier.width(12.dp))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White,
                    fontWeight = FontWeight.Medium
                )
            )
            
            Text(
                text = time,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = White60
                )
            )
        }
    }
}

@Composable
fun MatchStatisticsSection(
    match: Match
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "MATCH STATISTICS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Sample statistics
            StatRow(
                label = "Total Runs",
                teamAValue = "156",
                teamBValue = "89"
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            StatRow(
                label = "Wickets",
                teamAValue = "4",
                teamBValue = "2"
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            StatRow(
                label = "Run Rate",
                teamAValue = "8.3",
                teamBValue = "7.2"
            )
        }
    }
}

@Composable
fun StatRow(
    label: String,
    teamAValue: String,
    teamBValue: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = White60,
                fontWeight = FontWeight.Medium
            ),
            modifier = Modifier.weight(1f)
        )
        
        Text(
            text = teamAValue,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = NeonOrange
            ),
            modifier = Modifier.width(40.dp),
            textAlign = TextAlign.Center
        )
        
        Text(
            text = teamBValue,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = White
            ),
            modifier = Modifier.width(40.dp),
            textAlign = TextAlign.Center
        )
    }
}

// Extension function for getting initials
fun String.getInitials(): String {
    return this.split(" ").take(2).joinToString("") { 
        it.firstOrNull()?.uppercase() ?: "" 
    }
}
