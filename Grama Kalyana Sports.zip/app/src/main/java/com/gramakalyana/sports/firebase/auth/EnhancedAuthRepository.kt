package com.gramakalyana.sports.firebase.auth

import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.gramakalyana.sports.firebase.FirebaseManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * Enhanced Authentication Repository - Handles all Firebase Authentication operations
 * Supports Email/Password, Phone Number, and Google Sign-In methods
 */
class EnhancedAuthRepository private constructor() {
    
    private val auth: FirebaseAuth by lazy { FirebaseManager.getAuth() }
    private val emailAuthRepository: AuthRepository by lazy { AuthRepository.getInstance() }
    private val phoneAuthRepository: PhoneAuthRepository by lazy { PhoneAuthRepository.getInstance() }
    
    // Google Auth Repository needs context, will be initialized when needed
    private var googleAuthRepository: GoogleAuthRepository? = null
    
    /**
     * Initialize Google Auth Repository with context
     */
    fun initializeGoogleAuth(context: android.content.Context) {
        if (googleAuthRepository == null) {
            googleAuthRepository = GoogleAuthRepository.getInstance(context)
        }
    }
    
    /**
     * Get current user
     */
    val currentUser: FirebaseUser?
        get() = auth.currentUser
    
    /**
     * Check if user is authenticated
     */
    val isUserAuthenticated: Boolean
        get() = currentUser != null
    
    /**
     * Authentication state flow - emits authentication state changes
     */
    val authenticationStateFlow: Flow<EnhancedAuthenticationState> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            val state = if (user != null) {
                EnhancedAuthenticationState.Authenticated(user)
            } else {
                EnhancedAuthenticationState.Unauthenticated
            }
            trySend(state)
        }
        
        auth.addAuthStateListener(listener)
        
        awaitClose {
            auth.removeAuthStateListener(listener)
        }
    }
    
    /**
     * Sign up with email and password
     */
    suspend fun signUpWithEmail(
        email: String,
        password: String,
        name: String
    ): Result<AuthResult> {
        return emailAuthRepository.signUp(email, password, name)
    }
    
    /**
     * Sign in with email and password
     */
    suspend fun signInWithEmail(email: String, password: String): Result<AuthResult> {
        return emailAuthRepository.signIn(email, password)
    }
    
    /**
     * Send phone verification code
     */
    suspend fun sendPhoneVerificationCode(
        phoneNumber: String,
        callbacks: com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks
    ): Result<Unit> {
        return phoneAuthRepository.sendVerificationCode(phoneNumber, callbacks)
    }
    
    /**
     * Sign in with phone credential
     */
    suspend fun signInWithPhoneCredential(
        credential: com.google.firebase.auth.PhoneAuthCredential
    ): Result<String> {
        return phoneAuthRepository.signInWithPhoneCredential(credential)
    }
    
    /**
     * Create phone credential
     */
    fun createPhoneCredential(verificationId: String, code: String): com.google.firebase.auth.PhoneAuthCredential {
        return phoneAuthRepository.createPhoneCredential(verificationId, code)
    }
    
    /**
     * Resend phone verification code
     */
    suspend fun resendPhoneVerificationCode(
        phoneNumber: String,
        token: com.google.firebase.auth.PhoneAuthProvider.ForceResendingToken,
        callbacks: com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks
    ): Result<Unit> {
        return phoneAuthRepository.resendVerificationCode(phoneNumber, token, callbacks)
    }
    
    /**
     * Sign in with Google
     */
    suspend fun signInWithGoogle(account: com.google.android.gms.auth.api.signin.GoogleSignInAccount): Result<String> {
        return googleAuthRepository?.signInWithGoogle(account) ?: Result.failure(
            EnhancedAuthException.GoogleAuthNotInitialized("Google Auth not initialized. Call initializeGoogleAuth(context) first.")
        )
    }
    
    /**
     * Get Google Sign-In client
     */
    fun getGoogleSignInClient(): com.google.android.gms.auth.api.signin.GoogleSignInClient? {
        return googleAuthRepository?.getGoogleSignInClient()
    }
    
    /**
     * Check if signed in with Google
     */
    fun isSignedInWithGoogle(): Boolean {
        return googleAuthRepository?.isSignedInWithGoogle() ?: false
    }
    
    /**
     * Silent Google Sign-In
     */
    suspend fun silentGoogleSignIn(): Result<com.google.android.gms.auth.api.signin.GoogleSignInAccount?> {
        return googleAuthRepository?.silentSignIn() ?: Result.failure(
            EnhancedAuthException.GoogleAuthNotInitialized("Google Auth not initialized. Call initializeGoogleAuth(context) first.")
        )
    }
    
    /**
     * Send password reset email
     */
    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        return emailAuthRepository.sendPasswordResetEmail(email)
    }
    
    /**
     * Update user profile
     */
    suspend fun updateProfile(name: String): Result<Unit> {
        return emailAuthRepository.updateProfile(name)
    }
    
    /**
     * Update user email
     */
    suspend fun updateEmail(newEmail: String): Result<Unit> {
        return emailAuthRepository.updateEmail(newEmail)
    }
    
    /**
     * Update user password
     */
    suspend fun updatePassword(newPassword: String): Result<Unit> {
        return emailAuthRepository.updatePassword(newPassword)
    }
    
    /**
     * Delete user account
     */
    suspend fun deleteAccount(): Result<Unit> {
        return emailAuthRepository.deleteAccount()
    }
    
    /**
     * Reload user data
     */
    suspend fun reloadUser(): Result<FirebaseUser> {
        return emailAuthRepository.reloadUser()
    }
    
    /**
     * Sign out current user (from all auth methods)
     */
    suspend fun signOut(): Result<Unit> {
        return try {
            // Sign out from Firebase
            auth.signOut()
            
            // Sign out from Google if available
            googleAuthRepository?.signOut()
            
            // Clean up phone auth
            phoneAuthRepository.cleanupAll()
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(EnhancedAuthException.SignOutFailed("Failed to sign out: ${e.message}"))
        }
    }
    
    /**
     * Revoke Google access
     */
    suspend fun revokeGoogleAccess(): Result<Unit> {
        return googleAuthRepository?.revokeAccess() ?: Result.failure(
            EnhancedAuthException.GoogleAuthNotInitialized("Google Auth not initialized. Call initializeGoogleAuth(context) first.")
        )
    }
    
    /**
     * Get authentication method for current user
     */
    fun getAuthMethod(): String {
        val user = currentUser ?: return "none"
        
        return when {
            user.phoneNumber != null -> "phone"
            user.email?.endsWith("@gmail.com") == true && isSignedInWithGoogle() -> "google"
            user.email != null -> "email"
            else -> "unknown"
        }
    }
    
    /**
     * Enable phone auth testing (for development)
     */
    fun enablePhoneAuthTesting() {
        phoneAuthRepository.enablePhoneAuthTesting()
    }
    
    /**
     * Force reCAPTCHA flow (for testing)
     */
    fun forceRecaptchaFlowForTesting() {
        phoneAuthRepository.forceRecaptchaFlowForTesting()
    }
    
    /**
     * Set auto-retrieved SMS code for testing
     */
    fun setAutoRetrievedSmsCodeForTesting(phoneNumber: String, smsCode: String) {
        phoneAuthRepository.setAutoRetrievedSmsCodeForTesting(phoneNumber, smsCode)
    }
    
    companion object {
        @Volatile
        private var INSTANCE: EnhancedAuthRepository? = null
        
        fun getInstance(): EnhancedAuthRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: EnhancedAuthRepository().also { INSTANCE = it }
            }
        }
    }
}

/**
 * Authentication state sealed class
 */
sealed class EnhancedAuthenticationState {
    data class Authenticated(val user: FirebaseUser) : EnhancedAuthenticationState()
    object Unauthenticated : EnhancedAuthenticationState()
}

/**
 * Custom authentication exceptions
 */
sealed class EnhancedAuthException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class InvalidInput(message: String) : EnhancedAuthException(message)
    class InvalidEmail(message: String) : EnhancedAuthException(message)
    class InvalidPassword(message: String) : EnhancedAuthException(message)
    class WeakPassword(message: String) : EnhancedAuthException(message)
    class EmailAlreadyInUse(message: String) : EnhancedAuthException(message)
    class UserNotFound(message: String) : EnhancedAuthException(message)
    class NetworkError(message: String) : EnhancedAuthException(message)
    class SignOutFailed(message: String) : EnhancedAuthException(message)
    class ProfileUpdateFailed(message: String) : EnhancedAuthException(message)
    class AccountDeletionFailed(message: String) : EnhancedAuthException(message)
    class UserReloadFailed(message: String) : EnhancedAuthException(message)
    class GoogleAuthNotInitialized(message: String) : EnhancedAuthException(message)
    class UnknownError(message: String) : EnhancedAuthException(message)
}
