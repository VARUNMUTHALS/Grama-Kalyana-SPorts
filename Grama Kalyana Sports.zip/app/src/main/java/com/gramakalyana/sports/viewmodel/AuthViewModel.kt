package com.gramakalyana.sports.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseUser
import com.gramakalyana.sports.firebase.auth.AuthRepository
import com.gramakalyana.sports.firebase.auth.AuthenticationState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Authentication ViewModel - Handles authentication state and operations
 * Provides clean interface for UI components to interact with authentication
 */
class AuthViewModel : ViewModel() {
    
    private val authRepository = AuthRepository.getInstance()
    
    // Authentication state
    private val _authenticationState = MutableStateFlow<AuthenticationState>(
        AuthenticationState.Unauthenticated
    )
    val authenticationState: StateFlow<AuthenticationState> = _authenticationState.asStateFlow()
    
    // Loading states
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    // Error states
    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()
    
    // Current user
    private val _currentUser = MutableStateFlow<FirebaseUser?>(null)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()
    
    init {
        // Observe authentication state changes
        viewModelScope.launch {
            authRepository.authenticationStateFlow.collect { state ->
                _authenticationState.value = state
                when (state) {
                    is AuthenticationState.Authenticated -> {
                        _currentUser.value = state.user
                        _errorMessage.value = null
                    }
                    AuthenticationState.Unauthenticated -> {
                        _currentUser.value = null
                    }
                }
            }
        }
    }
    
    /**
     * Sign up with email and password
     */
    fun signUp(email: String, password: String, name: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            authRepository.signUp(email, password, name)
                .onSuccess {
                    _isLoading.value = false
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Sign in with email and password
     */
    fun signIn(email: String, password: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            authRepository.signIn(email, password)
                .onSuccess {
                    _isLoading.value = false
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Sign out current user
     */
    fun signOut() {
        viewModelScope.launch {
            _isLoading.value = true
            
            authRepository.signOut()
                .onSuccess {
                    _isLoading.value = false
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Send password reset email
     */
    fun sendPasswordResetEmail(email: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            authRepository.sendPasswordResetEmail(email)
                .onSuccess {
                    _isLoading.value = false
                    _errorMessage.value = "Password reset email sent successfully"
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Update user profile
     */
    fun updateProfile(name: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            authRepository.updateProfile(name)
                .onSuccess {
                    _isLoading.value = false
                    _errorMessage.value = "Profile updated successfully"
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Update user email
     */
    fun updateEmail(newEmail: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            authRepository.updateEmail(newEmail)
                .onSuccess {
                    _isLoading.value = false
                    _errorMessage.value = "Email updated successfully"
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Update user password
     */
    fun updatePassword(newPassword: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            authRepository.updatePassword(newPassword)
                .onSuccess {
                    _isLoading.value = false
                    _errorMessage.value = "Password updated successfully"
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Delete user account
     */
    fun deleteAccount() {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            authRepository.deleteAccount()
                .onSuccess {
                    _isLoading.value = false
                    _errorMessage.value = "Account deleted successfully"
                }
                .onFailure { exception ->
                    _isLoading.value = false
                    _errorMessage.value = exception.message
                }
        }
    }
    
    /**
     * Clear error message
     */
    fun clearError() {
        _errorMessage.value = null
    }
    
    /**
     * Check if user is authenticated
     */
    fun isUserAuthenticated(): Boolean {
        return authRepository.isUserAuthenticated
    }
    
    /**
     * Get current user ID
     */
    fun getCurrentUserId(): String? {
        return authRepository.currentUser?.uid
    }
}
