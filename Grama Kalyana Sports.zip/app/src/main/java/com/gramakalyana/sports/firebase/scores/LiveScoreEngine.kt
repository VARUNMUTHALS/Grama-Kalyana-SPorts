package com.gramakalyana.sports.firebase.scores

import com.gramakalyana.sports.firebase.FirebaseManager
import com.gramakalyana.sports.models.LiveScore
import com.gramakalyana.sports.models.MatchStatus
import com.gramakalyana.sports.models.SportType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.tasks.await

/**
 * Build-safe facade for live score persistence.
 *
 * The richer transaction engine previously in this file targeted a different
 * LiveScore model shape than the one present in this project. Keep the public
 * entry points available while using the repository's current model until the
 * scoring domain is reconciled end to end.
 */
class LiveScoreEngine private constructor() {
    suspend fun initializeLiveScore(matchId: String, sportType: SportType): Result<Unit> = runCatching {
        val score = LiveScore(matchId = matchId, sportType = sportType)
        FirebaseManager.getLiveScoreReference(matchId).setValue(score).await()
    }

    fun getLiveScoreUpdates(matchId: String): Flow<LiveScoreUpdate> = emptyFlow()

    suspend fun updateMatchStatus(matchId: String, status: MatchStatus): Result<Unit> = runCatching {
        FirebaseManager.getMatchReference(matchId).child("status").setValue(status.name).await()
        FirebaseManager.getLiveScoreReference(matchId).child("isLive")
            .setValue(status == MatchStatus.LIVE)
            .await()
    }

    suspend fun updateViewersCount(matchId: String, count: Int): Result<Unit> = runCatching {
        FirebaseManager.getLiveScoreReference(matchId).child("viewers").setValue(count).await()
    }

    suspend fun getCurrentScore(matchId: String): Result<LiveScore?> = runCatching {
        FirebaseManager.getLiveScoreReference(matchId).get().await().getValue(LiveScore::class.java)
    }

    fun cleanupMatch(matchId: String) = Unit

    fun cleanup() = Unit

    companion object {
        @Volatile
        private var INSTANCE: LiveScoreEngine? = null

        fun getInstance(): LiveScoreEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: LiveScoreEngine().also { INSTANCE = it }
            }
        }
    }
}

data class LiveScoreUpdate(
    val matchId: String,
    val score: LiveScore,
    val timestamp: Long,
    val viewersCount: Int
)
