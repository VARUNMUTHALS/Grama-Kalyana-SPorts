package com.gramakalyana.sports.utils

object Constants {
    
    // Firebase Constants
    const val FIREBASE_DATABASE_URL = "https://grama-kalyana-sports-default-rtdb.firebaseio.com/"
    const val FIREBASE_STORAGE_URL = "gs://grama-kalyana-sports.appspot.com"
    
    // App Constants
    const val APP_NAME = "Grama Kalyana Sports"
    const val APP_VERSION = "1.0.0"
    
    // Network Constants
    const val CONNECT_TIMEOUT = 30L // seconds
    const val READ_TIMEOUT = 30L // seconds
    const val WRITE_TIMEOUT = 30L // seconds
    
    // UI Constants
    const val ANIMATION_DURATION = 300L
    const val SPLASH_DELAY = 2000L
    const val DEBOUNCE_DELAY = 500L
    
    // Scoreboard Constants
    const val MAX_CRICKET_OVERS = 50
    const val MAX_CRICKET_OVERS_T20 = 20
    const val KABADDI_MATCH_TIME = 40 // minutes
    const val KABADDI_RAID_TIME = 30 // seconds
    const val VOLLEYBALL_SETS_TO_WIN = 3
    const val VOLLEYBALL_POINTS_PER_SET = 25
    
    // Validation Constants
    const val MIN_TEAM_NAME_LENGTH = 3
    const val MAX_TEAM_NAME_LENGTH = 50
    const val MIN_PLAYER_NAME_LENGTH = 2
    const val MAX_PLAYER_NAME_LENGTH = 30
    const val MIN_JERSEY_NUMBER = 1
    const val MAX_JERSEY_NUMBER = 99
    
    // Pagination Constants
    const val PAGE_SIZE = 20
    const val FIRST_PAGE_INDEX = 1
    
    // Cache Constants
    const val CACHE_SIZE = 10 * 1024 * 1024 // 10MB
    const val CACHE_MAX_AGE = 60 * 60 * 24 // 24 hours
    
    // SharedPreferences Keys
    const val PREFS_NAME = "sports_prefs"
    const val KEY_USER_ID = "user_id"
    const val KEY_USER_NAME = "user_name"
    const val KEY_USER_EMAIL = "user_email"
    const val KEY_IS_LOGGED_IN = "is_logged_in"
    const val KEY_DARK_THEME = "dark_theme"
    const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"
    const val KEY_SOUND_ENABLED = "sound_enabled"
    const val KEY_VIBRATION_ENABLED = "vibration_enabled"
    const val KEY_LIVE_UPDATES_ENABLED = "live_updates_enabled"
    
    // Intent Extras
    const val EXTRA_TOURNAMENT_ID = "tournament_id"
    const val EXTRA_TEAM_ID = "team_id"
    const val EXTRA_PLAYER_ID = "player_id"
    const val EXTRA_MATCH_ID = "match_id"
    const val EXTRA_SPORT_TYPE = "sport_type"
    
    // Error Messages
    const val ERROR_NETWORK = "Network error. Please check your internet connection."
    const val ERROR_AUTHENTICATION = "Authentication failed. Please login again."
    const val ERROR_PERMISSION_DENIED = "Permission denied. You don't have access to this resource."
    const val ERROR_NOT_FOUND = "Data not found."
    const val ERROR_UNKNOWN = "An unknown error occurred. Please try again."
    const val ERROR_VALIDATION = "Invalid input. Please check your data."
    const val ERROR_SERVER = "Server error. Please try again later."
    
    // Success Messages
    const val SUCCESS_TOURNAMENT_CREATED = "Tournament created successfully."
    const val SUCCESS_TEAM_ADDED = "Team added successfully."
    const val SUCCESS_PLAYER_ADDED = "Player added successfully."
    const val SUCCESS_MATCH_CREATED = "Match created successfully."
    const val SUCCESS_SCORE_UPDATED = "Score updated successfully."
    const val SUCCESS_DATA_SAVED = "Data saved successfully."
    const val SUCCESS_DATA_DELETED = "Data deleted successfully."
    
    // Notification Channels
    const val CHANNEL_LIVE_MATCHES = "live_matches"
    const val CHANNEL_MATCH_UPDATES = "match_updates"
    const val CHANNEL_TOURNAMENT_UPDATES = "tournament_updates"
    const val CHANNEL_GENERAL = "general"
    
    // Notification IDs
    const val NOTIFICATION_LIVE_MATCH = 1001
    const val NOTIFICATION_MATCH_START = 1002
    const val NOTIFICATION_MATCH_END = 1003
    const val NOTIFICATION_TOURNAMENT_START = 1004
    
    // Deep Link Patterns
    const val DEEP_LINK_SCHEME = "sports"
    const val DEEP_LINK_HOST = "gramakalyana.com"
    const val DEEP_LINK_TOURNAMENT = "/tournament"
    const val DEEP_LINK_MATCH = "/match"
    const val DEEP_LINK_TEAM = "/team"
    const val DEEP_LINK_PLAYER = "/player"
    
    // File Upload Constants
    const val MAX_IMAGE_SIZE = 5 * 1024 * 1024 // 5MB
    const val IMAGE_QUALITY = 80
    const val SUPPORTED_IMAGE_TYPES = "image/jpeg,image/png,image/webp"
    
    // Date Formats
    const val DATE_FORMAT_DISPLAY = "dd MMM yyyy"
    const val DATE_FORMAT_API = "yyyy-MM-dd"
    const val DATE_FORMAT_TIME = "hh:mm a"
    const val DATE_FORMAT_DATETIME = "dd MMM yyyy, hh:mm a"
    
    // Regex Patterns
    val EMAIL_PATTERN = Regex("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")
    val PHONE_PATTERN = Regex("^[+]?[0-9]{10,15}$")
    val NAME_PATTERN = Regex("^[a-zA-Z\\s]{2,50}$")
    
    // Sport Specific Constants
    object Cricket {
        const val MAX_WICKETS = 10
        const val BALLS_PER_OVER = 6
        const val MAX_RUNS_PER_BALL = 6
        const val NO_BALL_RUNS = 1
        const val WIDE_BALL_RUNS = 1
    }
    
    object Kabaddi {
        const val PLAYERS_PER_TEAM = 7
        const val MIN_PLAYERS_ON_COURT = 1
        const val MAX_RAID_POINTS = 4
        const val MAX_TACKLE_POINTS = 2
        const val ALL_OUT_POINTS = 2
        const val SUPER_RAID_POINTS = 3
        const val SUPER_TACKLE_POINTS = 3
    }
    
    object Volleyball {
        const val PLAYERS_PER_TEAM = 6
        const val MIN_SET_POINTS = 25
        const val MIN_FINAL_SET_POINTS = 15
        const val MAX_SETS_PER_MATCH = 5
        const val TIME_OUTS_PER_SET = 2
        const val SUBSTITUTIONS_PER_SET = 6
    }
}
