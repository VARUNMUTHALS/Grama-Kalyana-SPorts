package com.gramakalyana.sports.firebase.auth

import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.gramakalyana.sports.R
import com.gramakalyana.sports.firebase.FirebaseManager
import kotlinx.coroutines.tasks.await

/**
 * Google Sign-In Repository - Handles Firebase Google Authentication
 * Provides clean interface for Google Sign-In operations
 */
class GoogleAuthRepository private constructor(private val context: android.content.Context) {
    
    private val auth: FirebaseAuth by lazy { FirebaseManager.getAuth() }
    private val signInClient: GoogleSignInClient by lazy { createGoogleSignInClient() }
    
    /**
     * Get Google Sign-In client
     */
    fun getGoogleSignInClient(): GoogleSignInClient {
        return signInClient
    }
    
    /**
     * Sign in with Google account
     */
    suspend fun signInWithGoogle(account: GoogleSignInAccount): Result<String> {
        return try {
            val credential = GoogleAuthProvider.getCredential(account.idToken, null)
            val authResult = auth.signInWithCredential(credential).await()
            
            val userId = authResult.user?.uid ?: return Result.failure(
                GoogleAuthException.SignInFailed("Failed to get user ID after sign in")
            )
            
            // Create user profile in database if needed
            createUserProfileInDatabase(authResult.user, account)
            
            Result.success(userId)
        } catch (e: Exception) {
            Result.failure(handleGoogleAuthException(e))
        }
    }
    
    /**
     * Sign out from Google
     */
    suspend fun signOut(): Result<Unit> {
        return try {
            // Sign out from Firebase
            auth.signOut()
            
            // Sign out from Google
            signInClient.signOut().await()
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(GoogleAuthException.SignOutFailed("Failed to sign out: ${e.message}"))
        }
    }
    
    /**
     * Revoke Google access
     */
    suspend fun revokeAccess(): Result<Unit> {
        return try {
            // Sign out from Firebase
            auth.signOut()
            
            // Revoke Google access
            signInClient.revokeAccess().await()
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(GoogleAuthException.RevokeAccessFailed("Failed to revoke access: ${e.message}"))
        }
    }
    
    /**
     * Get current user
     */
    val currentUser get() = auth.currentUser
    
    /**
     * Check if user is authenticated
     */
    val isUserAuthenticated get() = currentUser != null
    
    /**
     * Get signed-in Google account
     */
    suspend fun getSignedInAccount(): Result<GoogleSignInAccount?> {
        return try {
            val account = GoogleSignIn.getSignedInAccountFromIntent(null).await()
            Result.success(account)
        } catch (e: Exception) {
            Result.failure(handleGoogleAuthException(e))
        }
    }
    
    /**
     * Check if user is signed in with Google
     */
    fun isSignedInWithGoogle(): Boolean {
        return GoogleSignIn.getLastSignedInAccount(context) != null
    }
    
    /**
     * Get silent sign-in result
     */
    suspend fun silentSignIn(): Result<GoogleSignInAccount?> {
        return try {
            val account = signInClient.silentSignIn().await()
            Result.success(account)
        } catch (e: Exception) {
            Result.failure(handleGoogleAuthException(e))
        }
    }
    
    // Private helper methods
    
    private fun createGoogleSignInClient(): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(context.getString(R.string.default_web_client_id))
            .requestEmail()
            .requestProfile()
            .build()
        
        return GoogleSignIn.getClient(context, gso)
    }
    
    private suspend fun createUserProfileInDatabase(
        user: com.google.firebase.auth.FirebaseUser?,
        account: GoogleSignInAccount
    ) {
        user?.let { firebaseUser ->
            val userProfile = mapOf(
                "uid" to firebaseUser.uid,
                "email" to firebaseUser.email,
                "name" to firebaseUser.displayName,
                "profileImage" to firebaseUser.photoUrl?.toString(),
                "googleId" to account.id,
                "createdAt" to System.currentTimeMillis(),
                "lastLoginAt" to System.currentTimeMillis(),
                "isEmailVerified" to firebaseUser.isEmailVerified,
                "authMethod" to "google",
                "role" to "USER"
            )
            
            FirebaseManager.usersRef.child(firebaseUser.uid).setValue(userProfile).await()
        }
    }
    
    private fun handleGoogleAuthException(exception: Exception): GoogleAuthException {
        return when (exception) {
            is ApiException -> {
                when (exception.statusCode) {
                    7 -> GoogleAuthException.NetworkError("Network error occurred")
                    8 -> GoogleAuthException.InternalError("Internal error occurred")
                    10 -> GoogleAuthException.DeveloperError("Developer error - check configuration")
                    13 -> GoogleAuthException.ApiNotConnected("API not connected")
                    16 -> GoogleAuthException.Canceled("Sign-in was canceled")
                    17 -> GoogleAuthException.Interrupted("Sign-in was interrupted")
                    12501 -> GoogleAuthException.SignInFailed("Sign-in failed")
                    12502 -> GoogleAuthException.SignInFailed("No network available")
                    else -> GoogleAuthException.ApiError("Google Sign-In API error: ${exception.statusCode}")
                }
            }
            else -> GoogleAuthException.UnknownError("Google authentication failed: ${exception.message}", exception)
        }
    }
    
    companion object {
        @Volatile
        private var INSTANCE: GoogleAuthRepository? = null
        
        fun getInstance(context: android.content.Context): GoogleAuthRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: GoogleAuthRepository(context).also { INSTANCE = it }
            }
        }
    }
}

/**
 * Custom exceptions for Google authentication operations
 */
sealed class GoogleAuthException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class NetworkError(message: String) : GoogleAuthException(message)
    class InternalError(message: String) : GoogleAuthException(message)
    class DeveloperError(message: String) : GoogleAuthException(message)
    class ApiNotConnected(message: String) : GoogleAuthException(message)
    class Canceled(message: String) : GoogleAuthException(message)
    class Interrupted(message: String) : GoogleAuthException(message)
    class ApiError(message: String) : GoogleAuthException(message)
    class SignInFailed(message: String) : GoogleAuthException(message)
    class SignOutFailed(message: String) : GoogleAuthException(message)
    class RevokeAccessFailed(message: String) : GoogleAuthException(message)
    class UnknownError(message: String, cause: Throwable? = null) : GoogleAuthException(message, cause)
}
