package com.gramakalyana.sports.navigation

object Destination {
    // Main Navigation
    const val SPLASH = "splash"
    const val HOME = "home"
    const val TOURNAMENTS = "tournaments"
    const val LIVE_SCORES = "live_scores"
    const val STATISTICS = "statistics"
    const val SETTINGS = "settings"
    
    // Tournament Management
    const val TOURNAMENT_LIST = "tournament_list"
    const val TOURNAMENT_DETAIL = "tournament_detail"
    const val CREATE_TOURNAMENT = "create_tournament"
    const val EDIT_TOURNAMENT = "edit_tournament"
    
    // Team Management
    const val TEAM_LIST = "team_list"
    const val TEAM_DETAIL = "team_detail"
    const val CREATE_TEAM = "create_team"
    const val EDIT_TEAM = "edit_team"
    const val ADD_PLAYERS = "add_players"
    
    // Player Management
    const val PLAYER_LIST = "player_list"
    const val PLAYER_DETAIL = "player_detail"
    const val CREATE_PLAYER = "create_player"
    const val EDIT_PLAYER = "edit_player"
    
    // Match Management
    const val MATCH_LIST = "match_list"
    const val MATCH_DETAIL = "match_detail"
    const val CREATE_MATCH = "create_match"
    const val EDIT_MATCH = "edit_match"
    const val MATCH_SCHEDULE = "match_schedule"
    
    // Live Scorer
    const val LIVE_SCORER = "live_scorer"
    const val CRICKET_SCORER = "cricket_scorer"
    const val KABADDI_SCORER = "kabaddi_scorer"
    const val VOLLEYBALL_SCORER = "volleyball_scorer"
    
    // Public View
    const val PUBLIC_LIVE_VIEW = "public_live_view"
    const val LIVE_MATCH_VIEW = "live_match_view"
    
    // Statistics
    const val TOURNAMENT_STATS = "tournament_stats"
    const val TEAM_STATS = "team_stats"
    const val PLAYER_STATS = "player_stats"
    const val PLAYER_CAREER = "player_career"
    
    // Authentication
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val FORGOT_PASSWORD = "forgot_password"
    
    // Arguments
    const val TOURNAMENT_ID_ARG = "tournamentId"
    const val TEAM_ID_ARG = "teamId"
    const val PLAYER_ID_ARG = "playerId"
    const val MATCH_ID_ARG = "matchId"
    const val SPORT_TYPE_ARG = "sportType"
    
    // Routes with arguments
    const val TOURNAMENT_DETAIL_ROUTE = "$TOURNAMENT_DETAIL/{$TOURNAMENT_ID_ARG}"
    const val EDIT_TOURNAMENT_ROUTE = "$EDIT_TOURNAMENT/{$TOURNAMENT_ID_ARG}"
    const val TEAM_DETAIL_ROUTE = "$TEAM_DETAIL/{$TEAM_ID_ARG}"
    const val EDIT_TEAM_ROUTE = "$EDIT_TEAM/{$TEAM_ID_ARG}"
    const val ADD_PLAYERS_ROUTE = "$ADD_PLAYERS/{$TEAM_ID_ARG}"
    const val PLAYER_DETAIL_ROUTE = "$PLAYER_DETAIL/{$PLAYER_ID_ARG}"
    const val EDIT_PLAYER_ROUTE = "$EDIT_PLAYER/{$PLAYER_ID_ARG}"
    const val MATCH_DETAIL_ROUTE = "$MATCH_DETAIL/{$MATCH_ID_ARG}"
    const val EDIT_MATCH_ROUTE = "$EDIT_MATCH/{$MATCH_ID_ARG}"
    const val LIVE_SCORER_ROUTE = "$LIVE_SCORER/{$MATCH_ID_ARG}"
    const val LIVE_MATCH_VIEW_ROUTE = "$LIVE_MATCH_VIEW/{$MATCH_ID_ARG}"
    const val CRICKET_SCORER_ROUTE = "$CRICKET_SCORER/{$MATCH_ID_ARG}"
    const val KABADDI_SCORER_ROUTE = "$KABADDI_SCORER/{$MATCH_ID_ARG}"
    const val VOLLEYBALL_SCORER_ROUTE = "$VOLLEYBALL_SCORER/{$MATCH_ID_ARG}"
    const val TOURNAMENT_STATS_ROUTE = "$TOURNAMENT_STATS/{$TOURNAMENT_ID_ARG}"
    const val TEAM_STATS_ROUTE = "$TEAM_STATS/{$TEAM_ID_ARG}"
    const val PLAYER_STATS_ROUTE = "$PLAYER_STATS/{$PLAYER_ID_ARG}"
    const val PLAYER_CAREER_ROUTE = "$PLAYER_CAREER/{$PLAYER_ID_ARG}"
}
