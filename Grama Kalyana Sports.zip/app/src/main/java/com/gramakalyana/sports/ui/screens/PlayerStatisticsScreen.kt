package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerStatisticsScreen(
    playerId: String,
    onBack: () -> Unit,
    onShare: () -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(140000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val statsGlow by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Player data
    val player = remember {
        Player(
            id = playerId,
            name = "Rahul Sharma",
            teamId = "team_001",
            teamName = "Royal Warriors",
            jerseyNumber = 7,
            role = PlayerRole.BATSMAN,
            age = 24,
            phoneNumber = "+919876543210",
            email = "rahul.sharma@example.com",
            totalMatches = 25,
            totalRuns = 1250,
            totalWickets = 12,
            totalPoints = 145,
            status = PlayerStatus.ACTIVE,
            joinDate = System.currentTimeMillis() - 86400000 * 365 * 2, // 2 years ago
            battingAverage = 52.5,
            strikeRate = 145.8,
            bowlingAverage = 28.3,
            economyRate = 6.2,
            highestScore = 98,
            bestBowling = "3/24",
            manOfTheMatchAwards = 5,
            catches = 18,
            runOuts = 7
        )
    }
    
    // Recent matches data
    val recentMatches = remember {
        listOf(
            PlayerMatchPerformance(
                matchId = "match_001",
                opponent = "Thunder Strikers",
                date = System.currentTimeMillis() - 86400000 * 2,
                runs = 78,
                wickets = 2,
                points = 15,
                result = "Won"
            ),
            PlayerMatchPerformance(
                matchId = "match_002",
                opponent = "Lions Club",
                date = System.currentTimeMillis() - 86400000 * 7,
                runs = 45,
                wickets = 1,
                points = 10,
                result = "Won"
            ),
            PlayerMatchPerformance(
                matchId = "match_003",
                opponent = "Eagles Team",
                date = System.currentTimeMillis() - 86400000 * 14,
                runs = 32,
                wickets = 0,
                points = 8,
                result = "Lost"
            ),
            PlayerMatchPerformance(
                matchId = "match_004",
                opponent = "Thunder Strikers",
                date = System.currentTimeMillis() - 86400000 * 21,
                runs = 98,
                wickets = 1,
                points = 20,
                result = "Won"
            ),
            PlayerMatchPerformance(
                matchId = "match_005",
                opponent = "Lions Club",
                date = System.currentTimeMillis() - 86400000 * 28,
                runs = 56,
                wickets = 3,
                points = 18,
                result = "Won"
            )
        )
    }
    
    val listState = rememberLazyListState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Statistics background
        PlayerStatsBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = statsGlow
        )
        
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            PlayerStatsHeader(
                onBack = onBack,
                onShare = onShare,
                statsGlow = statsGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Player profile card
            PlayerProfileCard(
                player = player,
                statsGlow = statsGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Career statistics
            CareerStatisticsSection(
                player = player,
                statsGlow = statsGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Performance chart
            PerformanceChartSection(
                player = player,
                statsGlow = statsGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Recent performances
            RecentPerformancesSection(
                recentMatches = recentMatches,
                statsGlow = statsGlow
            )
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

data class PlayerMatchPerformance(
    val matchId: String,
    val opponent: String,
    val date: Long,
    val runs: Int,
    val wickets: Int,
    val points: Int,
    val result: String
)

@Composable
fun PlayerStatsBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle background effect
        val positions = listOf(
            Offset(canvasWidth * 0.1f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.1f),
            Offset(canvasWidth * 0.1f, canvasHeight * 0.9f),
            Offset(canvasWidth * 0.9f, canvasHeight * 0.9f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.5f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center pattern
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        drawCircle(
            color = NeonOrange.copy(alpha = glowAlpha * 0.05f),
            radius = min(canvasWidth, canvasHeight) * 0.3f,
            center = Offset(centerX, centerY)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerStatsHeader(
    onBack: () -> Unit,
    onShare: () -> Unit,
    statsGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val logoPulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "PLAYER STATISTICS",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange,
                    letterSpacing = 2.sp
                )
            )
            
            Text(
                text = "Performance Analytics",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White80
                )
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        IconButton(
            onClick = onShare,
            modifier = Modifier
                .background(NeonOrange.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                .size(48.dp)
                .scale(logoPulse)
        ) {
            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = "Share",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun PlayerProfileCard(
    player: Player,
    statsGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val cardPulse by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .scale(cardPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 12.dp
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 2.dp,
            color = NeonOrange.copy(alpha = statsGlow)
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Player avatar
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(
                        color = NeonOrange.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(40.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = player.name.getInitials(),
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = NeonOrange
                    )
                )
            }
            
            Spacer(modifier = Modifier.width(20.dp))
            
            // Player info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = player.name,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange
                    )
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Jersey #${player.jerseyNumber}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = White80,
                            fontWeight = FontWeight.Medium
                        )
                    )
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    Text(
                        text = "•",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = White40
                        )
                    )
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    Text(
                        text = player.role.name,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = NeonGreen,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = player.teamName ?: "Team Name",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White60
                    )
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Status badge
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(NeonGreen, RoundedCornerShape(4.dp))
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Text(
                        text = "ACTIVE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NeonGreen,
                            letterSpacing = 1.sp
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun CareerStatisticsSection(
    player: Player,
    statsGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val statsPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .scale(statsPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "CAREER STATISTICS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(20.dp))
            
            // Statistics grid
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // First row - Basic stats
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatCard(
                        label = "MATCHES",
                        value = player.totalMatches.toString(),
                        color = NeonOrange,
                        modifier = Modifier.weight(1f)
                    )
                    
                    StatCard(
                        label = "RUNS",
                        value = player.totalRuns.toString(),
                        color = NeonGreen,
                        modifier = Modifier.weight(1f)
                    )
                    
                    StatCard(
                        label = "WICKETS",
                        value = player.totalWickets.toString(),
                        color = NeonRed,
                        modifier = Modifier.weight(1f)
                    )
                }
                
                // Second row - Performance stats
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatCard(
                        label = "AVG",
                        value = String.format("%.1f", player.battingAverage ?: 0.0),
                        color = VolleyballBlue,
                        modifier = Modifier.weight(1f)
                    )
                    
                    StatCard(
                        label = "SR",
                        value = String.format("%.1f", player.strikeRate ?: 0.0),
                        color = NeonYellow,
                        modifier = Modifier.weight(1f)
                    )
                    
                    StatCard(
                        label = "MOTM",
                        value = player.manOfTheMatchAwards.toString(),
                        color = KabaddiRed,
                        modifier = Modifier.weight(1f)
                    )
                }
                
                // Third row - Fielding stats
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatCard(
                        label = "CATCHES",
                        value = player.catches.toString(),
                        color = CricketGreen,
                        modifier = Modifier.weight(1f)
                    )
                    
                    StatCard(
                        label = "RUN OUTS",
                        value = player.runOuts.toString(),
                        color = White80,
                        modifier = Modifier.weight(1f)
                    )
                    
                    StatCard(
                        label = "POINTS",
                        value = player.totalPoints.toString(),
                        color = NeonOrange,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun StatCard(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.1f)
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Black,
                    color = color,
                    fontFamily = FontFamily.SansSerif
                )
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = White60,
                    letterSpacing = 1.sp
                )
            )
        }
    }
}

@Composable
fun PerformanceChartSection(
    player: Player,
    statsGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val chartPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .scale(chartPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "PERFORMANCE HIGHLIGHTS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(20.dp))
            
            // Performance highlights
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                HighlightItem(
                    icon = Icons.Default.TrendingUp,
                    label = "Highest Score",
                    value = "${player.highestScore ?: 0} runs",
                    color = NeonGreen
                )
                
                HighlightItem(
                    icon = Icons.Default.SportsCricket,
                    label = "Best Bowling",
                    value = player.bestBowling ?: "N/A",
                    color = NeonRed
                )
                
                HighlightItem(
                    icon = Icons.Default.EmojiEvents,
                    label = "Awards",
                    value = "${player.manOfTheMatchAwards} MOTM",
                    color = NeonYellow
                )
                
                HighlightItem(
                    icon = Icons.Default.CalendarToday,
                    label = "Experience",
                    value = "${getExperienceYears(player.joinDate)} years",
                    color = VolleyballBlue
                )
            }
        }
    }
}

@Composable
fun HighlightItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    color: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(24.dp)
        )
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = White60
                )
            )
            
            Text(
                text = value,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            )
        }
    }
}

@Composable
fun RecentPerformancesSection(
    recentMatches: List<PlayerMatchPerformance>,
    statsGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val listPulse by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .scale(listPulse),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "RECENT PERFORMANCES",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(recentMatches) { match ->
                    RecentMatchCard(match)
                }
            }
        }
    }
}

@Composable
fun RecentMatchCard(
    match: PlayerMatchPerformance
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 0.dp
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "vs ${match.opponent}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = White
                    )
                )
                
                Text(
                    text = getFormattedDate(match.date),
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = White60
                    )
                )
            }
            
            // Performance stats
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = match.runs.toString(),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NeonGreen
                        )
                    )
                    
                    Text(
                        text = "Runs",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = White60
                        )
                    )
                }
                
                if (match.wickets > 0) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    ) {
                        Text(
                            text = match.wickets.toString(),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NeonRed
                            )
                        )
                        
                        Text(
                            text = "Wickets",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = White60
                            )
                        )
                    }
                }
                
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = match.points.toString(),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NeonOrange
                        )
                    )
                    
                    Text(
                        text = "Points",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = White60
                        )
                    )
                }
            }
            
            // Result badge
            Box(
                modifier = Modifier
                    .background(
                        color = if (match.result == "Won") NeonGreen.copy(alpha = 0.2f) else NeonRed.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = match.result,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (match.result == "Won") NeonGreen else NeonRed,
                        letterSpacing = 1.sp
                    )
                )
            }
        }
    }
}

// Helper functions
fun String.getInitials(): String {
    return this.split(" ").take(2).joinToString("") { 
        it.firstOrNull()?.uppercase() ?: "" 
    }
}

fun getExperienceYears(joinDate: Long): Int {
    val currentTime = System.currentTimeMillis()
    val diffInMs = currentTime - joinDate
    val years = diffInMs / (1000 * 60 * 60 * 24 * 365)
    return years.toInt()
}

fun getFormattedDate(timestamp: Long): String {
    val date = java.util.Date(timestamp)
    val formatter = java.text.SimpleDateFormat("dd MMM", java.util.Locale.getDefault())
    return formatter.format(date)
}
