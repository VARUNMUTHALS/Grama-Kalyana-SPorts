package com.gramakalyana.sports.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.CricketScore
import com.gramakalyana.sports.models.KabaddiScore
import com.gramakalyana.sports.models.VolleyballScore
import com.gramakalyana.sports.ui.theme.*

@Composable
fun CricketScoreboard(
    team1Name: String,
    team2Name: String,
    team1Score: CricketScore,
    team2Score: CricketScore,
    isLive: Boolean = false,
    currentOver: Int = 0,
    currentBall: Int = 0,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition()
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(2.dp, ScoreboardBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(
            containerColor = ScoreboardBg
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 12.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Live Indicator
            if (isLive) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(LiveRed, RoundedCornerShape(4.dp))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LIVE",
                        style = ScoreboardTypography.LiveIndicator,
                        color = LiveRed
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
            
            // Teams and Scores
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Team 1
                TeamScoreColumn(
                    teamName = team1Name,
                    score = "${team1Score.totalRuns}/${team1Score.totalWickets}",
                    overs = String.format("%.1f", team1Score.totalOvers),
                    modifier = Modifier.weight(1f)
                )
                
                // VS
                Text(
                    text = "VS",
                    style = ScoreboardTypography.SmallScore,
                    color = White60,
                    fontWeight = FontWeight.Bold
                )
                
                // Team 2
                TeamScoreColumn(
                    teamName = team2Name,
                    score = "${team2Score.totalRuns}/${team2Score.totalWickets}",
                    overs = String.format("%.1f", team2Score.totalOvers),
                    modifier = Modifier.weight(1f)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Match Progress
            if (isLive) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Over: $currentOver.$currentBall",
                        style = MaterialTheme.typography.bodyMedium,
                        color = White80
                    )
                    
                    Text(
                        text = "CRR: ${String.format("%.2f", team1Score.runRate)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = NeonOrange
                    )
                }
            }
        }
    }
}

@Composable
fun KabaddiScoreboard(
    team1Name: String,
    team2Name: String,
    team1Score: KabaddiScore,
    team2Score: KabaddiScore,
    isLive: Boolean = false,
    currentRaidTime: Int = 0,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(2.dp, ScoreboardBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(
            containerColor = ScoreboardBg
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 12.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Live Indicator
            if (isLive) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(LiveRed, RoundedCornerShape(4.dp))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LIVE",
                        style = ScoreboardTypography.LiveIndicator,
                        color = LiveRed
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
            
            // Teams and Scores
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Team 1
                KabaddiTeamScoreColumn(
                    teamName = team1Name,
                    totalPoints = team1Score.totalPoints,
                    raidPoints = team1Score.raidPoints,
                    tacklePoints = team1Score.tacklePoints,
                    playersOnCourt = 7, // This would come from live data
                    modifier = Modifier.weight(1f)
                )
                
                // VS
                Text(
                    text = "VS",
                    style = ScoreboardTypography.SmallScore,
                    color = White60,
                    fontWeight = FontWeight.Bold
                )
                
                // Team 2
                KabaddiTeamScoreColumn(
                    teamName = team2Name,
                    totalPoints = team2Score.totalPoints,
                    raidPoints = team2Score.raidPoints,
                    tacklePoints = team2Score.tacklePoints,
                    playersOnCourt = 7, // This would come from live data
                    modifier = Modifier.weight(1f)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Match Progress
            if (isLive) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Raid Time: ${currentRaidTime}s",
                        style = MaterialTheme.typography.bodyMedium,
                        color = White80
                    )
                    
                    Text(
                        text = "Total Time: 40min",
                        style = MaterialTheme.typography.bodyMedium,
                        color = NeonOrange
                    )
                }
            }
        }
    }
}

@Composable
fun VolleyballScoreboard(
    team1Name: String,
    team2Name: String,
    team1Score: VolleyballScore,
    team2Score: VolleyballScore,
    isLive: Boolean = false,
    currentSet: Int = 1,
    servingTeam: String = "",
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(2.dp, ScoreboardBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(
            containerColor = ScoreboardBg
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 12.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Live Indicator
            if (isLive) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(LiveRed, RoundedCornerShape(4.dp))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LIVE",
                        style = ScoreboardTypography.LiveIndicator,
                        color = LiveRed
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
            
            // Teams and Scores
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Team 1
                VolleyballTeamScoreColumn(
                    teamName = team1Name,
                    currentSetPoints = team1Score.currentSetPoints,
                    setsWon = team1Score.setsWon,
                    sets = team1Score.sets,
                    isServing = servingTeam == team1Name,
                    modifier = Modifier.weight(1f)
                )
                
                // VS
                Text(
                    text = "VS",
                    style = ScoreboardTypography.SmallScore,
                    color = White60,
                    fontWeight = FontWeight.Bold
                )
                
                // Team 2
                VolleyballTeamScoreColumn(
                    teamName = team2Name,
                    currentSetPoints = team2Score.currentSetPoints,
                    setsWon = team2Score.setsWon,
                    sets = team2Score.sets,
                    isServing = servingTeam == team2Name,
                    modifier = Modifier.weight(1f)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Match Progress
            if (isLive) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Set $currentSet",
                        style = MaterialTheme.typography.bodyMedium,
                        color = White80
                    )
                    
                    Text(
                        text = "First to 3 sets",
                        style = MaterialTheme.typography.bodyMedium,
                        color = NeonOrange
                    )
                }
            }
        }
    }
}

@Composable
fun TeamScoreColumn(
    teamName: String,
    score: String,
    overs: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = teamName,
            style = ScoreboardTypography.TeamName,
            color = White,
            textAlign = TextAlign.Center,
            maxLines = 2
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = score,
            style = ScoreboardTypography.LargeScore,
            color = NeonOrange,
            textAlign = TextAlign.Center
        )
        
        Text(
            text = "($overs)",
            style = ScoreboardTypography.SmallScore,
            color = White80,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun KabaddiTeamScoreColumn(
    teamName: String,
    totalPoints: Int,
    raidPoints: Int,
    tacklePoints: Int,
    playersOnCourt: Int,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = teamName,
            style = ScoreboardTypography.TeamName,
            color = White,
            textAlign = TextAlign.Center,
            maxLines = 2
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = totalPoints.toString(),
            style = ScoreboardTypography.LargeScore,
            color = NeonOrange,
            textAlign = TextAlign.Center
        )
        
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "R: $raidPoints",
                style = ScoreboardTypography.SmallScore,
                color = White80
            )
            
            Text(
                text = "T: $tacklePoints",
                style = ScoreboardTypography.SmallScore,
                color = White80
            )
        }
        
        Text(
            text = "Players: $playersOnCourt",
            style = MaterialTheme.typography.bodySmall,
            color = White60
        )
    }
}

@Composable
fun VolleyballTeamScoreColumn(
    teamName: String,
    currentSetPoints: Int,
    setsWon: Int,
    sets: List<Int>,
    isServing: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isServing) {
                Icon(
                    imageVector = Icons.Default.SportsVolleyball,
                    contentDescription = "Serving",
                    tint = NeonGreen,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
            }
            
            Text(
                text = teamName,
                style = ScoreboardTypography.TeamName,
                color = White,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = currentSetPoints.toString(),
            style = ScoreboardTypography.LargeScore,
            color = NeonOrange,
            textAlign = TextAlign.Center
        )
        
        Text(
            text = "Sets: $setsWon",
            style = ScoreboardTypography.SmallScore,
            color = White80,
            textAlign = TextAlign.Center
        )
        
        // Display set scores
        if (sets.isNotEmpty()) {
            Text(
                text = sets.joinToString("-"),
                style = MaterialTheme.typography.bodySmall,
                color = White60,
                textAlign = TextAlign.Center
            )
        }
    }
}
