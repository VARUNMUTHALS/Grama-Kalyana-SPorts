package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.R
import com.gramakalyana.sports.ui.theme.*
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForgotPasswordScreen(
    onBack: () -> Unit,
    onResetSuccess: () -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(40000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Form states
    var email by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf(false) }
    
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Background effect
        ForgotPasswordBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = glowPulse
        )
        
        // Main content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 32.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .background(MatteBlackLight, RoundedCornerShape(12.dp))
                        .size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = NeonOrange
                    )
                }
                
                Spacer(modifier = Modifier.weight(1f))
                
                Text(
                    text = "Reset Password",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        color = White
                    )
                )
                
                Spacer(modifier = Modifier.weight(1f))
                
                Spacer(modifier = Modifier.width(48.dp))
            }
            
            Spacer(modifier = Modifier.height(40.dp))
            
            // Icon and message
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 32.dp)
            ) {
                Box(
                    modifier = Modifier.scale(1f + glowPulse * 0.1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.LockReset,
                        contentDescription = "Reset Password",
                        tint = NeonOrange,
                        modifier = Modifier.size(80.dp)
                    )
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Text(
                    text = "Forgot Your Password?",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange,
                        textAlign = TextAlign.Center
                    )
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Enter your email address and we'll send you a link to reset your password",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = White80,
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
            
            if (!isSuccess) {
                // Email field
                PremiumTextField(
                    value = email,
                    onValueChange = { 
                        email = it
                        errorMessage = null
                    },
                    label = "Email Address",
                    placeholder = "Enter your registered email",
                    leadingIcon = Icons.Default.Email,
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Done,
                    onImeAction = {
                        focusManager.clearFocus()
                        handlePasswordReset()
                    },
                    errorMessage = if (email.isNotEmpty() && !email.isValidEmail()) 
                        "Please enter a valid email address" else null
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Error message
                errorMessage?.let {
                    Text(
                        text = it,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NeonRed
                        ),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                }
                
                // Reset button
                PremiumGradientButton(
                    text = "SEND RESET LINK",
                    onClick = { handlePasswordReset() },
                    isLoading = isLoading,
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(32.dp))
                
                // Back to login
                Row(
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Remember your password? ",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = White60
                        )
                    )
                    
                    TextButton(
                        onClick = onBack,
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(
                            text = "Sign In",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = NeonOrange,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            } else {
                // Success state
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(vertical = 40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = NeonGreen,
                        modifier = Modifier.size(80.dp)
                    )
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    Text(
                        text = "Reset Link Sent!",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            color = NeonGreen,
                            textAlign = TextAlign.Center
                        )
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "We've sent a password reset link to\n$email",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            color = White80,
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    
                    Spacer(modifier = Modifier.height(32.dp))
                    
                    PremiumGradientButton(
                        text = "BACK TO LOGIN",
                        onClick = onBack,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(40.dp))
            
            // Help section
            HelpSection()
        }
    }
    
    // Handle password reset
    suspend fun handlePasswordReset() {
        if (email.isValidEmail()) {
            isLoading = true
            errorMessage = null
            
            try {
                // TODO: Implement Firebase password reset
                delay(2000) // Simulate API call
                isSuccess = true
            } catch (e: Exception) {
                errorMessage = "Failed to send reset email. Please try again."
            } finally {
                isLoading = false
            }
        } else {
            errorMessage = "Please enter a valid email address"
        }
    }
    
    LaunchedEffect(key1 = isSuccess) {
        if (isSuccess) {
            delay(3000)
            onResetSuccess()
        }
    }
}

@Composable
fun ForgotPasswordBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        // Subtle floodlight effect
        val positions = listOf(
            Offset(0f, canvasHeight * 0.2f),
            Offset(canvasWidth, canvasHeight * 0.2f),
            Offset(0f, canvasHeight * 0.8f),
            Offset(canvasWidth, canvasHeight * 0.8f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.5f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.15f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center subtle glow
        val centerGradient = androidx.compose.ui.graphics.RadialGradientShader(
            center = Offset(centerX, centerY),
            radius = min(canvasWidth, canvasHeight) * 0.3f,
            colors = listOf(
                NeonOrange.copy(alpha = glowAlpha * 0.1f),
                Color.Transparent
            ),
            colorStops = listOf(0f, 1f)
        )
        
        drawRect(
            brush = ShaderBrush(centerGradient),
            size = size
        )
    }
}

@Composable
fun HelpSection() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Need Help?",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = White
                )
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            HelpItem(
                icon = Icons.Default.Email,
                text = "support@gramakalyana.com",
                label = "Email Support"
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            HelpItem(
                icon = Icons.Default.Phone,
                text = "+91-XXXXXXXXXX",
                label = "Phone Support"
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            HelpItem(
                icon = Icons.Default.Help,
                text = "FAQ & Help Center",
                label = "Self Service"
            )
        }
    }
}

@Composable
fun HelpItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    label: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = NeonOrange,
            modifier = Modifier.size(20.dp)
        )
        
        Spacer(modifier = Modifier.width(12.dp))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White,
                    fontWeight = FontWeight.Medium
                )
            )
            
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = White60
                )
            )
        }
    }
}
