package com.gramakalyana.sports.navigation

import androidx.navigation.NamedNavArgument
import androidx.navigation.NavType
import androidx.navigation.navArgument

object NavigationArgs {
    
    val tournamentIdArg: NamedNavArgument
        get() = navArgument(Destination.TOURNAMENT_ID_ARG) {
            type = NavType.StringType
            nullable = false
        }
    
    val teamIdArg: NamedNavArgument
        get() = navArgument(Destination.TEAM_ID_ARG) {
            type = NavType.StringType
            nullable = false
        }
    
    val playerIdArg: NamedNavArgument
        get() = navArgument(Destination.PLAYER_ID_ARG) {
            type = NavType.StringType
            nullable = false
        }
    
    val matchIdArg: NamedNavArgument
        get() = navArgument(Destination.MATCH_ID_ARG) {
            type = NavType.StringType
            nullable = false
        }
    
    val sportTypeArg: NamedNavArgument
        get() = navArgument(Destination.SPORT_TYPE_ARG) {
            type = NavType.StringType
            nullable = false
        }
    
    val optionalTournamentIdArg: NamedNavArgument
        get() = navArgument(Destination.TOURNAMENT_ID_ARG) {
            type = NavType.StringType
            nullable = true
            defaultValue = null
        }
    
    val optionalTeamIdArg: NamedNavArgument
        get() = navArgument(Destination.TEAM_ID_ARG) {
            type = NavType.StringType
            nullable = true
            defaultValue = null
        }
    
    val optionalPlayerIdArg: NamedNavArgument
        get() = navArgument(Destination.PLAYER_ID_ARG) {
            type = NavType.StringType
            nullable = true
            defaultValue = null
        }
    
    val optionalMatchIdArg: NamedNavArgument
        get() = navArgument(Destination.MATCH_ID_ARG) {
            type = NavType.StringType
            nullable = true
            defaultValue = null
        }
}
