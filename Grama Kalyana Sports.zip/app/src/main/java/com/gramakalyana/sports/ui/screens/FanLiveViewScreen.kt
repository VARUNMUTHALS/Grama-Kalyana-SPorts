package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.R
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FanLiveViewScreen(
    matchId: String,
    onBack: () -> Unit,
    onShare: () -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val liveGlow by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(90000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val scorePulse by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val viewerCount by infiniteTransition.animateInt(
        initialValue = 1247,
        targetValue = 1253,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Match data (sample)
    val match = remember {
        Match(
            id = matchId,
            tournamentId = "tournament_001",
            teamAName = "Royal Warriors",
            teamBName = "Thunder Strikers",
            sportType = SportType.CRICKET,
            venue = "Grama Kalyana Stadium",
            scheduledDate = System.currentTimeMillis(),
            status = MatchStatus.LIVE,
            cricketScore = CricketScore(
                teamARuns = 178,
                teamAWickets = 5,
                teamAOvers = 19.2,
                teamBRuns = 145,
                teamBWickets = 8,
                teamBOvers = 18.4
            )
        )
    }
    
    val scrollState = rememberScrollState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Fan view background
        FanViewBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = liveGlow
        )
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
        ) {
            // Header with live indicators
            FanViewHeader(
                onBack = onBack,
                onShare = onShare,
                match = match,
                viewerCount = viewerCount,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Main scoreboard
            FanScoreboard(
                match = match,
                scorePulse = scorePulse,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Match progress
            MatchProgressSection(
                match = match,
                liveGlow = liveGlow
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Live commentary feed
            LiveCommentarySection()
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Match statistics
            FanMatchStatistics(
                match = match
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Player performances
            PlayerPerformancesSection(
                match = match
            )
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun FanViewBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        // Enhanced stadium floodlight effect for fan view
        val floodlightPositions = listOf(
            Offset(0f, 0f),
            Offset(canvasWidth, 0f),
            Offset(0f, canvasHeight),
            Offset(canvasWidth, canvasHeight),
            Offset(centerX, 0f),
            Offset(centerX, canvasHeight)
        )
        
        floodlightPositions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.9f,
                colors = listOf(
                    LiveRed.copy(alpha = glowAlpha * 0.4f),
                    NeonOrange.copy(alpha = glowAlpha * 0.3f),
                    NeonGreen.copy(alpha = glowAlpha * 0.2f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 0.3f, 0.6f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center broadcast spotlight
        val centerGradient = androidx.compose.ui.graphics.RadialGradientShader(
            center = Offset(centerX, centerY),
            radius = min(canvasWidth, canvasHeight) * 0.5f,
            colors = listOf(
                LiveRed.copy(alpha = glowAlpha * 0.2f),
                NeonOrange.copy(alpha = glowAlpha * 0.1f),
                Color.Transparent
            ),
            colorStops = listOf(0f, 0.5f, 1f)
        )
        
        drawRect(
            brush = ShaderBrush(centerGradient),
            size = size
        )
        
        // Dynamic broadcast lines
        drawBroadcastLines(centerX, centerY, min(canvasWidth, canvasHeight), glowAlpha)
    }
}

private fun DrawScope.drawBroadcastLines(
    centerX: Float,
    centerY: Float,
    canvasSize: Float,
    glowAlpha: Float
) {
    val numLines = 12
    for (i in 0 until numLines) {
        val angle = (i * 360f / numLines) * (PI / 180f)
        val startX = centerX + cos(angle).toFloat() * 60f
        val startY = centerY + sin(angle).toFloat() * 60f
        val endX = centerX + cos(angle).toFloat() * canvasSize * 0.45f
        val endY = centerY + sin(angle).toFloat() * canvasSize * 0.45f
        
        drawLine(
            color = NeonOrange.copy(alpha = glowAlpha * 0.15f),
            start = Offset(startX, startY),
            end = Offset(endX, endY),
            strokeWidth = 3f
        )
    }
    
    // Center broadcast circle
    drawCircle(
        color = LiveRed.copy(alpha = glowAlpha * 0.08f),
        radius = canvasSize * 0.35f,
        center = Offset(centerX, centerY)
    )
    
    // Inner circle
    drawCircle(
        color = NeonOrange.copy(alpha = glowAlpha * 0.05f),
        radius = canvasSize * 0.25f,
        center = Offset(centerX, centerY)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FanViewHeader(
    onBack: () -> Unit,
    onShare: () -> Unit,
    match: Match,
    viewerCount: Int,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val livePulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        // Live indicator with viewer count
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .background(
                    color = LiveRed.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(20.dp)
                )
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(LiveRed, RoundedCornerShape(5.dp))
                    .scale(livePulse)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = "LIVE",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Black,
                    color = LiveRed,
                    letterSpacing = 2.sp
                )
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            VerticalDivider(
                modifier = Modifier.height(20.dp),
                color = LiveRed.copy(alpha = 0.5f)
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Visibility,
                    contentDescription = "Viewers",
                    tint = LiveRed,
                    modifier = Modifier.size(16.dp)
                )
                
                Spacer(modifier = Modifier.width(4.dp))
                
                Text(
                    text = viewerCount.toString(),
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = LiveRed
                    )
                )
            }
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        IconButton(
            onClick = onShare,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = "Share",
                tint = NeonOrange
            )
        }
    }
}

@Composable
fun FanScoreboard(
    match: Match,
    scorePulse: Float,
    liveGlow: Float
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .border(
                width = 3.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        LiveRed.copy(alpha = liveGlow),
                        NeonOrange.copy(alpha = liveGlow),
                        NeonGreen.copy(alpha = liveGlow)
                    )
                ),
                shape = RoundedCornerShape(24.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 16.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            // Tournament and sport info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FanSportTypeBadge(
                    sportType = match.sportType,
                    isLive = match.status == MatchStatus.LIVE
                )
                
                Spacer(modifier = Modifier.width(16.dp))
                
                Text(
                    text = "• GRAMA KALYANA PREMIER LEAGUE •",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Black,
                        color = NeonOrange.copy(alpha = 0.8f),
                        letterSpacing = 2.sp
                    )
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Team scores
            when (match.sportType) {
                SportType.CRICKET -> FanCricketScoreboard(
                    match = match,
                    scorePulse = scorePulse
                )
                SportType.KABADDI -> FanKabaddiScoreboard(
                    match = match,
                    scorePulse = scorePulse
                )
                SportType.VOLLEYBALL -> FanVolleyballScoreboard(
                    match = match,
                    scorePulse = scorePulse
                )
            }
            
            Spacer(modifier = Modifier.height(20.dp))
            
            // Match venue
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = White60,
                    modifier = Modifier.size(16.dp)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = match.venue,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White80,
                        fontWeight = FontWeight.Medium
                    )
                )
            }
        }
    }
}

@Composable
fun FanSportTypeBadge(
    sportType: SportType,
    isLive: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition()
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val sportInfo = when (sportType) {
        SportType.CRICKET -> Triple("🏏", "CRICKET", CricketGreen)
        SportType.KABADDI -> Triple("🤼", "KABADDI", KabaddiRed)
        SportType.VOLLEYBALL -> Triple("🏐", "VOLLEYBALL", VolleyballBlue)
    }
    
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        sportInfo.third.copy(alpha = 0.3f),
                        sportInfo.third.copy(alpha = 0.1f)
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .scale(if (isLive) pulse else 1f)
    ) {
        Text(
            text = sportInfo.first,
            fontSize = 24.sp
        )
        
        Spacer(modifier = Modifier.width(8.dp))
        
        Text(
            text = sportInfo.second,
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.Black,
                color = sportInfo.third,
                letterSpacing = 1.sp
            )
        )
        
        if (isLive) {
            Spacer(modifier = Modifier.width(8.dp))
            
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(LiveRed, RoundedCornerShape(4.dp))
            )
        }
    }
}

@Composable
fun FanCricketScoreboard(
    match: Match,
    scorePulse: Float
) {
    val cricketScore = match.cricketScore ?: return
    
    Column {
        // Team A
        FanTeamScoreRow(
            teamName = match.teamAName,
            score = "${cricketScore.teamARuns}/${cricketScore.teamAWickets}",
            overs = "(${cricketScore.teamAOvers} ov)",
            isBatting = true,
            scorePulse = scorePulse,
            runRate = String.format("%.2f", cricketScore.teamARuns / cricketScore.teamAOvers)
        )
        
        Spacer(modifier = Modifier.height(20.dp))
        
        // VS indicator with animation
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                HorizontalDivider(
                    modifier = Modifier.width(40.dp),
                    color = NeonOrange.copy(alpha = 0.4f)
                )
                
                Text(
                    text = "VS",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = NeonOrange.copy(alpha = 0.8f),
                        letterSpacing = 6.sp,
                        fontFamily = FontFamily.SansSerif
                    )
                )
                
                HorizontalDivider(
                    modifier = Modifier.width(40.dp),
                    color = NeonOrange.copy(alpha = 0.4f)
                )
            }
        }
        
        Spacer(modifier = Modifier.height(20.dp))
        
        // Team B
        FanTeamScoreRow(
            teamName = match.teamBName,
            score = "${cricketScore.teamBRuns}/${cricketScore.teamBWickets}",
            overs = "(${cricketScore.teamBOvers} ov)",
            isBatting = false,
            scorePulse = 1f,
            runRate = String.format("%.2f", cricketScore.teamBRuns / cricketScore.teamBOvers)
        )
    }
}

@Composable
fun FanTeamScoreRow(
    teamName: String,
    score: String,
    overs: String,
    isBatting: Boolean,
    scorePulse: Float,
    runRate: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = teamName,
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Bold,
                color = if (isBatting) NeonOrange else White80
            ),
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        Row(
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = score,
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 56.sp,
                    fontWeight = FontWeight.Black,
                    color = if (isBatting) NeonOrange else White,
                    fontFamily = FontFamily.SansSerif
                ),
                modifier = Modifier.scale(if (isBatting) scorePulse else 1f)
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = overs,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = if (isBatting) NeonOrange.copy(alpha = 0.8f) else White60,
                        fontWeight = FontWeight.Medium
                    )
                )
                
                Text(
                    text = "RR: $runRate",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = if (isBatting) NeonGreen else White60,
                        fontWeight = FontWeight.Medium
                    )
                )
            }
        }
        
        if (isBatting) {
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(LiveRed, RoundedCornerShape(3.dp))
                )
                
                Spacer(modifier = Modifier.width(6.dp))
                
                Text(
                    text = "BATTING",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Black,
                        color = LiveRed,
                        letterSpacing = 2.sp
                    )
                )
            }
        }
    }
}

@Composable
fun FanKabaddiScoreboard(
    match: Match,
    scorePulse: Float
) {
    val kabaddiScore = match.kabaddiScore ?: return
    
    // Similar implementation for Kabaddi fan view
    Column {
        FanTeamScoreRow(
            teamName = match.teamAName,
            score = kabaddiScore.teamAPoints.toString(),
            overs = "",
            isBatting = true,
            scorePulse = scorePulse,
            runRate = ""
        )
        
        Spacer(modifier = Modifier.height(20.dp))
        
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "VS",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = NeonOrange.copy(alpha = 0.8f),
                    letterSpacing = 6.sp,
                    fontFamily = FontFamily.SansSerif
                )
            )
        }
        
        Spacer(modifier = Modifier.height(20.dp))
        
        FanTeamScoreRow(
            teamName = match.teamBName,
            score = kabaddiScore.teamBPoints.toString(),
            overs = "",
            isBatting = false,
            scorePulse = 1f,
            runRate = ""
        )
    }
}

@Composable
fun FanVolleyballScoreboard(
    match: Match,
    scorePulse: Float
) {
    val volleyballScore = match.volleyballScore ?: return
    
    // Similar implementation for Volleyball fan view
    Column {
        FanTeamScoreRow(
            teamName = match.teamAName,
            score = "${volleyballScore.teamASets} sets",
            overs = "Points: ${volleyballScore.teamAPoints}",
            isBatting = true,
            scorePulse = scorePulse,
            runRate = ""
        )
        
        Spacer(modifier = Modifier.height(20.dp))
        
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "VS",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = NeonOrange.copy(alpha = 0.8f),
                    letterSpacing = 6.sp,
                    fontFamily = FontFamily.SansSerif
                )
            )
        }
        
        Spacer(modifier = Modifier.height(20.dp))
        
        FanTeamScoreRow(
            teamName = match.teamBName,
            score = "${volleyballScore.teamBSets} sets",
            overs = "Points: ${volleyballScore.teamBPoints}",
            isBatting = false,
            scorePulse = 1f,
            runRate = ""
        )
    }
}

@Composable
fun MatchProgressSection(
    match: Match,
    liveGlow: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val progressPulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "MATCH PROGRESS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Progress bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .background(
                        color = White20,
                        shape = RoundedCornerShape(4.dp)
                    )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.75f) // 75% progress
                        .fillMaxHeight()
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    LiveRed,
                                    NeonOrange,
                                    NeonGreen
                                )
                            ),
                            shape = RoundedCornerShape(4.dp)
                        )
                        .scale(progressPulse)
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "OVERS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = White60,
                            letterSpacing = 1.sp
                        )
                    )
                    
                    Text(
                        text = match.cricketScore?.teamAOvers?.toString() ?: "0.0",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = NeonOrange,
                            fontFamily = FontFamily.SansSerif
                        )
                    )
                }
                
                VerticalDivider(
                    modifier = Modifier.height(40.dp),
                    color = White20
                )
                
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "STATUS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = White60,
                            letterSpacing = 1.sp
                        )
                    )
                    
                    Text(
                        text = match.status.getDisplayText(),
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = match.status.getDisplayColor()
                        )
                    )
                }
                
                VerticalDivider(
                    modifier = Modifier.height(40.dp),
                    color = White20
                )
                
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "TIME LEFT",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = White60,
                            letterSpacing = 1.sp
                        )
                    )
                    
                    Text(
                        text = "6.1 OV",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = NeonGreen,
                            fontFamily = FontFamily.SansSerif
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun LiveCommentarySection() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LIVE COMMENTARY",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange
                    )
                )
                
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(LiveRed, RoundedCornerShape(3.dp))
                    )
                    
                    Spacer(modifier = Modifier.width(6.dp))
                    
                    Text(
                        text = "AUTO-UPDATING",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = LiveRed,
                            letterSpacing = 1.sp
                        )
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Live commentary items
            FanCommentaryItem(
                over = "19.2",
                text = "SIX! Massive shot over deep mid-wicket! What a way to reach 180!",
                time = "Just now",
                isHighlight = true
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            FanCommentaryItem(
                over = "19.1",
                text = "Excellent yorker, just a single to long-on.",
                time = "1 min ago",
                isHighlight = false
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            FanCommentaryItem(
                over = "19.0",
                text = "WICKET! Bowled him! Great delivery to end the over.",
                time = "2 min ago",
                isHighlight = false
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            FanCommentaryItem(
                over = "18.5",
                text = "FOUR! Beautiful cover drive, races to the boundary.",
                time = "3 min ago",
                isHighlight = false
            )
        }
    }
}

@Composable
fun FanCommentaryItem(
    over: String,
    text: String,
    time: String,
    isHighlight: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = over,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Black,
                color = if (isHighlight) LiveRed else NeonOrange,
                fontFamily = FontFamily.SansSerif
            ),
            modifier = Modifier.width(40.dp)
        )
        
        Spacer(modifier = Modifier.width(12.dp))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = if (isHighlight) NeonOrange else White,
                    fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.Medium
                )
            )
            
            Text(
                text = time,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = White60
                )
            )
        }
    }
}

@Composable
fun FanMatchStatistics(
    match: Match
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "MATCH STATISTICS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Statistics grid
            when (match.sportType) {
                SportType.CRICKET -> CricketStatisticsGrid(match)
                SportType.KABADDI -> KabaddiStatisticsGrid(match)
                SportType.VOLLEYBALL -> VolleyballStatisticsGrid(match)
            }
        }
    }
}

@Composable
fun CricketStatisticsGrid(match: Match) {
    val cricketScore = match.cricketScore ?: return
    
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        FanStatRow(
            label = "Total Runs",
            teamAValue = cricketScore.teamARuns.toString(),
            teamBValue = cricketScore.teamBRuns.toString()
        )
        
        FanStatRow(
            label = "Wickets",
            teamAValue = cricketScore.teamAWickets.toString(),
            teamBValue = cricketScore.teamBWickets.toString()
        )
        
        FanStatRow(
            label = "Run Rate",
            teamAValue = String.format("%.2f", cricketScore.teamARuns / cricketScore.teamAOvers),
            teamBValue = String.format("%.2f", cricketScore.teamBRuns / cricketScore.teamBOvers)
        )
    }
}

@Composable
fun KabaddiStatisticsGrid(match: Match) {
    val kabaddiScore = match.kabaddiScore ?: return
    
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        FanStatRow(
            label = "Total Points",
            teamAValue = kabaddiScore.teamAPoints.toString(),
            teamBValue = kabaddiScore.teamBPoints.toString()
        )
        
        FanStatRow(
            label = "Successful Raids",
            teamAValue = kabaddiScore.teamASuccessfulRaids.toString(),
            teamBValue = kabaddiScore.teamBSuccessfulRaids.toString()
        )
        
        FanStatRow(
            label = "Successful Tackles",
            teamAValue = kabaddiScore.teamASuccessfulTackles.toString(),
            teamBValue = kabaddiScore.teamBSuccessfulTackles.toString()
        )
    }
}

@Composable
fun VolleyballStatisticsGrid(match: Match) {
    val volleyballScore = match.volleyballScore ?: return
    
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        FanStatRow(
            label = "Sets Won",
            teamAValue = volleyballScore.teamASets.toString(),
            teamBValue = volleyballScore.teamBSets.toString()
        )
        
        FanStatRow(
            label = "Total Points",
            teamAValue = volleyballScore.teamAPoints.toString(),
            teamBValue = volleyballScore.teamBPoints.toString()
        )
    }
}

@Composable
fun FanStatRow(
    label: String,
    teamAValue: String,
    teamBValue: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = White60,
                fontWeight = FontWeight.Medium
            ),
            modifier = Modifier.weight(1f)
        )
        
        Text(
            text = teamAValue,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = NeonOrange
            ),
            modifier = Modifier.width(60.dp),
            textAlign = TextAlign.Center
        )
        
        Text(
            text = teamBValue,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = White
            ),
            modifier = Modifier.width(60.dp),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun PlayerPerformancesSection(
    match: Match
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TOP PERFORMERS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange
                    )
                )
                
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = NeonOrange,
                    modifier = Modifier.size(24.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Top performers
            FanPlayerCard(
                playerName = "Rahul Sharma",
                teamName = match.teamAName,
                stats = "78 runs (45 balls)",
                role = "Top Scorer",
                isMVP = true
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            FanPlayerCard(
                playerName = "Vikram Singh",
                teamName = match.teamBName,
                stats = "3 wickets (24 runs)",
                role = "Best Bowler",
                isMVP = false
            )
        }
    }
}

@Composable
fun FanPlayerCard(
    playerName: String,
    teamName: String,
    stats: String,
    role: String,
    isMVP: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = if (isMVP) NeonOrange.copy(alpha = 0.1f) else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .background(
                    color = if (isMVP) NeonOrange else White20,
                    shape = RoundedCornerShape(24.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = playerName.getInitials(),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = if (isMVP) White else White80
                )
            )
        }
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = playerName,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isMVP) NeonOrange else White
                    )
                )
                
                if (isMVP) {
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Icon(
                        imageVector = Icons.Default.Stars,
                        contentDescription = "MVP",
                        tint = NeonOrange,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            
            Text(
                text = teamName,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = White60
                )
            )
            
            Text(
                text = role,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = NeonOrange.copy(alpha = 0.8f),
                    fontWeight = FontWeight.Medium
                )
            )
        }
        
        Text(
            text = stats,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = White80
            )
        )
    }
}
