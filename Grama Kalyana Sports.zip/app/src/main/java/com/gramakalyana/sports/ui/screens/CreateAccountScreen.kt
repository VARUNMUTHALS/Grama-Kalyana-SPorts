package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.R
import com.gramakalyana.sports.ui.theme.*
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateAccountScreen(
    onBack: () -> Unit,
    onAccountCreated: () -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(50000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Form states
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var isConfirmPasswordVisible by remember { mutableStateOf(false) }
    var agreeToTerms by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Background effect
        CreateAccountBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = glowPulse
        )
        
        // Main content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 32.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .background(MatteBlackLight, RoundedCornerShape(12.dp))
                        .size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = NeonOrange
                    )
                }
                
                Spacer(modifier = Modifier.weight(1f))
                
                Text(
                    text = "Create Account",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        color = White
                    )
                )
                
                Spacer(modifier = Modifier.weight(1f))
                
                Spacer(modifier = Modifier.width(48.dp))
            }
            
            Spacer(modifier = Modifier.height(40.dp))
            
            // Logo and welcome
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 24.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_premium_sports),
                    contentDescription = "Sports App Logo",
                    modifier = Modifier
                        .size(80.dp)
                        .scale(1f + glowPulse * 0.1f)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "Join Grama Kalyana Sports",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange,
                        textAlign = TextAlign.Center
                    )
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Create your account to manage tournaments and track scores",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = White80,
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Registration form
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Name field
                PremiumTextField(
                    value = name,
                    onValueChange = { 
                        name = it
                        errorMessage = null
                    },
                    label = "Full Name",
                    placeholder = "Enter your full name",
                    leadingIcon = Icons.Default.Person,
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Next,
                    onImeAction = {
                        focusManager.moveFocus(FocusDirection.Down)
                    },
                    errorMessage = if (name.isNotEmpty() && name.length < 3)
                        "Name must be at least 3 characters" else null
                )
                
                // Email field
                PremiumTextField(
                    value = email,
                    onValueChange = { 
                        email = it
                        errorMessage = null
                    },
                    label = "Email Address",
                    placeholder = "Enter your email",
                    leadingIcon = Icons.Default.Email,
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next,
                    onImeAction = {
                        focusManager.moveFocus(FocusDirection.Down)
                    },
                    errorMessage = if (email.isNotEmpty() && !email.isValidEmail()) 
                        "Please enter a valid email address" else null
                )
                
                // Password field
                PremiumTextField(
                    value = password,
                    onValueChange = { 
                        password = it
                        errorMessage = null
                    },
                    label = "Password",
                    placeholder = "Create a strong password",
                    leadingIcon = Icons.Default.Lock,
                    trailingIcon = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                    isPassword = !isPasswordVisible,
                    onTrailingIconClick = { isPasswordVisible = !isPasswordVisible },
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Next,
                    onImeAction = {
                        focusManager.moveFocus(FocusDirection.Down)
                    },
                    errorMessage = if (password.isNotEmpty() && password.length < 6)
                        "Password must be at least 6 characters" else null
                )
                
                // Confirm password field
                PremiumTextField(
                    value = confirmPassword,
                    onValueChange = { 
                        confirmPassword = it
                        errorMessage = null
                    },
                    label = "Confirm Password",
                    placeholder = "Re-enter your password",
                    leadingIcon = Icons.Default.Lock,
                    trailingIcon = if (isConfirmPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                    isPassword = !isConfirmPasswordVisible,
                    onTrailingIconClick = { isConfirmPasswordVisible = !isConfirmPasswordVisible },
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done,
                    onImeAction = {
                        focusManager.clearFocus()
                        handleAccountCreation()
                    },
                    errorMessage = if (confirmPassword.isNotEmpty() && confirmPassword != password)
                        "Passwords do not match" else null
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Terms and conditions
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = agreeToTerms,
                    onCheckedChange = { agreeToTerms = it },
                    colors = CheckboxDefaults.colors(
                        checkedColor = NeonOrange,
                        uncheckedColor = White40
                    )
                )
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "I agree to the ",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = White80
                        )
                    )
                    
                    Row {
                        TextButton(
                            onClick = { /* Open terms */ },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(
                                text = "Terms of Service",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = NeonOrange,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                        
                        Text(
                            text = " and ",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = White80
                            )
                        )
                        
                        TextButton(
                            onClick = { /* Open privacy */ },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(
                                text = "Privacy Policy",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = NeonOrange,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Error message
            errorMessage?.let {
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = NeonRed
                    ),
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }
            
            // Create account button
            PremiumGradientButton(
                text = "CREATE ACCOUNT",
                onClick = { handleAccountCreation() },
                isLoading = isLoading,
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Already have account
            Row(
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Already have an account? ",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White60
                    )
                )
                
                TextButton(
                    onClick = onBack,
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = "Sign In",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = NeonOrange,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Premium features
            PremiumFeaturesCard()
        }
    }
    
    // Handle account creation
    suspend fun handleAccountCreation() {
        if (validateForm()) {
            isLoading = true
            errorMessage = null
            
            try {
                // TODO: Implement Firebase account creation
                delay(2000) // Simulate API call
                onAccountCreated()
            } catch (e: Exception) {
                errorMessage = "Failed to create account. Please try again."
            } finally {
                isLoading = false
            }
        }
    }
    
    fun validateForm(): Boolean {
        return when {
            name.length < 3 -> {
                errorMessage = "Name must be at least 3 characters"
                false
            }
            !email.isValidEmail() -> {
                errorMessage = "Please enter a valid email address"
                false
            }
            password.length < 6 -> {
                errorMessage = "Password must be at least 6 characters"
                false
            }
            password != confirmPassword -> {
                errorMessage = "Passwords do not match"
                false
            }
            !agreeToTerms -> {
                errorMessage = "Please agree to terms and conditions"
                false
            }
            else -> true
        }
    }
}

@Composable
fun CreateAccountBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle floodlight effect
        val positions = listOf(
            Offset(canvasWidth * 0.2f, 0f),
            Offset(canvasWidth * 0.8f, 0f),
            Offset(0f, canvasHeight * 0.7f),
            Offset(canvasWidth, canvasHeight * 0.7f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.4f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    NeonGreen.copy(alpha = glowAlpha * 0.05f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 0.5f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center subtle pattern
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        drawCircle(
            color = NeonOrange.copy(alpha = glowAlpha * 0.03f),
            radius = min(canvasWidth, canvasHeight) * 0.3f,
            center = Offset(centerX, centerY)
        )
    }
}

@Composable
fun PremiumFeaturesCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Premium Features",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            FeatureItem(
                icon = Icons.Default.EmojiEvents,
                title = "Tournament Management",
                description = "Create and manage professional tournaments"
            )
            
            FeatureItem(
                icon = Icons.Default.LiveTv,
                title = "Live Scoring",
                description = "Real-time score updates and broadcasting"
            )
            
            FeatureItem(
                icon = Icons.Default.BarChart,
                title = "Player Statistics",
                description = "Track career stats and achievements"
            )
        }
    }
}

@Composable
fun FeatureItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = NeonOrange,
            modifier = Modifier.size(24.dp)
        )
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Medium,
                    color = White
                )
            )
            
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = White60
                )
            )
        }
    }
}
