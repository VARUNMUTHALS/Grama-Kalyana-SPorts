package com.gramakalyana.sports.firebase.tournaments

import com.gramakalyana.sports.firebase.FirebaseManager
import com.gramakalyana.sports.models.Match
import com.gramakalyana.sports.models.Team
import com.gramakalyana.sports.models.Tournament
import com.gramakalyana.sports.models.TournamentStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.tasks.await

class TournamentRepository private constructor() {
    suspend fun createTournament(tournament: Tournament): Result<String> = runCatching {
        val id = tournament.id.ifBlank {
            FirebaseManager.tournamentsRef.push().key ?: error("Unable to allocate tournament id")
        }
        FirebaseManager.tournamentsRef.child(id).setValue(tournament.copy(id = id)).await()
        id
    }

    suspend fun getTournament(tournamentId: String): Result<Tournament?> = runCatching {
        FirebaseManager.tournamentsRef.child(tournamentId).get().await().getValue(Tournament::class.java)
    }

    suspend fun getAllTournaments(): Result<List<Tournament>> = runCatching {
        FirebaseManager.tournamentsRef.get().await().children.mapNotNull { it.getValue(Tournament::class.java) }
    }

    suspend fun getTournamentsByStatus(status: TournamentStatus): Result<List<Tournament>> = runCatching {
        getAllTournaments().getOrThrow().filter { it.status == status }
    }

    suspend fun updateTournament(tournament: Tournament): Result<Unit> = runCatching {
        require(tournament.id.isNotBlank()) { "Tournament id is required" }
        FirebaseManager.tournamentsRef.child(tournament.id).setValue(tournament).await()
    }

    suspend fun deleteTournament(tournamentId: String): Result<Unit> = runCatching {
        FirebaseManager.tournamentsRef.child(tournamentId).removeValue().await()
    }

    suspend fun addTeamToTournament(tournamentId: String, team: Team): Result<Unit> = runCatching {
        val tournament = getTournament(tournamentId).getOrThrow() ?: error("Tournament not found")
        FirebaseManager.teamsRef.child(team.id).setValue(team).await()
        val updatedIds = (tournament.teamIds + team.id).distinct()
        updateTournament(tournament.copy(teamIds = updatedIds, totalTeams = updatedIds.size)).getOrThrow()
    }

    suspend fun removeTeamFromTournament(tournamentId: String, teamId: String): Result<Unit> = runCatching {
        val tournament = getTournament(tournamentId).getOrThrow() ?: error("Tournament not found")
        val updatedIds = tournament.teamIds.filterNot { it == teamId }
        updateTournament(tournament.copy(teamIds = updatedIds, totalTeams = updatedIds.size)).getOrThrow()
    }

    suspend fun getTournamentTeams(tournamentId: String): Result<List<Team>> = runCatching {
        val tournament = getTournament(tournamentId).getOrThrow() ?: return@runCatching emptyList()
        tournament.teamIds.mapNotNull { id ->
            FirebaseManager.teamsRef.child(id).get().await().getValue(Team::class.java)
        }
    }

    suspend fun generateFixtures(tournamentId: String): Result<List<Match>> = runCatching {
        val tournament = getTournament(tournamentId).getOrThrow() ?: error("Tournament not found")
        val teams = getTournamentTeams(tournamentId).getOrThrow()
        val fixtures = teams.chunked(2).mapIndexedNotNull { index, pair ->
            if (pair.size < 2) return@mapIndexedNotNull null
            Match(
                id = "${tournament.id}_match_${index + 1}",
                tournamentId = tournament.id,
                team1Id = pair[0].id,
                team2Id = pair[1].id,
                team1Name = pair[0].name,
                team2Name = pair[1].name,
                sportType = tournament.sportType,
                venue = tournament.venue
            )
        }
        fixtures.forEach { match ->
            FirebaseManager.matchesRef.child(match.id).setValue(match).await()
        }
        val matchIds = fixtures.map { it.id }
        updateTournament(tournament.copy(matchIds = matchIds, totalMatches = matchIds.size)).getOrThrow()
        fixtures
    }

    suspend fun getTournamentMatches(tournamentId: String): Result<List<Match>> = runCatching {
        val tournament = getTournament(tournamentId).getOrThrow() ?: return@runCatching emptyList()
        tournament.matchIds.mapNotNull { id ->
            FirebaseManager.matchesRef.child(id).get().await().getValue(Match::class.java)
        }
    }

    fun getTournamentUpdates(tournamentId: String): Flow<Tournament?> = emptyFlow()

    fun getAllTournamentUpdates(): Flow<List<Tournament>> = emptyFlow()

    suspend fun updateTournamentStatus(tournamentId: String, status: TournamentStatus): Result<Unit> = runCatching {
        val tournament = getTournament(tournamentId).getOrThrow() ?: error("Tournament not found")
        updateTournament(tournament.copy(status = status)).getOrThrow()
    }

    companion object {
        @Volatile
        private var INSTANCE: TournamentRepository? = null

        fun getInstance(): TournamentRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: TournamentRepository().also { INSTANCE = it }
            }
        }
    }
}
