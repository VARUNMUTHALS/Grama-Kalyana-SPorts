package com.gramakalyana.sports.firebase.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.gramakalyana.sports.MainActivity
import com.gramakalyana.sports.R
import com.gramakalyana.sports.firebase.FirebaseManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Firebase Cloud Messaging Service
 * Handles push notifications for real-time match updates and tournament announcements
 */
class NotificationService : FirebaseMessagingService() {
    
    private val notificationScope = CoroutineScope(Dispatchers.IO)
    
    companion object {
        const val CHANNEL_ID = "gramakalyana_sports"
        const val CHANNEL_NAME = "Grama Kalyana Sports"
        const val CHANNEL_DESCRIPTION = "Sports match updates and notifications"
        
        // Notification types
        const val TYPE_MATCH_STARTED = "match_started"
        const val TYPE_MATCH_COMPLETED = "match_completed"
        const val TYPE_SCORE_UPDATE = "score_update"
        const val TYPE_WICKET_FALLEN = "wicket_fallen"
        const val TYPE_BOUNDARY_HIT = "boundary_hit"
        const val TYPE_SIX_HIT = "six_hit"
        const val TYPE_RAID_COMPLETED = "raid_completed"
        const val TYPE_TACKLE_COMPLETED = "tackle_completed"
        const val TYPE_ALL_OUT = "all_out"
        const val TYPE_SET_COMPLETED = "set_completed"
        const val TYPE_MATCH_CANCELLED = "match_cancelled"
        const val TYPE_TOURNAMENT_STARTED = "tournament_started"
        const val TYPE_TOURNAMENT_COMPLETED = "tournament_completed"
        const val TYPE_NEW_TOURNAMENT = "new_tournament"
        const val TYPE_TEAM_UPDATE = "team_update"
        const val TYPE_PLAYER_UPDATE = "player_update"
        const val TYPE_SYSTEM = "system"
    }
    
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        
        // Save FCM token to Firebase
        notificationScope.launch {
            try {
                saveFcmToken(token)
            } catch (e: Exception) {
                // Handle token save error
                e.printStackTrace()
            }
        }
    }
    
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        
        // Handle incoming message
        notificationScope.launch {
            try {
                handleMessage(remoteMessage)
            } catch (e: Exception) {
                // Handle message processing error
                e.printStackTrace()
            }
        }
    }
    
    override fun onMessageSent(messageId: String) {
        super.onMessageSent(messageId)
        // Handle message sent confirmation
    }
    
    override fun onDeletedMessages() {
        super.onDeletedMessages()
        // Handle deleted messages from server
    }
    
    /**
     * Save FCM token to Firebase Realtime Database
     */
    private suspend fun saveFcmToken(token: String) {
        withContext(Dispatchers.IO) {
            try {
                val currentUserId = FirebaseManager.getCurrentUserId()
                currentUserId?.let { userId ->
                    FirebaseManager.usersRef.child(userId).child("fcmToken").setValue(token)
                }
            } catch (e: Exception) {
                throw NotificationException.TokenSaveFailed("Failed to save FCM token: ${e.message}", e)
            }
        }
    }
    
    /**
     * Handle incoming FCM message
     */
    private suspend fun handleMessage(remoteMessage: RemoteMessage) {
        withContext(Dispatchers.Main) {
            try {
                val notificationType = remoteMessage.data["type"] ?: TYPE_SYSTEM
                val title = remoteMessage.data["title"] ?: remoteMessage.notification?.title ?: "Grama Kalyana Sports"
                val message = remoteMessage.data["message"] ?: remoteMessage.notification?.body ?: "New notification"
                val matchId = remoteMessage.data["matchId"]
                val tournamentId = remoteMessage.data["tournamentId"]
                
                // Save notification to database
                saveNotificationToDatabase(notificationType, title, message, matchId, tournamentId)
                
                // Show notification
                showNotification(notificationType, title, message, matchId, tournamentId)
                
            } catch (e: Exception) {
                throw NotificationException.MessageProcessingFailed("Failed to process message: ${e.message}", e)
            }
        }
    }
    
    /**
     * Save notification to Firebase Realtime Database
     */
    private suspend fun saveNotificationToDatabase(
        type: String,
        title: String,
        message: String,
        matchId: String?,
        tournamentId: String?
    ) {
        withContext(Dispatchers.IO) {
            try {
                val currentUserId = FirebaseManager.getCurrentUserId()
                currentUserId?.let { userId ->
                    val notificationId = FirebaseManager.notificationsRef.child(userId).push().key
                    notificationId?.let { id ->
                        val notification = mapOf(
                            "id" to id,
                            "title" to title,
                            "message" to message,
                            "type" to type,
                            "isRead" to false,
                            "createdAt" to System.currentTimeMillis(),
                            "expiresAt" to (System.currentTimeMillis() + 86400000 * 7), // 7 days
                            "matchId" to matchId,
                            "tournamentId" to tournamentId
                        )
                        
                        FirebaseManager.notificationsRef.child(userId).child(id).setValue(notification)
                    }
                }
            } catch (e: Exception) {
                // Don't throw exception for notification save failure
                e.printStackTrace()
            }
        }
    }
    
    /**
     * Show notification to user
     */
    private fun showNotification(
        type: String,
        title: String,
        message: String,
        matchId: String?,
        tournamentId: String?
    ) {
        try {
            // Create notification channel (required for Android 8.0+)
            createNotificationChannel()
            
            // Create intent for notification click
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("notification_type", type)
                putExtra("match_id", matchId)
                putExtra("tournament_id", tournamentId)
            }
            
            val pendingIntent = PendingIntent.getActivity(
                this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            
            // Get notification icon and priority based on type
            val (icon, priority) = getNotificationConfig(type)
            
            // Build notification
            val notificationBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(icon)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(priority)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            
            // Add sound and vibration for important notifications
            if (isImportantNotification(type)) {
                notificationBuilder
                    .setDefaults(NotificationCompat.DEFAULT_ALL)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
            }
            
            // Show notification
            val notificationManager = NotificationManagerCompat.from(this)
            notificationManager.notify(System.currentTimeMillis().toInt(), notificationBuilder.build())
            
        } catch (e: Exception) {
            // Handle notification display error
            e.printStackTrace()
        }
    }
    
    /**
     * Create notification channel for Android 8.0+
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = CHANNEL_DESCRIPTION
                enableLights(true)
                enableVibration(true)
            }
            
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    /**
     * Get notification icon and priority based on type
     */
    private fun getNotificationConfig(type: String): Pair<Int, Int> {
        return when (type) {
            TYPE_MATCH_STARTED -> Pair(R.drawable.ic_sports, NotificationCompat.PRIORITY_HIGH)
            TYPE_MATCH_COMPLETED -> Pair(R.drawable.ic_premium_badge, NotificationCompat.PRIORITY_HIGH)
            TYPE_WICKET_FALLEN -> Pair(R.drawable.ic_stadium_floodlight, NotificationCompat.PRIORITY_DEFAULT)
            TYPE_SIX_HIT -> Pair(R.drawable.ic_premium_sports, NotificationCompat.PRIORITY_DEFAULT)
            TYPE_BOUNDARY_HIT -> Pair(R.drawable.ic_premium_sports, NotificationCompat.PRIORITY_LOW)
            TYPE_RAID_COMPLETED -> Pair(R.drawable.ic_premium_sports, NotificationCompat.PRIORITY_DEFAULT)
            TYPE_TACKLE_COMPLETED -> Pair(R.drawable.ic_stadium_floodlight, NotificationCompat.PRIORITY_DEFAULT)
            TYPE_ALL_OUT -> Pair(R.drawable.ic_premium_badge, NotificationCompat.PRIORITY_HIGH)
            TYPE_SET_COMPLETED -> Pair(R.drawable.ic_premium_sports, NotificationCompat.PRIORITY_DEFAULT)
            TYPE_MATCH_CANCELLED -> Pair(R.drawable.ic_stadium_floodlight, NotificationCompat.PRIORITY_HIGH)
            TYPE_TOURNAMENT_STARTED -> Pair(R.drawable.ic_premium_badge, NotificationCompat.PRIORITY_HIGH)
            TYPE_TOURNAMENT_COMPLETED -> Pair(R.drawable.ic_premium_badge, NotificationCompat.PRIORITY_HIGH)
            TYPE_NEW_TOURNAMENT -> Pair(R.drawable.ic_premium_sports, NotificationCompat.PRIORITY_DEFAULT)
            TYPE_TEAM_UPDATE -> Pair(R.drawable.ic_premium_sports, NotificationCompat.PRIORITY_LOW)
            TYPE_PLAYER_UPDATE -> Pair(R.drawable.ic_premium_sports, NotificationCompat.PRIORITY_LOW)
            else -> Pair(R.drawable.ic_premium_sports, NotificationCompat.PRIORITY_DEFAULT)
        }
    }
    
    /**
     * Check if notification is important (should use sound and vibration)
     */
    private fun isImportantNotification(type: String): Boolean {
        return when (type) {
            TYPE_MATCH_STARTED,
            TYPE_MATCH_COMPLETED,
            TYPE_WICKET_FALLEN,
            TYPE_SIX_HIT,
            TYPE_ALL_OUT,
            TYPE_MATCH_CANCELLED,
            TYPE_TOURNAMENT_STARTED,
            TYPE_TOURNAMENT_COMPLETED -> true
            else -> false
        }
    }
}

/**
 * Notification Manager - Helper class for sending notifications
 */
class NotificationManager(private val context: Context) {
    
    private val notificationScope = CoroutineScope(Dispatchers.IO)
    
    /**
     * Send match started notification
     */
    fun sendMatchStartedNotification(matchId: String, teamAName: String, teamBName: String) {
        notificationScope.launch {
            try {
                val title = "Match Started!"
                val message = "$teamAName vs $teamBName"
                
                sendNotification(NotificationService.TYPE_MATCH_STARTED, title, message, matchId, null)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    /**
     * Send match completed notification
     */
    fun sendMatchCompletedNotification(matchId: String, winnerName: String, resultSummary: String) {
        notificationScope.launch {
            try {
                val title = "Match Completed!"
                val message = "$winnerName won! $resultSummary"
                
                sendNotification(NotificationService.TYPE_MATCH_COMPLETED, title, message, matchId, null)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    /**
     * Send wicket fallen notification
     */
    fun sendWicketNotification(matchId: String, playerName: String, wicketType: String) {
        notificationScope.launch {
            try {
                val title = "Wicket!"
                val message = "$playerName - $wicketType"
                
                sendNotification(NotificationService.TYPE_WICKET_FALLEN, title, message, matchId, null)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    /**
     * Send boundary notification
     */
    fun sendBoundaryNotification(matchId: String, playerName: String, runs: Int) {
        notificationScope.launch {
            try {
                val title = "Boundary!"
                val message = "$playerName hits $runs runs"
                
                val type = if (runs == 6) NotificationService.TYPE_SIX_HIT else NotificationService.TYPE_BOUNDARY_HIT
                sendNotification(type, title, message, matchId, null)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    /**
     * Send tournament notification
     */
    fun sendTournamentNotification(tournamentId: String, tournamentName: String, type: String) {
        notificationScope.launch {
            try {
                val title = when (type) {
                    "started" -> "Tournament Started!"
                    "completed" -> "Tournament Completed!"
                    "new" -> "New Tournament!"
                    else -> "Tournament Update!"
                }
                
                val message = when (type) {
                    "started" -> "$tournamentName has begun"
                    "completed" -> "$tournamentName has concluded"
                    "new" -> "New tournament: $tournamentName"
                    else -> "Update for $tournamentName"
                }
                
                val notificationType = when (type) {
                    "started" -> NotificationService.TYPE_TOURNAMENT_STARTED
                    "completed" -> NotificationService.TYPE_TOURNAMENT_COMPLETED
                    "new" -> NotificationService.TYPE_NEW_TOURNAMENT
                    else -> NotificationService.TYPE_TOURNAMENT_STARTED
                }
                
                sendNotification(notificationType, title, message, null, tournamentId)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    /**
     * Send notification to Firebase Cloud Messaging
     */
    private suspend fun sendNotification(
        type: String,
        title: String,
        message: String,
        matchId: String?,
        tournamentId: String?
    ) {
        // This would integrate with FCM API to send push notifications
        // For now, we save to database and local notifications are handled by the service
        try {
            val currentUserId = FirebaseManager.getCurrentUserId()
            currentUserId?.let { userId ->
                val notificationId = FirebaseManager.notificationsRef.child(userId).push().key
                notificationId?.let { id ->
                    val notification = mapOf(
                        "id" to id,
                        "title" to title,
                        "message" to message,
                        "type" to type,
                        "isRead" to false,
                        "createdAt" to System.currentTimeMillis(),
                        "expiresAt" to (System.currentTimeMillis() + 86400000 * 7),
                        "matchId" to matchId,
                        "tournamentId" to tournamentId
                    )
                    
                    FirebaseManager.notificationsRef.child(userId).child(id).setValue(notification)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

/**
 * Custom exceptions for notification operations
 */
sealed class NotificationException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class TokenSaveFailed(message: String, cause: Throwable? = null) : NotificationException(message, cause)
    class MessageProcessingFailed(message: String, cause: Throwable? = null) : NotificationException(message, cause)
    class NotificationDisplayFailed(message: String, cause: Throwable? = null) : NotificationException(message, cause)
}
