package com.gramakalyana.sports.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gramakalyana.sports.ui.theme.MatteBlack
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

abstract class BaseViewModel : ViewModel() {
    
    // Loading state
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    // Error state
    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()
    
    // Success message state
    private val _successMessage = MutableStateFlow<String?>(null)
    val successMessage: StateFlow<String?> = _successMessage.asStateFlow()
    
    /**
     * Set loading state
     */
    protected fun setLoading(isLoading: Boolean) {
        _isLoading.value = isLoading
    }
    
    /**
     * Set error message
     */
    protected fun setErrorMessage(message: String?) {
        _errorMessage.value = message
    }
    
    /**
     * Set success message
     */
    protected fun setSuccessMessage(message: String?) {
        _successMessage.value = message
    }
    
    /**
     * Clear error message
     */
    fun clearErrorMessage() {
        _errorMessage.value = null
    }
    
    /**
     * Clear success message
     */
    fun clearSuccessMessage() {
        _successMessage.value = null
    }
    
    /**
     * Execute a suspending function with loading state and error handling
     */
    protected fun executeWithLoading(
        block: suspend () -> Unit
    ) {
        viewModelScope.launch {
            try {
                setLoading(true)
                clearErrorMessage()
                block()
            } catch (e: Exception) {
                setErrorMessage(e.message ?: "An unknown error occurred")
            } finally {
                setLoading(false)
            }
        }
    }
    
    /**
     * Execute a suspending function with loading state, error handling, and success message
     */
    protected fun executeWithLoadingAndSuccess(
        successMessage: String,
        block: suspend () -> Unit
    ) {
        viewModelScope.launch {
            try {
                setLoading(true)
                clearErrorMessage()
                clearSuccessMessage()
                block()
                setSuccessMessage(successMessage)
            } catch (e: Exception) {
                setErrorMessage(e.message ?: "An unknown error occurred")
            } finally {
                setLoading(false)
            }
        }
    }
}
