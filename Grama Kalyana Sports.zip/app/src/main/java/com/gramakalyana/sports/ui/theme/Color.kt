package com.gramakalyana.sports.ui.theme

import androidx.compose.ui.graphics.Color

// Sports Theme Colors
val NeonOrange = Color(0xFFFF6B35)
val NeonOrangeLight = Color(0xFFFF8C42)
val NeonOrangeDark = Color(0xFFE55100)

// Background Colors - Matte Black
val MatteBlack = Color(0xFF1A1A1A)
val MatteBlackLight = Color(0xFF2D2D2D)
val MatteBlackDark = Color(0xFF0D0D0D)

// Text Colors
val White = Color(0xFFFFFFFF)
val White80 = Color(0xCCFFFFFF)
val White60 = Color(0x99FFFFFF)
val White40 = Color(0x66FFFFFF)
val White20 = Color(0x33FFFFFF)

// Accent Colors
val NeonGreen = Color(0xFF39FF14)
val NeonBlue = Color(0xFF00D4FF)
val NeonRed = Color(0xFFFF073A)
val NeonYellow = Color(0xFFFFFF00)

// Sports Specific Colors
val CricketGreen = Color(0xFF2E7D32)
val KabaddiRed = Color(0xFFC62828)
val VolleyballBlue = Color(0xFF1565C0)

// Scoreboard Colors
val ScoreboardBg = Color(0xFF0A0A0A)
val ScoreboardBorder = NeonOrange
val ScoreboardText = White
val ScoreboardHighlight = NeonOrangeLight

// Status Colors
val LiveRed = Color(0xFFFF0000)
val LiveGreen = Color(0xFF00FF00)
val LiveYellow = Color(0xFFFFFF00)
