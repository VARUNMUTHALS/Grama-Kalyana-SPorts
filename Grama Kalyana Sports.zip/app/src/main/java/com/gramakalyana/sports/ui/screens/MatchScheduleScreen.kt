package com.gramakalyana.sports.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramakalyana.sports.models.*
import com.gramakalyana.sports.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchScheduleScreen(
    tournamentId: String,
    onBack: () -> Unit,
    onScheduleMatch: (Match) -> Unit
) {
    // Animation states
    val infiniteTransition = rememberInfiniteTransition()
    val backgroundRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(120000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    // Form states
    var selectedTeamA by remember { mutableStateOf<Team?>(null) }
    var selectedTeamB by remember { mutableStateOf<Team?>(null) }
    var matchDate by remember { mutableStateOf("") }
    var matchTime by remember { mutableStateOf("") }
    var venue by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    // Sample teams data
    val teams = remember {
        listOf(
            Team(
                id = "team_001",
                name = "Royal Warriors",
                logo = "",
                captain = "Rahul Sharma",
                totalPlayers = 11,
                wins = 8,
                losses = 2,
                points = 16,
                status = TeamStatus.ACTIVE,
                sportType = SportType.CRICKET,
                foundedYear = 2020,
                homeGround = "Grama Kalyana Stadium"
            ),
            Team(
                id = "team_002",
                name = "Thunder Strikers",
                logo = "",
                captain = "Vikram Singh",
                totalPlayers = 11,
                wins = 6,
                losses = 4,
                points = 12,
                status = TeamStatus.ACTIVE,
                sportType = SportType.CRICKET,
                foundedYear = 2019,
                homeGround = "Community Sports Ground"
            ),
            Team(
                id = "team_003",
                name = "Lions Club",
                logo = "",
                captain = "Amit Kumar",
                totalPlayers = 7,
                wins = 5,
                losses = 1,
                points = 10,
                status = TeamStatus.ACTIVE,
                sportType = SportType.KABADDI,
                foundedYear = 2021,
                homeGround = "Youth Sports Complex"
            ),
            Team(
                id = "team_004",
                name = "Eagles Team",
                logo = "",
                captain = "Sanjay Patel",
                totalPlayers = 6,
                wins = 3,
                losses = 3,
                points = 6,
                status = TeamStatus.ACTIVE,
                sportType = SportType.KABADDI,
                foundedYear = 2020,
                homeGround = "Beach Sports Arena"
            )
        )
    }
    
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Match schedule background
        MatchScheduleBackground(
            modifier = Modifier.fillMaxSize(),
            rotation = backgroundRotation,
            glowAlpha = glowPulse
        )
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Header
            MatchScheduleHeader(
                onBack = onBack,
                glowPulse = glowPulse
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Form content
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MatteBlackLight
                ),
                elevation = CardDefaults.cardElevation(
                    defaultElevation = 8.dp
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    // Team A selection
                    TeamSelectionSection(
                        title = "Team A",
                        selectedTeam = selectedTeamA,
                        teams = teams.filter { it.id != selectedTeamB?.id },
                        onTeamSelected = { selectedTeamA = it },
                        glowPulse = glowPulse
                    )
                    
                    // VS indicator
                    if (selectedTeamA != null && selectedTeamB != null) {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "VS",
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    color = NeonOrange.copy(alpha = 0.8f),
                                    letterSpacing = 6.sp,
                                    fontFamily = FontFamily.SansSerif
                                )
                            )
                        }
                    }
                    
                    // Team B selection
                    TeamSelectionSection(
                        title = "Team B",
                        selectedTeam = selectedTeamB,
                        teams = teams.filter { it.id != selectedTeamA?.id },
                        onTeamSelected = { selectedTeamB = it },
                        glowPulse = glowPulse
                    )
                    
                    // Date and time selection
                    DateTimeSelectionRow(
                        matchDate = matchDate,
                        matchTime = matchTime,
                        onDateChange = { 
                            matchDate = it
                            errorMessage = null
                        },
                        onTimeChange = { 
                            matchTime = it
                            errorMessage = null
                        },
                        onImeAction = {
                            focusManager.moveFocus(FocusDirection.Down)
                        },
                        glowPulse = glowPulse,
                        errorMessage = if (matchDate.isNotEmpty() && matchTime.isNotEmpty() && !isValidDateTime(matchDate, matchTime))
                            "Please enter valid date and time" else null
                    )
                    
                    // Venue
                    ScheduleTextField(
                        value = venue,
                        onValueChange = { 
                            venue = it
                            errorMessage = null
                        },
                        label = "Venue",
                        placeholder = "Enter match venue",
                        icon = Icons.Default.LocationOn,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done,
                        onImeAction = {
                            focusManager.clearFocus()
                        },
                        errorMessage = if (venue.isNotEmpty() && venue.length < 5)
                            "Venue must be at least 5 characters" else null
                    )
                    
                    Spacer(modifier = Modifier.height(20.dp))
                    
                    // Error message
                    errorMessage?.let {
                        Text(
                            text = it,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NeonRed
                            ),
                            modifier = Modifier.padding(bottom = 16.dp)
                        )
                    }
                    
                    // Schedule match button
                    ScheduleMatchButton(
                        onClick = {
                            if (validateScheduleForm(selectedTeamA, selectedTeamB, matchDate, matchTime, venue)) {
                                isLoading = true
                                val match = Match(
                                    id = "",
                                    tournamentId = tournamentId,
                                    teamAId = selectedTeamA!!.id,
                                    teamBId = selectedTeamB!!.id,
                                    teamAName = selectedTeamA!!.name,
                                    teamBName = selectedTeamB!!.name,
                                    sportType = selectedTeamA!!.sportType,
                                    venue = venue,
                                    scheduledDate = parseDateTime(matchDate, matchTime),
                                    status = MatchStatus.UPCOMING
                                )
                                onScheduleMatch(match)
                            }
                        },
                        isLoading = isLoading,
                        glowPulse = glowPulse,
                        isFormValid = selectedTeamA != null && selectedTeamB != null && 
                                     matchDate.isNotEmpty() && matchTime.isNotEmpty() && 
                                     venue.isNotEmpty()
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun MatchScheduleBackground(
    modifier: Modifier = Modifier,
    rotation: Float,
    glowAlpha: Float
) {
    Canvas(modifier = modifier.rotate(rotation)) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        
        // Subtle background effect
        val positions = listOf(
            Offset(canvasWidth * 0.15f, canvasHeight * 0.15f),
            Offset(canvasWidth * 0.85f, canvasHeight * 0.15f),
            Offset(canvasWidth * 0.15f, canvasHeight * 0.85f),
            Offset(canvasWidth * 0.85f, canvasHeight * 0.85f)
        )
        
        positions.forEach { position ->
            val gradient = androidx.compose.ui.graphics.RadialGradientShader(
                center = position,
                radius = min(canvasWidth, canvasHeight) * 0.4f,
                colors = listOf(
                    NeonOrange.copy(alpha = glowAlpha * 0.1f),
                    Color.Transparent
                ),
                colorStops = listOf(0f, 1f)
            )
            
            drawRect(
                brush = ShaderBrush(gradient),
                size = size
            )
        }
        
        // Center pattern
        val centerX = canvasWidth / 2
        val centerY = canvasHeight / 2
        
        drawCircle(
            color = NeonOrange.copy(alpha = glowAlpha * 0.05f),
            radius = min(canvasWidth, canvasHeight) * 0.2f,
            center = Offset(centerX, centerY)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchScheduleHeader(
    onBack: () -> Unit,
    glowPulse: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val logoPulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .background(MatteBlackLight, RoundedCornerShape(12.dp))
                .size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "SCHEDULE MATCH",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange,
                    letterSpacing = 2.sp
                )
            )
            
            Text(
                text = "Create new fixture",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White80
                )
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    color = NeonOrange.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(20.dp)
                )
                .scale(logoPulse),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Schedule,
                contentDescription = "Schedule",
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun TeamSelectionSection(
    title: String,
    selectedTeam: Team?,
    teams: List<Team>,
    onTeamSelected: (Team) -> Unit,
    glowPulse: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val selectorPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = White80
            )
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        if (selectedTeam != null) {
            // Selected team display
            SelectedTeamCard(
                team = selectedTeam,
                onClearSelection = { onTeamSelected(Team()) },
                glowPulse = glowPulse
            )
        } else {
            // Team selection grid
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .scale(selectorPulse),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(teams.size) { index ->
                    TeamSelectionCard(
                        team = teams[index],
                        onClick = { onTeamSelected(teams[index]) },
                        glowPulse = glowPulse
                    )
                }
            }
        }
    }
}

@Composable
fun SelectedTeamCard(
    team: Team,
    onClearSelection: () -> Unit,
    glowPulse: Float
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = NeonOrange.copy(alpha = 0.1f)
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 2.dp,
            color = NeonOrange.copy(alpha = glowPulse)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            color = NeonOrange.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(24.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = team.name.getInitials(),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = NeonOrange
                        )
                    )
                }
                
                Spacer(modifier = Modifier.width(16.dp))
                
                Column {
                    Text(
                        text = team.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NeonOrange
                        )
                    )
                    
                    Text(
                        text = "Captain: ${team.captain}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = White60
                        )
                    )
                }
            }
            
            IconButton(
                onClick = onClearSelection,
                modifier = Modifier
                    .background(MatteBlackLight, RoundedCornerShape(8.dp))
                    .size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Clear",
                    tint = NeonRed,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun TeamSelectionCard(
    team: Team,
    onClick: () -> Unit,
    glowPulse: Float
) {
    val infiniteTransition = rememberInfiniteTransition()
    val cardGlow by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .scale(cardGlow),
        colors = CardDefaults.cardColors(
            containerColor = MatteBlackLight
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        color = NeonOrange.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(20.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = team.name.getInitials(),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = NeonOrange
                    )
                )
            }
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = team.name,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = White
                    )
                )
                
                Text(
                    text = "Captain: ${team.captain}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = White60
                    )
                )
            }
            
            SportTypeBadge(
                sportType = team.sportType,
                isLive = false,
                size = SportBadgeSize.SMALL
            )
        }
    }
}

@Composable
fun DateTimeSelectionRow(
    matchDate: String,
    matchTime: String,
    onDateChange: (String) -> Unit,
    onTimeChange: (String) -> Unit,
    onImeAction: () -> Unit,
    glowPulse: Float,
    errorMessage: String? = null
) {
    val infiniteTransition = rememberInfiniteTransition()
    val selectorPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Column {
        Text(
            text = "Match Date & Time",
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = White80
            )
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .scale(selectorPulse),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DateField(
                value = matchDate,
                onValueChange = onDateChange,
                label = "Date",
                placeholder = "DD/MM/YYYY",
                icon = Icons.Default.CalendarToday,
                onImeAction = onImeAction
            )
            
            TimeField(
                value = matchTime,
                onValueChange = onTimeChange,
                label = "Time",
                placeholder = "HH:MM",
                icon = Icons.Default.Schedule,
                onImeAction = onImeAction
            )
        }
        
        errorMessage?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NeonRed
                ),
                modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onImeAction: () -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White80
                )
            )
        },
        placeholder = {
            Text(
                text = placeholder,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White40
                )
            )
        },
        leadingIcon = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Number,
            imeAction = ImeAction.Next
        ),
        keyboardActions = KeyboardActions(
            onAny = { onImeAction() }
        ),
        modifier = Modifier.weight(1f),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonOrange,
            unfocusedBorderColor = White20,
            focusedTextColor = White,
            unfocusedTextColor = White,
            cursorColor = NeonOrange
        ),
        shape = RoundedCornerShape(12.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimeField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onImeAction: () -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White80
                )
            )
        },
        placeholder = {
            Text(
                text = placeholder,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = White40
                )
            )
        },
        leadingIcon = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Number,
            imeAction = ImeAction.Next
        ),
        keyboardActions = KeyboardActions(
            onAny = { onImeAction() }
        ),
        modifier = Modifier.weight(1f),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonOrange,
            unfocusedBorderColor = White20,
            focusedTextColor = White,
            unfocusedTextColor = White,
            cursorColor = NeonOrange
        ),
        shape = RoundedCornerShape(12.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    keyboardType: KeyboardType,
    imeAction: ImeAction,
    onImeAction: () -> Unit,
    errorMessage: String? = null
) {
    Column {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White80
                    )
                )
            },
            placeholder = {
                Text(
                    text = placeholder,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = White40
                    )
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = NeonOrange,
                    modifier = Modifier.size(24.dp)
                )
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = keyboardType,
                imeAction = imeAction
            ),
            keyboardActions = KeyboardActions(
                onAny = { onImeAction() }
            ),
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonOrange,
                unfocusedBorderColor = White20,
                focusedTextColor = White,
                unfocusedTextColor = White,
                cursorColor = NeonOrange,
                errorBorderColor = NeonRed,
                errorTextColor = NeonRed
            ),
            shape = RoundedCornerShape(12.dp),
            isError = errorMessage != null
        )
        
        errorMessage?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NeonRed
                ),
                modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
        }
    }
}

@Composable
fun ScheduleMatchButton(
    onClick: () -> Unit,
    isLoading: Boolean,
    glowPulse: Float,
    isFormValid: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition()
    val buttonPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .scale(buttonPulse),
        enabled = !isLoading && isFormValid,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent
        ),
        contentPadding = PaddingValues(0.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            NeonOrangeDark,
                            NeonOrange,
                            NeonOrangeLight
                        )
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
                .border(
                    width = 2.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            NeonOrange.copy(alpha = glowPulse),
                            NeonOrangeLight.copy(alpha = glowPulse)
                        )
                    ),
                    shape = RoundedCornerShape(16.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = White,
                    strokeWidth = 2.dp
                )
            } else {
                Text(
                    text = "SCHEDULE MATCH",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = White,
                        letterSpacing = 2.sp
                    )
                )
            }
        }
    }
}

// Validation functions
fun validateScheduleForm(
    selectedTeamA: Team?,
    selectedTeamB: Team?,
    matchDate: String,
    matchTime: String,
    venue: String
): Boolean {
    return selectedTeamA != null &&
           selectedTeamB != null &&
           selectedTeamA.id != selectedTeamB.id &&
           matchDate.isNotEmpty() &&
           matchTime.isNotEmpty() &&
           venue.length >= 5 &&
           isValidDateTime(matchDate, matchTime)
}

fun isValidDateTime(date: String, time: String): Boolean {
    // Simple validation - in real app, use proper date parsing
    return date.length >= 8 && time.length >= 4
}

fun parseDateTime(date: String, time: String): Long {
    // Simple parsing - in real app, use proper date parsing
    return System.currentTimeMillis()
}

// Extension function for getting initials
fun String.getInitials(): String {
    return this.split(" ").take(2).joinToString("") { 
        it.firstOrNull()?.uppercase() ?: "" 
    }
}
