package com.gramakalyana.sports.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gramakalyana.sports.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit
) {
    var notificationsEnabled by remember { mutableStateOf(true) }
    var liveUpdatesEnabled by remember { mutableStateOf(true) }
    var soundEnabled by remember { mutableStateOf(true) }
    var vibrationEnabled by remember { mutableStateOf(true) }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .background(MatteBlackLight, RoundedCornerShape(12.dp))
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = NeonOrange
                )
            }
            
            Text(
                text = "Settings",
                style = MaterialTheme.typography.headlineMedium,
                color = White,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.width(48.dp))
        }
        
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                SettingsSection(title = "Notifications") {
                    SettingsSwitchTile(
                        title = "Push Notifications",
                        subtitle = "Receive match updates and news",
                        icon = Icons.Default.Notifications,
                        isChecked = notificationsEnabled,
                        onCheckedChange = { notificationsEnabled = it }
                    )
                    
                    SettingsSwitchTile(
                        title = "Live Updates",
                        subtitle = "Real-time score notifications",
                        icon = Icons.Default.LiveTv,
                        isChecked = liveUpdatesEnabled,
                        onCheckedChange = { liveUpdatesEnabled = it }
                    )
                    
                    SettingsSwitchTile(
                        title = "Sound",
                        subtitle = "Play sound for notifications",
                        icon = Icons.Default.VolumeUp,
                        isChecked = soundEnabled,
                        onCheckedChange = { soundEnabled = it }
                    )
                    
                    SettingsSwitchTile(
                        title = "Vibration",
                        subtitle = "Vibrate for important updates",
                        icon = Icons.Default.Vibration,
                        isChecked = vibrationEnabled,
                        onCheckedChange = { vibrationEnabled = it }
                    )
                }
            }
            
            item {
                SettingsSection(title = "Preferences") {
                    SettingsNavigationTile(
                        title = "Language",
                        subtitle = "English",
                        icon = Icons.Default.Language,
                        onClick = { /* Navigate to language settings */ }
                    )
                    
                    SettingsNavigationTile(
                        title = "Theme",
                        subtitle = "Dark Sports Theme",
                        icon = Icons.Default.Palette,
                        onClick = { /* Navigate to theme settings */ }
                    )
                    
                    SettingsNavigationTile(
                        title = "Score Display",
                        subtitle = "Large scoreboard",
                        icon = Icons.Default.Scoreboard,
                        onClick = { /* Navigate to score display settings */ }
                    )
                }
            }
            
            item {
                SettingsSection(title = "Data & Storage") {
                    SettingsNavigationTile(
                        title = "Clear Cache",
                        subtitle = "Free up storage space",
                        icon = Icons.Default.Storage,
                        onClick = { /* Clear cache */ }
                    )
                    
                    SettingsNavigationTile(
                        title = "Offline Mode",
                        subtitle = "Download matches for offline viewing",
                        icon = Icons.Default.Download,
                        onClick = { /* Navigate to offline settings */ }
                    )
                }
            }
            
            item {
                SettingsSection(title = "About") {
                    SettingsNavigationTile(
                        title = "Version",
                        subtitle = "1.0.0",
                        icon = Icons.Default.Info,
                        onClick = { /* Show version info */ }
                    )
                    
                    SettingsNavigationTile(
                        title = "Help & Support",
                        subtitle = "Get help with the app",
                        icon = Icons.Default.Help,
                        onClick = { /* Navigate to help */ }
                    )
                    
                    SettingsNavigationTile(
                        title = "Privacy Policy",
                        subtitle = "Read our privacy policy",
                        icon = Icons.Default.PrivacyTip,
                        onClick = { /* Navigate to privacy policy */ }
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsSection(
    title: String,
    content: @Composable () -> Unit
) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = NeonOrange,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 12.dp)
        )
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MatteBlackLight
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 4.dp
            )
        ) {
            Column(
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                content()
            }
        }
    }
}

@Composable
fun SettingsSwitchTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = White,
                    fontWeight = FontWeight.Medium
                )
                
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = White60
                )
            }
        }
        
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = NeonOrange,
                checkedTrackColor = NeonOrange.copy(alpha = 0.3f),
                uncheckedThumbColor = White40,
                uncheckedTrackColor = White20
            )
        )
    }
}

@Composable
fun SettingsNavigationTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = NeonOrange,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = White,
                    fontWeight = FontWeight.Medium
                )
                
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = White60
                )
            }
        }
        
        Icon(
            imageVector = Icons.Default.ArrowForward,
            contentDescription = "Navigate",
            tint = White40,
            modifier = Modifier.size(20.dp)
        )
    }
}
