package com.gramakalyana.sports.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.gramakalyana.sports.ui.screens.SplashScreen
import com.gramakalyana.sports.ui.screens.HomeScreen
import com.gramakalyana.sports.ui.screens.TournamentListScreen
import com.gramakalyana.sports.ui.screens.LiveScoresScreen
import com.gramakalyana.sports.ui.screens.StatisticsScreen
import com.gramakalyana.sports.ui.screens.SettingsScreen

@Composable
fun SportsNavigation(
    navController: NavHostController = rememberNavController(),
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Destination.SPLASH,
        modifier = modifier
    ) {
        // Splash Screen
        composable(Destination.SPLASH) {
            PremiumSplashScreen(
                onNavigateToHome = {
                    navController.navigate(Destination.HOME) {
                        popUpTo(Destination.SPLASH) { inclusive = true }
                    }
                }
            )
        }
        
        // Authentication Screens
        composable(Destination.LOGIN) {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate(Destination.HOME) {
                        popUpTo(Destination.LOGIN) { inclusive = true }
                    }
                },
                onForgotPassword = {
                    navController.navigate(Destination.FORGOT_PASSWORD)
                },
                onCreateAccount = {
                    navController.navigate(Destination.REGISTER)
                }
            )
        }
        
        composable(Destination.FORGOT_PASSWORD) {
            ForgotPasswordScreen(
                onBack = {
                    navController.popBackStack()
                },
                onResetSuccess = {
                    navController.navigate(Destination.LOGIN)
                }
            )
        }
        
        composable(Destination.REGISTER) {
            CreateAccountScreen(
                onBack = {
                    navController.popBackStack()
                },
                onAccountCreated = {
                    navController.navigate(Destination.HOME) {
                        popUpTo(Destination.LOGIN) { inclusive = true }
                    }
                }
            )
        }
        
        // Main Navigation
        composable(Destination.HOME) {
            HomeScreen(
                onNavigateToTournaments = {
                    navController.navigate(Destination.TOURNAMENTS)
                },
                onNavigateToLiveScores = {
                    navController.navigate(Destination.LIVE_SCORES)
                },
                onNavigateToStatistics = {
                    navController.navigate(Destination.STATISTICS)
                },
                onNavigateToSettings = {
                    navController.navigate(Destination.SETTINGS)
                }
            )
        }
        
        composable(Destination.TOURNAMENTS) {
            TournamentListScreen(
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToTournamentDetail = { tournamentId ->
                    navController.navigate("${Destination.TOURNAMENT_DETAIL}/$tournamentId")
                },
                onNavigateToCreateTournament = {
                    navController.navigate(Destination.CREATE_TOURNAMENT)
                }
            )
        }
        
        composable(Destination.LIVE_SCORES) {
            LiveScoresScreen(
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToMatchDetail = { matchId ->
                    navController.navigate("${Destination.MATCH_DETAIL}/$matchId")
                },
                onNavigateToLiveView = { matchId ->
                    navController.navigate("${Destination.LIVE_MATCH_VIEW}/$matchId")
                }
            )
        }
        
        composable(Destination.STATISTICS) {
            StatisticsScreen(
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToPlayerStats = { playerId ->
                    navController.navigate("${Destination.PLAYER_STATS}/$playerId")
                },
                onNavigateToTeamStats = { teamId ->
                    navController.navigate("${Destination.TEAM_STATS}/$teamId")
                },
                onNavigateToTournamentStats = { tournamentId ->
                    navController.navigate("${Destination.TOURNAMENT_STATS}/$tournamentId")
                }
            )
        }
        
        composable(Destination.SETTINGS) {
            SettingsScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
        
        // Tournament Management
        composable(Destination.TOURNAMENT_DETAIL_ROUTE) { backStackEntry ->
            val tournamentId = backStackEntry.arguments?.getString(Destination.TOURNAMENT_ID_ARG) ?: ""
            // TournamentDetailScreen will be implemented
        }
        
        composable(Destination.CREATE_TOURNAMENT) {
            // CreateTournamentScreen will be implemented
        }
        
        composable(Destination.EDIT_TOURNAMENT_ROUTE) { backStackEntry ->
            val tournamentId = backStackEntry.arguments?.getString(Destination.TOURNAMENT_ID_ARG) ?: ""
            // EditTournamentScreen will be implemented
        }
        
        // Team Management
        composable(Destination.TEAM_LIST) {
            // TeamListScreen will be implemented
        }
        
        composable(Destination.TEAM_DETAIL_ROUTE) { backStackEntry ->
            val teamId = backStackEntry.arguments?.getString(Destination.TEAM_ID_ARG) ?: ""
            // TeamDetailScreen will be implemented
        }
        
        composable(Destination.CREATE_TEAM) {
            // CreateTeamScreen will be implemented
        }
        
        composable(Destination.EDIT_TEAM_ROUTE) { backStackEntry ->
            val teamId = backStackEntry.arguments?.getString(Destination.TEAM_ID_ARG) ?: ""
            // EditTeamScreen will be implemented
        }
        
        // Player Management
        composable(Destination.PLAYER_LIST) {
            // PlayerListScreen will be implemented
        }
        
        composable(Destination.PLAYER_DETAIL_ROUTE) { backStackEntry ->
            val playerId = backStackEntry.arguments?.getString(Destination.PLAYER_ID_ARG) ?: ""
            // PlayerDetailScreen will be implemented
        }
        
        composable(Destination.CREATE_PLAYER) {
            // CreatePlayerScreen will be implemented
        }
        
        composable(Destination.EDIT_PLAYER_ROUTE) { backStackEntry ->
            val playerId = backStackEntry.arguments?.getString(Destination.PLAYER_ID_ARG) ?: ""
            // EditPlayerScreen will be implemented
        }
        
        // Match Management
        composable(Destination.MATCH_LIST) {
            // MatchListScreen will be implemented
        }
        
        composable(Destination.MATCH_DETAIL_ROUTE) { backStackEntry ->
            val matchId = backStackEntry.arguments?.getString(Destination.MATCH_ID_ARG) ?: ""
            // MatchDetailScreen will be implemented
        }
        
        composable(Destination.CREATE_MATCH) {
            // CreateMatchScreen will be implemented
        }
        
        composable(Destination.EDIT_MATCH_ROUTE) { backStackEntry ->
            val matchId = backStackEntry.arguments?.getString(Destination.MATCH_ID_ARG) ?: ""
            // EditMatchScreen will be implemented
        }
        
        // Live Scorer
        composable(Destination.LIVE_SCORER_ROUTE) { backStackEntry ->
            val matchId = backStackEntry.arguments?.getString(Destination.MATCH_ID_ARG) ?: ""
            // LiveScorerScreen will be implemented
        }
        
        composable(Destination.CRICKET_SCORER_ROUTE) { backStackEntry ->
            val matchId = backStackEntry.arguments?.getString(Destination.MATCH_ID_ARG) ?: ""
            // CricketScorerScreen will be implemented
        }
        
        composable(Destination.KABADDI_SCORER_ROUTE) { backStackEntry ->
            val matchId = backStackEntry.arguments?.getString(Destination.MATCH_ID_ARG) ?: ""
            // KabaddiScorerScreen will be implemented
        }
        
        composable(Destination.VOLLEYBALL_SCORER_ROUTE) { backStackEntry ->
            val matchId = backStackEntry.arguments?.getString(Destination.MATCH_ID_ARG) ?: ""
            // VolleyballScorerScreen will be implemented
        }
        
        // Public View
        composable(Destination.PUBLIC_LIVE_VIEW) {
            // PublicLiveViewScreen will be implemented
        }
        
        composable(Destination.LIVE_MATCH_VIEW_ROUTE) { backStackEntry ->
            val matchId = backStackEntry.arguments?.getString(Destination.MATCH_ID_ARG) ?: ""
            // LiveMatchViewScreen will be implemented
        }
        
        // Statistics
        composable(Destination.TOURNAMENT_STATS_ROUTE) { backStackEntry ->
            val tournamentId = backStackEntry.arguments?.getString(Destination.TOURNAMENT_ID_ARG) ?: ""
            // TournamentStatsScreen will be implemented
        }
        
        composable(Destination.TEAM_STATS_ROUTE) { backStackEntry ->
            val teamId = backStackEntry.arguments?.getString(Destination.TEAM_ID_ARG) ?: ""
            // TeamStatsScreen will be implemented
        }
        
        composable(Destination.PLAYER_STATS_ROUTE) { backStackEntry ->
            val playerId = backStackEntry.arguments?.getString(Destination.PLAYER_ID_ARG) ?: ""
            // PlayerStatsScreen will be implemented
        }
        
        composable(Destination.PLAYER_CAREER_ROUTE) { backStackEntry ->
            val playerId = backStackEntry.arguments?.getString(Destination.PLAYER_ID_ARG) ?: ""
            // PlayerCareerScreen will be implemented
        }
    }
}
