@echo off
echo Getting SHA-1 certificate for Firebase...
cd /d "%~dp0"
keytool -list -v -keystore "%USERPROFILE%\.android\debug.keystore" -alias androiddebugkey -storepass android -keypass android
pause
